/**
 * React Hook for Python Kernel
 */

import { useState, useCallback, useEffect, useRef } from 'react';
import type { PythonKernelState, CodeCell } from '@/types';
import { getPythonKernel } from '@/lib/python-kernel';

interface UsePythonReturn {
  state: PythonKernelState;
  cells: CodeCell[];
  execute: (code: string) => Promise<void>;
  installPackage: (packageName: string) => Promise<void>;
  clearCells: () => void;
  reset: () => void;
}

export function usePython(): UsePythonReturn {
  const kernelRef = useRef(getPythonKernel());
  const [state, setState] = useState<PythonKernelState>(kernelRef.current.getState());
  const [cells, setCells] = useState<CodeCell[]>([]);
  
  // Subscribe to state changes
  useEffect(() => {
    kernelRef.current.setOnStateChange((newState) => {
      setState(newState);
    });
  }, []);
  
  const execute = useCallback(async (code: string) => {
    const cell = await kernelRef.current.executeCode(code);
    setCells((prev) => [...prev, cell]);
  }, []);
  
  const installPackage = useCallback(async (packageName: string) => {
    await kernelRef.current.installPackage(packageName);
  }, []);
  
  const clearCells = useCallback(() => {
    setCells([]);
  }, []);
  
  const reset = useCallback(() => {
    kernelRef.current.reset();
    setCells([]);
  }, []);
  
  return {
    state,
    cells,
    execute,
    installPackage,
    clearCells,
    reset,
  };
}
