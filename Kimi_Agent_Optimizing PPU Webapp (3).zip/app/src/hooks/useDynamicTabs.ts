/**
 * Dynamic Tab System for Instantiated Apps
 */

import { useState, useCallback } from 'react';

export type TabType = 'python' | 'ppu-asm' | 'nlp-app' | 'visualization' | 'custom';

export interface DynamicTab {
  id: string;
  title: string;
  type: TabType;
  content: {
    code?: string;
    assembly?: string;
    bytecode?: Uint8Array;
    nlpInput?: string;
    compiled?: boolean;
    errors?: string[];
    fixes?: string[];
  };
  createdAt: number;
}

interface UseDynamicTabsReturn {
  tabs: DynamicTab[];
  activeTabId: string | null;
  addTab: (tab: Omit<DynamicTab, 'id' | 'createdAt'>) => string;
  removeTab: (id: string) => void;
  setActiveTab: (id: string) => void;
  updateTabContent: (id: string, content: Partial<DynamicTab['content']>) => void;
  getTab: (id: string) => DynamicTab | undefined;
}

export function useDynamicTabs(): UseDynamicTabsReturn {
  const [tabs, setTabs] = useState<DynamicTab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);

  const generateId = () => `tab_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const addTab = useCallback((tab: Omit<DynamicTab, 'id' | 'createdAt'>): string => {
    const id = generateId();
    const newTab: DynamicTab = {
      ...tab,
      id,
      createdAt: Date.now(),
    };
    
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(id);
    
    return id;
  }, []);

  const removeTab = useCallback((id: string) => {
    setTabs((prev) => {
      const filtered = prev.filter((t) => t.id !== id);
      
      // Update active tab if needed
      if (activeTabId === id) {
        setActiveTabId(filtered.length > 0 ? filtered[filtered.length - 1].id : null);
      }
      
      return filtered;
    });
  }, [activeTabId]);

  const setActiveTab = useCallback((id: string) => {
    setActiveTabId(id);
  }, []);

  const updateTabContent = useCallback((id: string, content: Partial<DynamicTab['content']>) => {
    setTabs((prev) =>
      prev.map((tab) =>
        tab.id === id
          ? { ...tab, content: { ...tab.content, ...content } }
          : tab
      )
    );
  }, []);

  const getTab = useCallback(
    (id: string) => tabs.find((t) => t.id === id),
    [tabs]
  );

  return {
    tabs,
    activeTabId,
    addTab,
    removeTab,
    setActiveTab,
    updateTabContent,
    getTab,
  };
}
