/**
 * React Hook for PPU/AQC State Management
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import type { PPUState } from '@/types';
import { createPPUState, stepPPU, pulsePPU, setCoherence } from '@/lib/ppu-core';

interface UsePPUReturn {
  state: PPUState;
  step: (dt: number) => void;
  pulse: (strength?: number) => void;
  setCoherence: (value: number) => void;
  setLoad: (value: number) => void;
  reset: () => void;
}

export function usePPU(): UsePPUReturn {
  const [state, setState] = useState<PPUState>(createPPUState());
  const stateRef = useRef(state);
  
  // Keep ref in sync
  useEffect(() => {
    stateRef.current = state;
  }, [state]);
  
  const step = useCallback((dt: number) => {
    const current = stateRef.current;
    stepPPU(current, dt);
    setState({ ...current });
  }, []);
  
  const pulse = useCallback((strength: number = 0.9) => {
    const current = stateRef.current;
    pulsePPU(current, strength);
    setState({ ...current });
  }, []);
  
  const setCoherenceValue = useCallback((value: number) => {
    const current = stateRef.current;
    setCoherence(current, value);
    setState({ ...current });
  }, []);
  
  const setLoad = useCallback((value: number) => {
    const current = stateRef.current;
    current.load = Math.min(Math.max(value, 0), 1);
    setState({ ...current });
  }, []);
  
  const reset = useCallback(() => {
    setState(createPPUState());
  }, []);
  
  return {
    state,
    step,
    pulse,
    setCoherence: setCoherenceValue,
    setLoad,
    reset,
  };
}
