/**
 * React Hook for GIFLife Field Management
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import type { PPUState } from '@/types';
import { GIFLifeField } from '@/lib/giflife-field';

interface UseGIFLifeReturn {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  field: GIFLifeField | null;
  isRunning: boolean;
  start: () => void;
  stop: () => void;
  splash: (x: number, y: number, radius: number, strength: number) => void;
  burnCache: (text: string) => void;
}

export function useGIFLife(ppu: PPUState): UseGIFLifeReturn {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fieldRef = useRef<GIFLifeField | null>(null);
  const animationRef = useRef<number | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  
  // Initialize field when canvas is available
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || fieldRef.current) return;
    
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(3, window.devicePixelRatio || 1);
    
    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    
    fieldRef.current = new GIFLifeField(rect.width, rect.height);
    
    // Initial render
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const imageData = fieldRef.current.render(ppu);
      ctx.putImageData(imageData, 0, 0);
    }
  }, []);
  
  // Animation loop
  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    const field = fieldRef.current;
    if (!canvas || !field) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Step simulation
    field.step(ppu, 0.016);
    
    // Render
    const imageData = field.render(ppu);
    ctx.putImageData(imageData, 0, 0);
    
    animationRef.current = requestAnimationFrame(animate);
  }, [ppu]);
  
  const start = useCallback(() => {
    if (!isRunning) {
      setIsRunning(true);
      animationRef.current = requestAnimationFrame(animate);
    }
  }, [isRunning, animate]);
  
  const stop = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    setIsRunning(false);
  }, []);
  
  const splash = useCallback((x: number, y: number, radius: number, strength: number) => {
    fieldRef.current?.splash(x, y, radius, strength);
  }, []);
  
  const burnCache = useCallback((text: string) => {
    fieldRef.current?.burnCache(text);
  }, []);
  
  // Cleanup
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);
  
  return {
    canvasRef,
    field: fieldRef.current,
    isRunning,
    start,
    stop,
    splash,
    burnCache,
  };
}
