/**
 * Unified GIF Interface - Everything inside the GIF at 60fps
 * Touch-only optimized interface
 * Auto-calibrated layout
 */

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Play, Square, RotateCcw, Menu, ChevronLeft, ChevronRight } from 'lucide-react';
import { GIFExecutor, type ExecutionFrame } from '@/lib/gif-executor';
import { decompilePPUToPython } from '@/lib/ppu-to-python-decompiler';
import { compilePythonToPPU } from '@/lib/python-to-ppu-compiler';
import { getNLTranslatorV2 } from '@/lib/nl-to-ppu-v2';

interface GIFInterfaceProps {
  initialMode?: 'python' | 'ppu' | 'nl';
}

export const GIFInterface: React.FC<GIFInterfaceProps> = ({ initialMode = 'python' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const executorRef = useRef<GIFExecutor | null>(null);
  
  const [mode, setMode] = useState<'python' | 'ppu' | 'nl'>(initialMode);
  const [code, setCode] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [currentFrame, setCurrentFrame] = useState<ExecutionFrame | null>(null);
  const [progress, setProgress] = useState(0);
  const [showCodePanel, setShowCodePanel] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const [twoWayView, setTwoWayView] = useState<'python' | 'ppu'>('python');
  const [decompiledCode, setDecompiledCode] = useState('');
  
  // Touch handling
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null);
  const [activeTab, setActiveTab] = useState<'editor' | 'frames' | 'poles'>('editor');
  
  // Initialize canvas and executor
  useEffect(() => {
    if (canvasRef.current && !executorRef.current) {
      executorRef.current = new GIFExecutor(canvasRef.current);
      executorRef.current.setCallbacks(
        (frame) => {
          setCurrentFrame(frame);
          setProgress(executorRef.current?.getProgress() || 0);
        },
        () => {
          setIsRunning(false);
        }
      );
    }
    
    return () => {
      executorRef.current?.reset();
    };
  }, []);
  
  // Handle code changes for two-way translation
  useEffect(() => {
    if (mode === 'python' && code) {
      const result = compilePythonToPPU(code);
      if (result.success) {
        const decompiled = decompilePPUToPython(result.bytecode);
        setDecompiledCode(decompiled.python);
      }
    }
  }, [code, mode]);
  
  const handleRun = useCallback(async () => {
    if (!executorRef.current) return;
    
    executorRef.current.reset();
    setIsRunning(true);
    
    if (mode === 'nl') {
      const translator = getNLTranslatorV2();
      await translator.init();
      executorRef.current.execute(code, 'natural-language');
    } else {
      executorRef.current.execute(code, mode === 'ppu' ? 'ppu-assembly' : 'python');
    }
  }, [code, mode]);
  
  const handleStop = useCallback(() => {
    executorRef.current?.stop();
    setIsRunning(false);
  }, []);
  
  const handleReset = useCallback(() => {
    executorRef.current?.reset();
    setIsRunning(false);
    setCurrentFrame(null);
    setProgress(0);
  }, []);
  
  // Touch handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchStart({ x: touch.clientX, y: touch.clientY });
  }, []);
  
  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    if (!touchStart) return;
    
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStart.x;
    const dy = touch.clientY - touchStart.y;
    
    // Swipe detection
    if (Math.abs(dx) > 50) {
      if (dx > 0) {
        // Swipe right - show code panel
        setShowCodePanel(true);
      } else {
        // Swipe left - hide code panel
        setShowCodePanel(false);
      }
    }
    
    if (Math.abs(dy) > 50 && dy < 0) {
      // Swipe up - show menu
      setShowMenu(true);
    }
    
    setTouchStart(null);
  }, [touchStart]);
  
  const handleCanvasTap = useCallback((e: React.MouseEvent) => {
    // Handle tap on canvas for touch interaction
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Check touch targets
    if (y < 50) {
      if (x < 60) handleRun();
      else if (x < 120) handleStop();
      else if (x < 180) handleReset();
      else if (x > rect.width - 70) setShowMenu(!showMenu);
    }
  }, [handleRun, handleStop, handleReset, showMenu]);
  
  // Example code snippets
  const examples = {
    python: `x = 128
y = 128
color = 0xFF0000
radius = 30

for i in range(100):
    x = x + 1
    fbset(x, y, color)

print("Done!")`,
    ppu: `; Draw a circle
LDI r0, 128    ; x center
LDI r1, 128    ; y center
LDI r2, 30     ; radius
LDI r3, 0xFF   ; red color

FBSET r0, r1, r3
OUT 0, r0
HALT`,
    nl: 'draw a red circle at 128 128 with size 30',
  };
  
  const loadExample = () => {
    setCode(examples[mode]);
  };
  
  return (
    <div 
      ref={containerRef}
      className="w-full h-screen bg-black overflow-hidden touch-none select-none"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Main Canvas Area - Everything inside GIF */}
      <div className="relative w-full h-full">
        <canvas
          ref={canvasRef}
          width={256}
          height={256}
          className="absolute inset-0 w-full h-full"
          style={{ imageRendering: 'pixelated' }}
          onClick={handleCanvasTap}
        />
        
        {/* Overlay UI - Rendered on top of GIF */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Top Control Bar */}
          <div className="absolute top-0 left-0 right-0 p-2 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent">
            <div className="flex items-center gap-2 pointer-events-auto">
              <button
                onClick={handleRun}
                disabled={isRunning}
                className={`p-2 rounded-lg ${isRunning ? 'bg-gray-700' : 'bg-emerald-600'} text-white touch-manipulation`}
              >
                <Play size={20} fill="currentColor" />
              </button>
              <button
                onClick={handleStop}
                disabled={!isRunning}
                className={`p-2 rounded-lg ${!isRunning ? 'bg-gray-700' : 'bg-red-600'} text-white touch-manipulation`}
              >
                <Square size={20} fill="currentColor" />
              </button>
              <button
                onClick={handleReset}
                className="p-2 rounded-lg bg-slate-600 text-white touch-manipulation"
              >
                <RotateCcw size={20} />
              </button>
            </div>
            
            <div className="flex items-center gap-2 pointer-events-auto">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-2 rounded-lg bg-slate-700 text-white touch-manipulation"
              >
                <Menu size={20} />
              </button>
            </div>
          </div>
          
          {/* Mode Selector */}
          <div className="absolute top-16 left-2 flex flex-col gap-1 pointer-events-auto">
            {(['python', 'ppu', 'nl'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`px-3 py-1.5 rounded text-xs font-mono touch-manipulation ${
                  mode === m ? 'bg-blue-600 text-white' : 'bg-slate-800/80 text-slate-300'
                }`}
              >
                {m.toUpperCase()}
              </button>
            ))}
          </div>
          
          {/* Two-way Toggle (when in python mode) */}
          {mode === 'python' && (
            <div className="absolute top-16 right-2 flex gap-1 pointer-events-auto">
              <button
                onClick={() => setTwoWayView('python')}
                className={`px-2 py-1 rounded text-xs ${twoWayView === 'python' ? 'bg-emerald-600' : 'bg-slate-700'} text-white`}
              >
                PY
              </button>
              <button
                onClick={() => setTwoWayView('ppu')}
                className={`px-2 py-1 rounded text-xs ${twoWayView === 'ppu' ? 'bg-purple-600' : 'bg-slate-700'} text-white`}
              >
                PPU
              </button>
            </div>
          )}
          
          {/* Code Panel - Swipeable */}
          {showCodePanel && (
            <div className="absolute bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur border-t border-slate-700 pointer-events-auto">
              {/* Tab Bar */}
              <div className="flex items-center border-b border-slate-700">
                {(['editor', 'frames', 'poles'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`flex-1 py-2 text-xs font-mono uppercase ${
                      activeTab === tab ? 'bg-slate-700 text-white' : 'text-slate-400'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
                <button
                  onClick={() => setShowCodePanel(false)}
                  className="px-3 py-2 text-slate-400"
                >
                  <ChevronRight size={16} />
                </button>
              </div>
              
              {/* Panel Content */}
              <div className="h-48 overflow-auto">
                {activeTab === 'editor' && (
                  <div className="p-2">
                    <textarea
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder={mode === 'nl' ? 'Enter natural language...' : 'Enter code...'}
                      className="w-full h-32 bg-slate-800 text-slate-200 font-mono text-xs p-2 rounded resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                      spellCheck={false}
                    />
                    <div className="flex items-center justify-between mt-2">
                      <button
                        onClick={loadExample}
                        className="text-xs text-blue-400 hover:text-blue-300"
                      >
                        Load Example
                      </button>
                      <span className="text-xs text-slate-500">
                        {code.split('\n').filter(l => l.trim()).length} lines
                      </span>
                    </div>
                    
                    {/* Two-way view */}
                    {mode === 'python' && decompiledCode && (
                      <div className="mt-2 p-2 bg-slate-800/50 rounded">
                        <div className="text-xs text-slate-400 mb-1">
                          {twoWayView === 'python' ? '← Decompiled from PPU' : '→ Compiled to PPU'}
                        </div>
                        <pre className="text-xs text-slate-300 overflow-x-auto">
                          {twoWayView === 'python' ? decompiledCode : compilePythonToPPU(code).assembly}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
                
                {activeTab === 'frames' && (
                  <div className="p-2">
                    {currentFrame ? (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Frame {currentFrame.lineNumber}</span>
                          <span className="text-emerald-400">
                            Poles: [{currentFrame.poleUses.join(', ')}]
                          </span>
                        </div>
                        <div className="font-mono text-xs text-slate-300 bg-slate-800 p-2 rounded">
                          {currentFrame.code}
                        </div>
                        {currentFrame.result !== null && currentFrame.result !== undefined && (
                          <div className="text-xs text-blue-400">
                            → {JSON.stringify(currentFrame.result)}
                          </div>
                        )}
                        <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                          <div 
                            className="bg-emerald-500 h-full transition-all"
                            style={{ width: `${progress * 100}%` }}
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="text-center text-slate-500 text-sm py-8">
                        Run code to see frames
                      </div>
                    )}
                  </div>
                )}
                
                {activeTab === 'poles' && (
                  <div className="p-2">
                    <div className="grid grid-cols-6 gap-1">
                      {Array.from({ length: 12 }, (_, i) => (
                        <div 
                          key={i}
                          className={`aspect-square rounded flex items-center justify-center text-xs font-mono ${
                            currentFrame?.poleUses.includes(i)
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          P{i}
                        </div>
                      ))}
                    </div>
                    <div className="mt-2 text-xs text-slate-400">
                      Active poles: {currentFrame?.poleUses.length || 0}/12
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Swipe hint when panel is hidden */}
          {!showCodePanel && (
            <button
              onClick={() => setShowCodePanel(true)}
              className="absolute bottom-4 left-1/2 -translate-x-1/2 p-2 bg-slate-800/80 rounded-full pointer-events-auto"
            >
              <ChevronLeft size={20} className="text-slate-400" />
            </button>
          )}
          
          {/* Status Overlay */}
          <div className="absolute bottom-2 right-2 text-xs font-mono text-slate-400 pointer-events-none">
            {isRunning ? (
              <span className="text-emerald-400">● RUNNING {Math.round(progress * 100)}%</span>
            ) : (
              <span className="text-slate-500">○ READY</span>
            )}
          </div>
        </div>
        
        {/* Menu Modal */}
        {showMenu && (
          <div 
            className="absolute inset-0 bg-black/80 backdrop-blur flex items-center justify-center pointer-events-auto"
            onClick={() => setShowMenu(false)}
          >
            <div 
              className="bg-slate-900 rounded-xl p-4 w-64 max-w-[80vw]"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-lg font-bold text-white mb-4">Menu</h3>
              <div className="space-y-2">
                <button
                  onClick={() => { loadExample(); setShowMenu(false); }}
                  className="w-full p-3 bg-slate-800 rounded-lg text-left text-slate-200 text-sm"
                >
                  Load Example
                </button>
                <button
                  onClick={() => { handleReset(); setShowMenu(false); }}
                  className="w-full p-3 bg-slate-800 rounded-lg text-left text-slate-200 text-sm"
                >
                  Reset Canvas
                </button>
                <button
                  onClick={() => { setCode(''); setShowMenu(false); }}
                  className="w-full p-3 bg-slate-800 rounded-lg text-left text-slate-200 text-sm"
                >
                  Clear Code
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
