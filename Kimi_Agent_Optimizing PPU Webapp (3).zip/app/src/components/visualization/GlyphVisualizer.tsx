/**
 * Multisensory Glyph-Convolutional Visualizer
 * Shows glyph algebra and spectral ladders
 */

import React, { useState, useMemo } from 'react';
import {
  createEmptyGlyph,
  addAtomToGlyph,
  createAtom,
  intrinsicSum,
  computeSpectralLadder,
  createPoetryCircle,
  checkHadamardCondition,
  SENSORY_MODALITIES,
  POETRY_TRIBES,
  CLASSICAL_METERS,
  visualizeGlyph,
} from '@/lib/glyph-convolutional';

export const GlyphVisualizer: React.FC = () => {
  const [glyphA] = useState(() => {
    const g = createEmptyGlyph();
    addAtomToGlyph(g, createAtom(0, 'vision', 3, '+'), 2);
    addAtomToGlyph(g, createAtom(1, 'vision', 1, '+'), 1);
    return g;
  });
  
  const [glyphB] = useState(() => {
    const g = createEmptyGlyph();
    addAtomToGlyph(g, createAtom(0, 'vision', 2, '+'), 1);
    addAtomToGlyph(g, createAtom(1, 'vision', 2, '-'), 1);
    return g;
  });
  
  const [selectedTribe, setSelectedTribe] = useState(POETRY_TRIBES[0]);
  const [selectedMeter, setSelectedMeter] = useState(CLASSICAL_METERS[0]);
  const [rhyme, setRhyme] = useState('al-Ḥā');
  
  const sumGlyph = useMemo(() => {
    return intrinsicSum(glyphA, glyphB);
  }, [glyphA, glyphB]);
  
  const spectralLadder = useMemo(() => {
    return computeSpectralLadder(sumGlyph, 'vision', 8);
  }, [sumGlyph]);
  
  const poetryCircle = useMemo(() => {
    return createPoetryCircle(selectedTribe, selectedMeter, rhyme);
  }, [selectedTribe, selectedMeter, rhyme]);
  
  const hadamardCheck = useMemo(() => {
    return checkHadamardCondition(poetryCircle, 8);
  }, [poetryCircle]);
  
  const vizA = useMemo(() => visualizeGlyph(glyphA), [glyphA]);
  const vizB = useMemo(() => visualizeGlyph(glyphB), [glyphB]);
  const vizSum = useMemo(() => visualizeGlyph(sumGlyph), [sumGlyph]);
  
  return (
    <div className="bg-slate-900 rounded-lg p-4 border border-slate-700 space-y-4">
      <h3 className="text-sm font-semibold text-slate-200">
        Multisensory Glyph-Convolutional Theory
      </h3>
      
      {/* Glyph Algebra Demo */}
      <div className="bg-slate-800 rounded p-3">
        <h4 className="text-xs text-slate-400 mb-2">Glyph Algebra (A ⊕ B)</h4>
        
        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="bg-slate-900 rounded p-2">
            <h5 className="text-slate-500 mb-1">Glyph A</h5>
            <div className="space-y-1">
              {vizA.atoms.map((atom, i) => (
                <div key={i} className="font-mono text-blue-400">
                  ⟨{atom.layer}, {atom.modality}, {atom.template}, {atom.polarity}⟩ × {atom.multiplicity}
                </div>
              ))}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-700">
              <span className="text-slate-500">Det = </span>
              <span className="text-emerald-400">{vizA.determinant.toExponential(2)}</span>
            </div>
          </div>
          
          <div className="bg-slate-900 rounded p-2">
            <h5 className="text-slate-500 mb-1">Glyph B</h5>
            <div className="space-y-1">
              {vizB.atoms.map((atom, i) => (
                <div key={i} className="font-mono text-rose-400">
                  ⟨{atom.layer}, {atom.modality}, {atom.template}, {atom.polarity}⟩ × {atom.multiplicity}
                </div>
              ))}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-700">
              <span className="text-slate-500">Det = </span>
              <span className="text-emerald-400">{vizB.determinant.toExponential(2)}</span>
            </div>
          </div>
          
          <div className="bg-slate-900 rounded p-2 border border-emerald-700">
            <h5 className="text-slate-500 mb-1">A ⊕ B (Normalized)</h5>
            <div className="space-y-1">
              {vizSum.atoms.map((atom, i) => (
                <div key={i} className="font-mono text-emerald-400">
                  ⟨{atom.layer}, {atom.modality}, {atom.template}, {atom.polarity}⟩ × {atom.multiplicity}
                </div>
              ))}
            </div>
            <div className="mt-2 pt-2 border-t border-slate-700">
              <span className="text-slate-500">Det = </span>
              <span className="text-emerald-400">{vizSum.determinant.toExponential(2)}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Spectral Ladder */}
      <div className="bg-slate-800 rounded p-3">
        <h4 className="text-xs text-slate-400 mb-2">Spectral Ladder (MCT Tail)</h4>
        <div className="flex items-center gap-1">
          {spectralLadder.eigenvalues.map((ev, i) => {
            const magnitude = Math.sqrt(ev.re * ev.re + ev.im * ev.im);
            
            return (
              <div
                key={i}
                className="flex-1 h-16 bg-slate-900 rounded relative overflow-hidden"
              >
                <div
                  className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-600 to-purple-500 transition-all"
                  style={{ height: `${Math.min(magnitude * 20, 100)}%` }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[8px] text-white font-mono">
                    λ<sub>{i}</sub>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
        <div className="mt-2 text-xs text-slate-400">
          Product Det = <span className="text-emerald-400">{spectralLadder.determinant.toExponential(4)}</span>
        </div>
      </div>
      
      {/* Poetry Circle (Rawḍ al-Ṭarīq) */}
      <div className="bg-slate-800 rounded p-3">
        <h4 className="text-xs text-slate-400 mb-2">Poetry Circle (Rawḍ al-Ṭarīq)</h4>
        
        <div className="flex gap-2 mb-3">
          <select
            value={selectedTribe}
            onChange={(e) => setSelectedTribe(e.target.value)}
            className="flex-1 px-2 py-1 bg-slate-900 border border-slate-600 rounded text-xs text-slate-200"
          >
            {POETRY_TRIBES.map((tribe) => (
              <option key={tribe} value={tribe}>{tribe}</option>
            ))}
          </select>
          
          <select
            value={selectedMeter}
            onChange={(e) => setSelectedMeter(e.target.value)}
            className="flex-1 px-2 py-1 bg-slate-900 border border-slate-600 rounded text-xs text-slate-200"
          >
            {CLASSICAL_METERS.map((meter) => (
              <option key={meter} value={meter}>{meter}</option>
            ))}
          </select>
          
          <input
            type="text"
            value={rhyme}
            onChange={(e) => setRhyme(e.target.value)}
            placeholder="Rhyme..."
            className="w-24 px-2 py-1 bg-slate-900 border border-slate-600 rounded text-xs text-slate-200"
          />
        </div>
        
        <div className="bg-slate-900 rounded p-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400">
              {poetryCircle.tribe} - {poetryCircle.meter} - {poetryCircle.rhyme}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded ${
              hadamardCheck.satisfied 
                ? 'bg-emerald-900 text-emerald-400' 
                : 'bg-amber-900 text-amber-400'
            }`}>
              {hadamardCheck.satisfied ? 'Hadamard ✓' : 'Imperfect'}
            </span>
          </div>
          
          <div className="text-xs text-slate-500">
            Max deviation: <span className="text-slate-300">{hadamardCheck.maxDeviation.toFixed(4)}</span>
          </div>
        </div>
      </div>
      
      {/* Sensory Modalities */}
      <div className="bg-slate-800 rounded p-3">
        <h4 className="text-xs text-slate-400 mb-2">Sensory Modalities</h4>
        <div className="flex flex-wrap gap-1">
          {SENSORY_MODALITIES.map((mod) => (
            <span
              key={mod.name}
              className="px-2 py-1 bg-slate-900 rounded text-xs text-slate-300"
              title={`${mod.layers} layers, ${mod.templates.length} templates`}
            >
              {mod.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
