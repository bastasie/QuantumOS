/**
 * Modular Entropy Visualizer
 * Shows entropy calculations and cooling profiles
 */

import React, { useState, useMemo } from 'react';
import { 
  generateEntropyVisualization, 
  generateCoolingMatrix,
} from '@/lib/modular-entropy';
import type { CoolingProfile } from '@/types';

export const EntropyVisualizer: React.FC = () => {
  const [temperature, setTemperature] = useState(300);
  const [numStates, setNumStates] = useState(10);
  
  const entropyData = useMemo(() => {
    return generateEntropyVisualization(numStates, temperature);
  }, [numStates, temperature]);
  
  const coolingProfiles: CoolingProfile[] = useMemo(() => [
    { position: [0.3, 0.3, 0], intensity: 1.0, frequency: 2.0, phase: 0 },
    { position: [0.7, 0.7, 0], intensity: 0.8, frequency: 1.5, phase: Math.PI / 2 },
    { position: [0.5, 0.5, 0], intensity: 0.6, frequency: 3.0, phase: Math.PI },
  ], []);
  
  const coolingMatrix = useMemo(() => {
    return generateCoolingMatrix([16, 16, 1], coolingProfiles, 0);
  }, [coolingProfiles]);
  
  const maxCooling = Math.max(...coolingMatrix);
  const minCooling = Math.min(...coolingMatrix);
  
  return (
    <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
      <h3 className="text-sm font-semibold text-slate-200 mb-4">
        Modular Entropy Framework
      </h3>
      
      {/* Controls */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="text-xs text-slate-400 block mb-1">Temperature (K)</label>
          <input
            type="range"
            min="10"
            max="1000"
            value={temperature}
            onChange={(e) => setTemperature(parseInt(e.target.value))}
            className="w-full h-1 bg-slate-600 rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-xs text-slate-300">{temperature} K</span>
        </div>
        
        <div>
          <label className="text-xs text-slate-400 block mb-1">Number of States</label>
          <input
            type="range"
            min="5"
            max="20"
            value={numStates}
            onChange={(e) => setNumStates(parseInt(e.target.value))}
            className="w-full h-1 bg-slate-600 rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-xs text-slate-300">{numStates}</span>
        </div>
      </div>
      
      {/* Entropy summary */}
      <div className="bg-slate-800 rounded p-3 mb-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-400">Total Entropy:</span>
          <span className="text-lg font-mono text-emerald-400">
            {entropyData.entropy.toExponential(4)} J/K
          </span>
        </div>
      </div>
      
      {/* Energy levels */}
      <div className="bg-slate-800 rounded p-3 mb-4">
        <h4 className="text-xs text-slate-400 mb-2">Energy Level Distribution</h4>
        <div className="space-y-2">
          {entropyData.energies.slice(0, 8).map((_, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="text-xs text-slate-500 w-8">E<sub>{i}</sub></span>
              <div className="flex-1 h-4 bg-slate-700 rounded overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                  style={{ width: `${(entropyData.probabilities[i] * 100).toFixed(1)}%` }}
                />
              </div>
              <span className="text-xs font-mono text-slate-300 w-16 text-right">
                {(entropyData.probabilities[i] * 100).toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
      
      {/* 3D Standing Wave Pattern */}
      <div className="bg-slate-800 rounded p-3">
        <h4 className="text-xs text-slate-400 mb-2">3D Standing Wave Cooling Pattern</h4>
        <div 
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(16, 1fr)',
            gap: '1px'
          }}
        >
          {Array.from({ length: 16 }, (_, y) => (
            Array.from({ length: 16 }, (_, x) => {
              const idx = y * 16 + x;
              const value = coolingMatrix[idx];
              const normalized = (value - minCooling) / (maxCooling - minCooling || 1);
              
              return (
                <div
                  key={`${x}-${y}`}
                  style={{
                    aspectRatio: '1',
                    backgroundColor: `hsl(${240 - normalized * 240}, 70%, ${30 + normalized * 40}%)`,
                  }}
                  title={`I(${x / 16}, ${y / 16}) = ${value.toFixed(3)}`}
                />
              );
            })
          ))}
        </div>
        <div className="flex justify-between text-[10px] text-slate-500 mt-1">
          <span>Cold (blue)</span>
          <span>Hot (red)</span>
        </div>
      </div>
      
      {/* Application notes */}
      <div className="mt-4 pt-4 border-t border-slate-700">
        <h4 className="text-xs text-slate-400 mb-2">Applications</h4>
        <ul className="text-xs text-slate-300 space-y-1">
          <li>• Rapid cooling via material-specific resonant frequencies</li>
          <li>• UV purification with standing wave patterns</li>
          <li>• Copper-silver ionization with modulated release</li>
          <li>• Targeted heating with feedback control</li>
        </ul>
      </div>
    </div>
  );
};
