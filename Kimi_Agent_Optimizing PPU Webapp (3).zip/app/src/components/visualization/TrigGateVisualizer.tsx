/**
 * Trigonometric Gate Visualizer
 * Shows Boolean gates in trigonometric form
 */

import React, { useState, useMemo } from 'react';
import { TRIG_GATES, generateGateVisualization, verifyParseval } from '@/lib/trig-set-theory';

export const TrigGateVisualizer: React.FC = () => {
  const [selectedGate, setSelectedGate] = useState<string>('AND');
  
  const visualization = useMemo(() => {
    return generateGateVisualization(selectedGate);
  }, [selectedGate]);
  
  const parsevalResult = useMemo(() => {
    const gate = TRIG_GATES[selectedGate];
    if (!gate) return null;
    return verifyParseval((x) => gate.evaluate(x) ? 1 : 0, 2);
  }, [selectedGate]);
  
  const gate = TRIG_GATES[selectedGate];
  
  return (
    <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
      <h3 className="text-sm font-semibold text-slate-200 mb-4">
        Trigonometric Set Theory - Boolean Gates
      </h3>
      
      {/* Gate selector */}
      <div className="flex flex-wrap gap-2 mb-4">
        {Object.keys(TRIG_GATES).map((name) => (
          <button
            key={name}
            onClick={() => setSelectedGate(name)}
            className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              selectedGate === name
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {name}
          </button>
        ))}
      </div>
      
      {gate && (
        <div className="space-y-4">
          {/* Trigonometric expression */}
          <div className="bg-slate-800 rounded p-3">
            <h4 className="text-xs text-slate-400 mb-2">Trigonometric Form</h4>
            <code className="text-sm font-mono text-emerald-400">
              {selectedGate}(x, y) = {gate.trigExpression}
            </code>
          </div>
          
          {/* Truth table */}
          <div className="bg-slate-800 rounded p-3">
            <h4 className="text-xs text-slate-400 mb-2">Truth Table</h4>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-slate-500">
                  <th className="text-left py-1">x</th>
                  <th className="text-left py-1">y</th>
                  <th className="text-left py-1">{selectedGate}(x,y)</th>
                </tr>
              </thead>
              <tbody className="font-mono">
                {visualization.truthTable.slice(0, 4).map(([inputs, output], i) => (
                  <tr key={i} className="text-slate-300">
                    <td className="py-1">{inputs[0] ? '1' : '0'}</td>
                    <td className="py-1">{inputs[1] ? '1' : '0'}</td>
                    <td className="py-1 text-emerald-400">{output ? '1' : '0'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Fourier coefficients */}
          <div className="bg-slate-800 rounded p-3">
            <h4 className="text-xs text-slate-400 mb-2">Fourier Coefficients</h4>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              {Array.from(visualization.fourierCoefficients.entries()).map(([key, value]) => (
                <div key={key} className="flex justify-between">
                  <span className="text-slate-500">f̂({key})</span>
                  <span className="text-blue-400">{value.toFixed(4)}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Parseval verification */}
          {parsevalResult && (
            <div className="bg-slate-800 rounded p-3">
              <h4 className="text-xs text-slate-400 mb-2">Parseval's Identity</h4>
              <div className="text-xs font-mono space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Σ f̂(S)² =</span>
                  <span className="text-purple-400">{parsevalResult.lhs.toFixed(6)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">2⁻ⁿ Σ f(x)² =</span>
                  <span className="text-purple-400">{parsevalResult.rhs.toFixed(6)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Error:</span>
                  <span className={parsevalResult.error < 1e-10 ? 'text-emerald-400' : 'text-rose-400'}>
                    {parsevalResult.error.toExponential(2)}
                  </span>
                </div>
              </div>
            </div>
          )}
          
          {/* Spectral surface visualization */}
          <div className="bg-slate-800 rounded p-3">
            <h4 className="text-xs text-slate-400 mb-2">Spectral Surface</h4>
            <div 
              className="relative"
              style={{ 
                display: 'grid',
                gridTemplateColumns: `repeat(${visualization.spectralValues[0]?.length || 11}, 1fr)`,
                gap: '1px'
              }}
            >
              {visualization.spectralValues.map((row, y) => (
                row.map((value, x) => (
                  <div
                    key={`${x}-${y}`}
                    style={{
                      aspectRatio: '1',
                      backgroundColor: `hsl(${value * 240}, 70%, ${30 + value * 40}%)`,
                    }}
                    title={`f(${x / 10}, ${y / 10}) = ${value.toFixed(3)}`}
                  />
                ))
              ))}
            </div>
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>x: 0→1</span>
              <span>y: 0→1</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
