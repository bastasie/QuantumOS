/**
 * Python Code Editor Component
 */

import React, { useState } from 'react';
import { Play, Trash2, Package, Loader2 } from 'lucide-react';
import type { PythonKernelState, CodeCell } from '@/types';

interface PythonEditorProps {
  state: PythonKernelState;
  cells: CodeCell[];
  onExecute: (code: string) => void;
  onClear: () => void;
  onInstallPackage: (pkg: string) => void;
}

const DEFAULT_CODE = `# PPU-AQC Python Environment
# Available: numpy, sympy, matplotlib, pandas

import numpy as np
import sympy as sp
import matplotlib.pyplot as plt

# Example: Prime factorization visualization
def plot_prime_spiral(n=1000):
    fig, ax = plt.subplots(figsize=(8, 8), facecolor='black')
    ax.set_facecolor('black')
    
    # Generate prime spiral
    x, y = [], []
    for i in range(n):
        angle = i * 2.39996  # Golden angle
        r = np.sqrt(i)
        x.append(r * np.cos(angle))
        y.append(r * np.sin(angle))
    
    ax.scatter(x, y, c=range(n), cmap='hsv', s=1, alpha=0.6)
    ax.set_aspect('equal')
    ax.axis('off')
    plt.title('Prime Number Spiral', color='white', fontsize=14)
    return fig

# Execute
fig = plot_prime_spiral(2000)
plt.show()

print("PPU-AQC Python Kernel Ready!")
print(f"Coherence: {ppu_aqc.coherence if 'ppu_aqc' in dir() else 'N/A'}")
`;

export const PythonEditor: React.FC<PythonEditorProps> = ({
  state,
  cells,
  onExecute,
  onClear,
  onInstallPackage,
}) => {
  const [code, setCode] = useState(DEFAULT_CODE);
  const [packageName, setPackageName] = useState('');

  const handleExecute = () => {
    onExecute(code);
  };

  const handleInstall = () => {
    if (packageName.trim()) {
      onInstallPackage(packageName.trim());
      setPackageName('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-200">Python Cell</span>
          <span className={`text-xs px-2 py-0.5 rounded ${
            state.status === 'ready' ? 'bg-emerald-900 text-emerald-400' :
            state.status === 'running' ? 'bg-amber-900 text-amber-400' :
            state.status === 'error' ? 'bg-rose-900 text-rose-400' :
            'bg-slate-700 text-slate-400'
          }`}>
            {state.status === 'loading' && <Loader2 className="w-3 h-3 inline animate-spin mr-1" />}
            {state.status.toUpperCase()}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <input
              type="text"
              placeholder="Package name..."
              value={packageName}
              onChange={(e) => setPackageName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleInstall()}
              className="w-32 px-2 py-1 bg-slate-700 border border-slate-600 rounded text-xs text-slate-200"
            />
            <button
              onClick={handleInstall}
              disabled={state.status === 'running'}
              className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded transition-colors"
              title="Install package"
            >
              <Package className="w-4 h-4" />
            </button>
          </div>
          
          <button
            onClick={onClear}
            className="p-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded transition-colors"
            title="Clear output"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          
          <button
            onClick={handleExecute}
            disabled={state.status === 'running' || state.status === 'loading'}
            className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-600 text-white rounded text-sm font-medium transition-colors"
          >
            {state.status === 'running' ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            Run
          </button>
        </div>
      </div>
      
      {/* Code editor */}
      <div className="flex-1 flex">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="flex-1 p-4 bg-slate-950 text-slate-300 font-mono text-sm resize-none focus:outline-none"
          spellCheck={false}
          style={{ tabSize: 4 }}
        />
      </div>
      
      {/* Output area */}
      <div className="h-48 overflow-auto border-t border-slate-700 bg-slate-950">
        {cells.length === 0 ? (
          <div className="p-4 text-slate-500 text-sm">
            No output yet. Click Run to execute code.
          </div>
        ) : (
          <div className="space-y-2 p-2">
            {cells.map((cell) => (
              <div key={cell.id} className="bg-slate-900 rounded p-3">
                {cell.output && (
                  <pre className="text-sm text-slate-300 font-mono whitespace-pre-wrap">
                    {cell.output}
                  </pre>
                )}
                {cell.error && (
                  <pre className="text-sm text-rose-400 font-mono whitespace-pre-wrap mt-2">
                    {cell.error}
                  </pre>
                )}
                {cell.figure && (
                  <div className="mt-2">
                    <img
                      src={`data:image/png;base64,${cell.figure}`}
                      alt="Output figure"
                      className="max-w-full rounded"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
