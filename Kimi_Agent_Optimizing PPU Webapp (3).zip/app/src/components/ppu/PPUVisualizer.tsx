/**
 * PPU Visualizer Component
 * Displays the 12-pole harmonic oscillator system
 */

import React from 'react';
import type { PPUState } from '@/types';
import { NUM_POLES } from '@/lib/ppu-core';

interface PPUVisualizerProps {
  state: PPUState;
  onPulse?: () => void;
  onCoherenceChange?: (value: number) => void;
}

export const PPUVisualizer: React.FC<PPUVisualizerProps> = ({
  state,
  onPulse,
  onCoherenceChange,
}) => {
  const barHeight = 80;
  const barWidth = 12;
  
  return (
    <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-200">PPU Pole Bank</h3>
        <div className="flex gap-2">
          <button
            onClick={onPulse}
            className="px-3 py-1 text-xs bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors"
          >
            Pulse
          </button>
        </div>
      </div>
      
      {/* Pole visualization */}
      <div className="flex items-end justify-center gap-1 mb-4" style={{ height: barHeight + 20 }}>
        {Array.from({ length: NUM_POLES }, (_, i) => {
          const amp = state.poles[i];
          const h = Math.abs(amp) * (barHeight * 0.45);
          const isPositive = amp >= 0;
          
          return (
            <div
              key={i}
              className="relative flex flex-col items-center"
              style={{ width: barWidth }}
            >
              <div
                className={`w-full rounded-sm transition-all duration-75 ${
                  isPositive ? 'bg-emerald-500' : 'bg-rose-500'
                }`}
                style={{ height: h }}
              />
              <span className="text-[8px] text-slate-500 mt-1">{i}</span>
            </div>
          );
        })}
      </div>
      
      {/* Status indicators */}
      <div className="grid grid-cols-2 gap-3 text-xs">
        <div className="bg-slate-800 rounded p-2">
          <span className="text-slate-400">Coherence:</span>
          <div className="flex items-center gap-2 mt-1">
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={state.coherence}
              onChange={(e) => onCoherenceChange?.(parseFloat(e.target.value))}
              className="flex-1 h-1 bg-slate-600 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-slate-200 w-10 text-right">{state.coherence.toFixed(2)}</span>
          </div>
        </div>
        
        <div className="bg-slate-800 rounded p-2">
          <span className="text-slate-400">Entropy:</span>
          <div className="mt-1">
            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-100"
                style={{ width: `${state.entropy * 100}%` }}
              />
            </div>
            <span className="text-slate-200">{state.entropy.toFixed(3)}</span>
          </div>
        </div>
        
        <div className="bg-slate-800 rounded p-2">
          <span className="text-slate-400">Temperature:</span>
          <span className="text-slate-200 ml-2">{state.temperature.toFixed(2)}</span>
        </div>
        
        <div className="bg-slate-800 rounded p-2">
          <span className="text-slate-400">Load:</span>
          <div className="mt-1">
            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-purple-500 transition-all duration-100"
                style={{ width: `${state.load * 100}%` }}
              />
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800 rounded p-2">
          <span className="text-slate-400">Smooth:</span>
          <span className="text-slate-200 ml-2">{state.smooth.toFixed(3)}</span>
        </div>
      </div>
    </div>
  );
};
