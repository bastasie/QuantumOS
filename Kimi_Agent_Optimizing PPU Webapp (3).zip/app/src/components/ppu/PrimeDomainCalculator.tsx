/**
 * Prime Domain Calculator with Symbolic Math
 * Demonstrates log-domain multiplication, prime factorization, and symbolic computation
 * 100+ mathematical symbols
 */

import React, { useState, useCallback, useMemo } from 'react';
import { 
  factorize, 
  toPrimeVector, 
  logDomainMultiply,
  primeToVoltage,
  PRIMES,
} from '@/lib/ppu-core';
import {
  MATH_SYMBOLS,
  SYMBOLS_BY_CATEGORY,
  parseExpression,
  evaluate,
  simplify,
  linkToPrimeDomain,
  type SymbolicExpr,
  type MathSymbol,
} from '@/lib/symbolic-math';

export const PrimeDomainCalculator: React.FC = () => {
  const [inputA, setInputA] = useState<number>(12);
  const [inputB, setInputB] = useState<number>(15);
  const [symbolicInput, setSymbolicInput] = useState<string>('pi * x + sin(theta)');
  const [activeTab, setActiveTab] = useState<'numeric' | 'symbolic' | 'symbols'>('numeric');
  const [selectedSymbolCategory, setSelectedSymbolCategory] = useState<string>('constant');
  
  const [numericResult, setNumericResult] = useState<{
    product: number;
    logProduct: number;
    factorsA: Map<number, number>;
    factorsB: Map<number, number>;
    vectorA: number[];
    vectorB: number[];
    voltageA: number;
    voltageB: number;
    voltageProduct: number;
  } | null>(null);
  
  const [symbolicResult, setSymbolicResult] = useState<{
    expr: SymbolicExpr;
    simplified: SymbolicExpr;
    evaluated: number;
    latex: string;
    primeVector: number[];
    logDomainValue: number;
    analogVoltage: number;
  } | null>(null);

  const calculateNumeric = useCallback(() => {
    const product = inputA * inputB;
    const logProduct = logDomainMultiply(inputA, inputB);
    
    const factorsA = factorize(inputA);
    const factorsB = factorize(inputB);
    
    const vectorA = toPrimeVector(inputA);
    const vectorB = toPrimeVector(inputB);
    
    const voltageA = primeToVoltage(inputA);
    const voltageB = primeToVoltage(inputB);
    const voltageProduct = primeToVoltage(product);
    
    setNumericResult({
      product,
      logProduct,
      factorsA,
      factorsB,
      vectorA,
      vectorB,
      voltageA,
      voltageB,
      voltageProduct,
    });
  }, [inputA, inputB]);

  const calculateSymbolic = useCallback(() => {
    const expr = parseExpression(symbolicInput);
    if (expr) {
      const simplified = simplify(expr);
      const evaluated = evaluate(simplified, { x: 2, theta: Math.PI / 4 });
      const primeLink = linkToPrimeDomain(simplified);
      
      setSymbolicResult({
        expr,
        simplified,
        evaluated,
        latex: simplified.latex || '',
        primeVector: primeLink.primeVector,
        logDomainValue: primeLink.logDomainValue,
        analogVoltage: primeLink.analogVoltage,
      });
    }
  }, [symbolicInput]);

  const formatFactors = (factors: Map<number, number>): string => {
    const entries: string[] = [];
    for (const [prime, exp] of factors) {
      entries.push(`${prime}^${exp}`);
    }
    return entries.join(' × ') || '1';
  };

  const symbolCategories = useMemo(() => {
    return Array.from(SYMBOLS_BY_CATEGORY.keys());
  }, []);

  const currentSymbols = useMemo(() => {
    return SYMBOLS_BY_CATEGORY.get(selectedSymbolCategory) || [];
  }, [selectedSymbolCategory]);

  const insertSymbol = (symbol: MathSymbol) => {
    setSymbolicInput(prev => prev + ' ' + symbol.name);
  };

  return (
    <div className="bg-slate-900 rounded-lg p-4 border border-slate-700">
      <h3 className="text-sm font-semibold text-slate-200 mb-4">
        Prime Domain Calculator <span className="text-xs text-slate-500">({MATH_SYMBOLS.length} symbols)</span>
      </h3>
      
      {/* Tabs */}
      <div className="flex border-b border-slate-700 mb-4">
        {[
          { id: 'numeric', label: 'Numeric' },
          { id: 'symbolic', label: 'Symbolic Math' },
          { id: 'symbols', label: 'Symbol Library' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`px-4 py-2 text-sm transition-colors ${
              activeTab === tab.id
                ? 'text-blue-400 border-b-2 border-blue-500'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'numeric' && (
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="text-xs text-slate-400 block mb-1">Input A</label>
              <input
                type="number"
                value={inputA}
                onChange={(e) => setInputA(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-600 rounded text-slate-200 text-sm"
              />
            </div>
            <div className="flex-1">
              <label className="text-xs text-slate-400 block mb-1">Input B</label>
              <input
                type="number"
                value={inputB}
                onChange={(e) => setInputB(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-600 rounded text-slate-200 text-sm"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={calculateNumeric}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-sm font-medium transition-colors"
              >
                Calculate
              </button>
            </div>
          </div>
          
          {numericResult && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-800 rounded p-3">
                  <h4 className="text-xs text-slate-400 mb-2">Standard Multiplication</h4>
                  <p className="text-lg font-mono text-emerald-400">
                    {inputA} × {inputB} = {numericResult.product}
                  </p>
                </div>
                
                <div className="bg-slate-800 rounded p-3">
                  <h4 className="text-xs text-slate-400 mb-2">Log-Domain (Analog PPU)</h4>
                  <p className="text-lg font-mono text-amber-400">
                    exp(log({inputA}) + log({inputB})) = {numericResult.logProduct.toFixed(2)}
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-800 rounded p-3">
                  <h4 className="text-xs text-slate-400 mb-2">Prime Factorization A</h4>
                  <p className="text-sm font-mono text-blue-400">{formatFactors(numericResult.factorsA)}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Vector: [{numericResult.vectorA.slice(0, 8).join(', ')}...]
                  </p>
                </div>
                
                <div className="bg-slate-800 rounded p-3">
                  <h4 className="text-xs text-slate-400 mb-2">Prime Factorization B</h4>
                  <p className="text-sm font-mono text-blue-400">{formatFactors(numericResult.factorsB)}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Vector: [{numericResult.vectorB.slice(0, 8).join(', ')}...]
                  </p>
                </div>
              </div>
              
              <div className="bg-slate-800 rounded p-3">
                <h4 className="text-xs text-slate-400 mb-2">Analog Voltage Representation</h4>
                <div className="flex items-center gap-4 text-sm">
                  <span className="font-mono text-purple-400">V<sub>A</sub> = {numericResult.voltageA.toFixed(2)}V</span>
                  <span className="text-slate-500">×</span>
                  <span className="font-mono text-purple-400">V<sub>B</sub> = {numericResult.voltageB.toFixed(2)}V</span>
                  <span className="text-slate-500">=</span>
                  <span className="font-mono text-rose-400">V<sub>out</sub> = {numericResult.voltageProduct.toFixed(2)}V</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'symbolic' && (
        <div className="space-y-4">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Symbolic Expression</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={symbolicInput}
                onChange={(e) => setSymbolicInput(e.target.value)}
                placeholder="e.g., pi * x + sin(theta)"
                className="flex-1 px-3 py-2 bg-slate-800 border border-slate-600 rounded text-slate-200 text-sm font-mono"
              />
              <button
                onClick={calculateSymbolic}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-sm font-medium transition-colors"
              >
                Evaluate
              </button>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Supported: +, *, sin(), cos(), exp(), ln(), sqrt(), constants (pi, e), variables (x, theta)
            </p>
          </div>

          {/* Quick symbol buttons */}
          <div className="flex flex-wrap gap-1">
            {['pi', 'e', 'phi', 'x', 'theta', 'sin', 'cos', 'exp', 'ln', 'sqrt'].map(s => (
              <button
                key={s}
                onClick={() => setSymbolicInput(prev => prev + (prev ? ' ' : '') + s)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs"
              >
                {s}
              </button>
            ))}
          </div>
          
          {symbolicResult && (
            <div className="space-y-3">
              <div className="bg-slate-800 rounded p-3">
                <h4 className="text-xs text-slate-400 mb-2">LaTeX Representation</h4>
                <code className="text-sm font-mono text-emerald-400 block bg-slate-900 p-2 rounded">
                  ${symbolicResult.latex}$
                </code>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-800 rounded p-3">
                  <h4 className="text-xs text-slate-400 mb-2">Evaluated (x=2, θ=π/4)</h4>
                  <p className="text-lg font-mono text-blue-400">{symbolicResult.evaluated.toFixed(6)}</p>
                </div>
                
                <div className="bg-slate-800 rounded p-3">
                  <h4 className="text-xs text-slate-400 mb-2">Prime Vector</h4>
                  <p className="text-sm font-mono text-purple-400">
                    [{symbolicResult.primeVector.slice(0, 8).join(', ')}...]
                  </p>
                </div>
              </div>
              
              <div className="bg-slate-800 rounded p-3">
                <h4 className="text-xs text-slate-400 mb-2">Log-Domain & Voltage</h4>
                <div className="flex items-center gap-4 text-sm">
                  <span className="font-mono text-amber-400">log(val) = {symbolicResult.logDomainValue.toFixed(4)}</span>
                  <span className="text-slate-500">|</span>
                  <span className="font-mono text-rose-400">V = {symbolicResult.analogVoltage.toFixed(2)}V</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'symbols' && (
        <div className="space-y-4">
          {/* Category selector */}
          <div className="flex flex-wrap gap-2">
            {symbolCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedSymbolCategory(cat)}
                className={`px-3 py-1 rounded text-xs capitalize transition-colors ${
                  selectedSymbolCategory === cat
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat} ({SYMBOLS_BY_CATEGORY.get(cat)?.length || 0})
              </button>
            ))}
          </div>
          
          {/* Symbol grid */}
          <div className="bg-slate-800 rounded p-3 max-h-64 overflow-auto">
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {currentSymbols.map(sym => (
                <button
                  key={sym.name}
                  onClick={() => insertSymbol(sym)}
                  title={sym.description}
                  className="p-2 bg-slate-900 hover:bg-slate-700 rounded text-center transition-colors group"
                >
                  <span className="text-lg block">{sym.unicode}</span>
                  <span className="text-[10px] text-slate-500 group-hover:text-slate-300">{sym.name}</span>
                </button>
              ))}
            </div>
          </div>
          
          {/* Symbol info */}
          <div className="text-xs text-slate-500">
            Total symbols: {MATH_SYMBOLS.length} | 
            Constants: {SYMBOLS_BY_CATEGORY.get('constant')?.length || 0} | 
            Variables: {SYMBOLS_BY_CATEGORY.get('variable')?.length || 0} | 
            Operators: {SYMBOLS_BY_CATEGORY.get('operator')?.length || 0} | 
            Functions: {SYMBOLS_BY_CATEGORY.get('function')?.length || 0}
          </div>
        </div>
      )}
      
      <div className="mt-4 pt-4 border-t border-slate-700">
        <h4 className="text-xs text-slate-400 mb-2">Prime Reference</h4>
        <div className="flex flex-wrap gap-1">
          {PRIMES.slice(0, 16).map((p, i) => (
            <span key={p} className="px-2 py-1 bg-slate-800 rounded text-xs font-mono text-slate-300">
              p<sub>{i + 1}</sub>={p}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
