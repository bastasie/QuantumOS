/**
 * Natural Language to PPU Translator Component v2
 * Uses dictionary + selector to interpret meaning and translate to working code
 */

import React, { useState, useEffect } from 'react';
import { MessageSquare, Sparkles, Plus, X, Download, Play, Check, AlertCircle, BookOpen } from 'lucide-react';
import { getNLTranslatorV2, type TranslationResult } from '@/lib/nl-to-ppu-v2';
import { getPoetryDictionary, type PoetryWord } from '@/lib/poetry-dictionary';
import { useDynamicTabs } from '@/hooks/useDynamicTabs';

interface NLToPPUTranslatorProps {
  dynamicTabs: ReturnType<typeof useDynamicTabs>;
}

const EXAMPLE_COMMANDS = [
  'draw a red circle at 256 256 with size 50',
  'draw a blue square at 100 100',
  'draw a green triangle at center',
  'calculate 42 plus 58',
  'calculate 12 times 15',
  'set x to 100',
  'print hello world',
  'animate the circle moving',
  'set coherence to 78',
  'clear all graphics',
];

export const NLToPPUTranslator: React.FC<NLToPPUTranslatorProps> = ({ dynamicTabs }) => {
  const [input, setInput] = useState('');
  const [appName, setAppName] = useState('My NL App');
  const [commands, setCommands] = useState<string[]>([]);
  const [translation, setTranslation] = useState<TranslationResult | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [activeView, setActiveView] = useState<'input' | 'result'>('input');
  const [dictLoaded, setDictLoaded] = useState(false);
  const [dictSize, setDictSize] = useState(0);
  const [reconstructedWords, setReconstructedWords] = useState<PoetryWord[]>([]);
  
  const translator = getNLTranslatorV2();
  const poetryDict = getPoetryDictionary();
  
  // Load dictionary on mount
  useEffect(() => {
    poetryDict.load().then(() => {
      setDictLoaded(true);
      setDictSize(poetryDict.getSize());
    });
    translator.init();
  }, []);
  
  const handleAddCommand = () => {
    if (input.trim()) {
      setCommands([...commands, input.trim()]);
      setInput('');
    }
  };
  
  const handleRemoveCommand = (index: number) => {
    setCommands(commands.filter((_, i) => i !== index));
  };
  
  const handleTranslate = async () => {
    if (commands.length === 0) return;
    
    setIsTranslating(true);
    
    const allInput = commands.join('. ');
    const result = translator.translate(allInput);
    setTranslation(result);
    
    // Get reconstructed words
    const reconstructed = poetryDict.reconstructMeaning(allInput);
    setReconstructedWords(reconstructed);
    
    // Create new tab with ACTUAL WORKING CODE
    if (result.success) {
      dynamicTabs.addTab({
        title: appName,
        type: 'nlp-app',
        content: {
          code: result.generated.assembly,
          assembly: result.generated.assembly,
          bytecode: new Uint8Array(result.generated.bytecode),
          nlpInput: allInput,
          compiled: true,
          errors: [],
        },
      });
    }
    
    setActiveView('result');
    setIsTranslating(false);
  };
  
  const handleQuickTranslate = async (cmd: string) => {
    setInput(cmd);
    const result = translator.translate(cmd);
    setTranslation(result);
    
    const reconstructed = poetryDict.reconstructMeaning(cmd);
    setReconstructedWords(reconstructed);
    
    if (result.success) {
      dynamicTabs.addTab({
        title: `Quick: ${cmd.slice(0, 20)}...`,
        type: 'nlp-app',
        content: {
          code: result.generated.assembly,
          assembly: result.generated.assembly,
          bytecode: new Uint8Array(result.generated.bytecode),
          nlpInput: cmd,
          compiled: true,
          errors: [],
        },
      });
    }
    
    setActiveView('result');
  };
  
  const handleDownload = () => {
    if (!translation) return;
    
    const blob = new Blob([translation.generated.assembly], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${appName.replace(/\s+/g, '_')}.asm`;
    a.click();
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-purple-400" />
          <span className="text-sm font-semibold text-slate-200">NL → PPU (Dictionary + Selector)</span>
          <span className={`text-xs px-2 py-0.5 rounded ${dictLoaded ? 'bg-emerald-900 text-emerald-400' : 'bg-amber-900 text-amber-400'}`}>
            <BookOpen className="w-3 h-3 inline mr-1" />
            {dictLoaded ? `${dictSize} words` : 'Loading...'}
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={appName}
            onChange={(e) => setAppName(e.target.value)}
            placeholder="App name..."
            className="px-2 py-1 bg-slate-700 border border-slate-600 rounded text-xs text-slate-200 w-32"
          />
          <button
            onClick={handleTranslate}
            disabled={commands.length === 0 || isTranslating}
            className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 disabled:bg-slate-600 text-white rounded text-xs transition-colors"
          >
            {isTranslating ? (
              <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Sparkles className="w-3 h-3" />
            )}
            Translate
          </button>
        </div>
      </div>

      {activeView === 'input' ? (
        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-auto">
          {/* Command builder */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h4 className="text-xs text-slate-400 mb-2">Build Your App</h4>
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCommand()}
                placeholder="Enter natural language command..."
                className="flex-1 px-3 py-2 bg-slate-700 border border-slate-600 rounded text-sm text-slate-200"
              />
              <button
                onClick={handleAddCommand}
                className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Command list */}
          {commands.length > 0 && (
            <div className="bg-slate-800 rounded-lg p-4">
              <h4 className="text-xs text-slate-400 mb-2">Commands ({commands.length})</h4>
              <div className="space-y-2">
                {commands.map((cmd, i) => (
                  <div key={i} className="flex items-center justify-between bg-slate-700 rounded px-3 py-2">
                    <span className="text-sm text-slate-300">{cmd}</span>
                    <button
                      onClick={() => handleRemoveCommand(i)}
                      className="p-1 text-slate-400 hover:text-rose-400 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick examples */}
          <div className="bg-slate-800 rounded-lg p-4">
            <h4 className="text-xs text-slate-400 mb-2">Quick Examples (click to run)</h4>
            <div className="flex flex-wrap gap-2">
              {EXAMPLE_COMMANDS.map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => handleQuickTranslate(cmd)}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs transition-colors flex items-center gap-1"
                >
                  <Play className="w-3 h-3" />
                  {cmd}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-auto p-4 space-y-4">
          {/* Back button */}
          <button
            onClick={() => setActiveView('input')}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
          >
            ← Back to input
          </button>

          {translation && (
            <div className="space-y-4">
              {/* Success indicator */}
              <div className={`flex items-center gap-2 px-3 py-2 rounded ${
                translation.success 
                  ? 'bg-emerald-900/30 border border-emerald-700' 
                  : 'bg-rose-900/30 border border-rose-700'
              }`}>
                {translation.success ? (
                  <Check className="w-4 h-4 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-400" />
                )}
                <span className={translation.success ? 'text-emerald-400' : 'text-rose-400'}>
                  {translation.success 
                    ? `Translation successful! (${translation.generated.bytecode.length} bytes)` 
                    : 'Translation failed'}
                </span>
              </div>

              {/* Dictionary reconstruction */}
              {reconstructedWords.length > 0 && (
                <div className="bg-slate-800 rounded-lg p-4">
                  <h4 className="text-xs text-slate-400 mb-2">
                    Dictionary Reconstruction (Semantic Similarity)
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {reconstructedWords.map((word, i) => (
                      <div 
                        key={i}
                        className="px-3 py-2 bg-slate-700 rounded text-xs"
                        title={word.meaning}
                      >
                        <span className="text-amber-400">{word.arabic}</span>
                        <span className="text-slate-500 mx-1">|</span>
                        <span className="text-blue-400">{word.transliteration}</span>
                        <span className="text-slate-500 mx-1">=</span>
                        <span className="text-emerald-400">{word.english}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Execution plan */}
              <div className="bg-slate-800 rounded-lg p-4">
                <h4 className="text-xs text-slate-400 mb-2">Execution Plan</h4>
                <div className="space-y-1">
                  {translation.executionPlan.steps.map((step, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      <span className="text-slate-500">{i + 1}.</span>
                      <span className="text-slate-300">{step.description}</span>
                    </div>
                  ))}
                </div>
                <div className="mt-2 pt-2 border-t border-slate-700 text-xs text-slate-500">
                  Requires canvas: {translation.executionPlan.requiresCanvas ? 'Yes' : 'No'} | 
                  Estimated cycles: {translation.executionPlan.estimatedCycles} | 
                  Memory: {translation.executionPlan.memoryRequired} bytes
                </div>
              </div>

              {/* Generated Assembly */}
              <div className="bg-slate-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs text-slate-400">Generated PPU Assembly</h4>
                  <button
                    onClick={handleDownload}
                    className="flex items-center gap-1 px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs"
                  >
                    <Download className="w-3 h-3" />
                    Download .asm
                  </button>
                </div>
                <pre className="text-xs font-mono text-emerald-400 bg-slate-950 p-3 rounded overflow-auto max-h-48">
                  {translation.generated.assembly}
                </pre>
              </div>

              {/* Bytecode */}
              <div className="bg-slate-800 rounded-lg p-4">
                <h4 className="text-xs text-slate-400 mb-2">
                  Bytecode ({translation.generated.bytecode.length} bytes)
                </h4>
                <div className="text-xs font-mono text-slate-500 bg-slate-950 p-3 rounded overflow-auto max-h-32">
                  {translation.generated.bytecode.map((b, i) => (
                    <span key={i}>
                      {b.toString(16).padStart(2, '0').toUpperCase()}
                      {(i + 1) % 16 === 0 ? '\n' : ' '}
                    </span>
                  ))}
                </div>
              </div>

              {/* App created notice */}
              {translation.success && (
                <div className="bg-emerald-900/20 border border-emerald-700/50 rounded-lg p-4">
                  <h4 className="text-xs text-emerald-400 mb-1">✓ App Created Successfully!</h4>
                  <p className="text-xs text-slate-400">
                    The app has been added to the Apps tab. Go there to view the generated code 
                    and download the bytecode.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
