/**
 * Python-to-PPU Compiler Component
 * Compiles Python code to PPU Assembly with error fixing
 */

import React, { useState } from 'react';
import { Play, Wand2, FileCode, Cpu, Download, Check, AlertCircle } from 'lucide-react';
import { compilePythonToPPU, type CompileResult } from '@/lib/python-to-ppu-compiler';
import { useDynamicTabs } from '@/hooks/useDynamicTabs';

interface PythonToPPUCompilerProps {
  initialCode?: string;
  onCompile?: (result: CompileResult, tabId: string) => void;
  dynamicTabs: ReturnType<typeof useDynamicTabs>;
}

const DEFAULT_CODE = `# Example: Simple counter and pixel drawing
x = 0
y = 128
color = 0xFF0000

for i in range(100):
    x = x + 1
    fbset(x, y, color)

# Calculate using log-domain multiplication
result = 12 * 15
print(result)

# Convert to prime domain
prime_val = prime(42)
print(prime_val)
`;

export const PythonToPPUCompiler: React.FC<PythonToPPUCompilerProps> = ({
  initialCode = DEFAULT_CODE,
  onCompile,
  dynamicTabs,
}) => {
  const [code, setCode] = useState(initialCode);
  const [result, setResult] = useState<CompileResult | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);
  const [showFixed, setShowFixed] = useState(false);

  const handleCompile = () => {
    setIsCompiling(true);
    
    // Compile
    const compileResult = compilePythonToPPU(code);
    setResult(compileResult);
    
    // Create new tab if successful
    if (compileResult.success) {
      const tabId = dynamicTabs.addTab({
        title: `PPU App ${dynamicTabs.tabs.length + 1}`,
        type: 'ppu-asm',
        content: {
          code: compileResult.fixed,
          assembly: compileResult.assembly,
          bytecode: compileResult.bytecode,
          compiled: true,
          errors: compileResult.errors,
          fixes: compileResult.fixes,
        },
      });
      
      onCompile?.(compileResult, tabId);
    }
    
    setIsCompiling(false);
  };

  const handleFixErrors = () => {
    const { fixed, fixes } = compilePythonToPPU(code);
    if (fixes.length > 0) {
      setCode(fixed);
      setShowFixed(true);
      setTimeout(() => setShowFixed(false), 3000);
    }
  };

  const handleDownloadBytecode = () => {
    if (!result?.bytecode) return;
    
    const bytes = result.bytecode;
    const array = Array.from(bytes);
    const blob = new Blob([new Uint8Array(array)], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ppu_program.bin';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadAssembly = () => {
    if (!result?.assembly) return;
    
    const blob = new Blob([result.assembly], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ppu_program.asm';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <FileCode className="w-5 h-5 text-blue-400" />
          <span className="text-sm font-semibold text-slate-200">Python → PPU Compiler</span>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={handleFixErrors}
            className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded text-xs transition-colors"
            title="Auto-fix common errors"
          >
            <Wand2 className="w-3 h-3" />
            Auto-Fix
          </button>
          
          <button
            onClick={handleCompile}
            disabled={isCompiling}
            className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-600 text-white rounded text-xs transition-colors"
          >
            {isCompiling ? (
              <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Play className="w-3 h-3" />
            )}
            Compile to PPU
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Code editor */}
        <div className="flex-1 flex flex-col border-r border-slate-700">
          <div className="px-3 py-1 bg-slate-800/50 text-xs text-slate-400">Python Source</div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="flex-1 p-4 bg-slate-950 text-slate-300 font-mono text-sm resize-none focus:outline-none"
            spellCheck={false}
            style={{ tabSize: 4 }}
          />
        </div>

        {/* Result panel */}
        <div className="flex-1 flex flex-col">
          <div className="px-3 py-1 bg-slate-800/50 text-xs text-slate-400">PPU Assembly Output</div>
          <div className="flex-1 overflow-auto p-4 bg-slate-950">
            {result ? (
              <div className="space-y-4">
                {/* Status */}
                <div className={`flex items-center gap-2 px-3 py-2 rounded ${
                  result.success ? 'bg-emerald-900/30 border border-emerald-700' : 'bg-rose-900/30 border border-rose-700'
                }`}>
                  {result.success ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                  )}
                  <span className={result.success ? 'text-emerald-400' : 'text-rose-400'}>
                    {result.success ? 'Compilation successful!' : 'Compilation failed'}
                  </span>
                </div>

                {/* Fixes applied */}
                {result.fixes.length > 0 && (
                  <div className="bg-amber-900/20 border border-amber-700/50 rounded p-3">
                    <h4 className="text-xs text-amber-400 mb-2">Auto-fixes applied:</h4>
                    <ul className="text-xs text-slate-300 space-y-1">
                      {result.fixes.map((fix, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <Check className="w-3 h-3 text-emerald-400" />
                          {fix}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Errors */}
                {result.errors.length > 0 && (
                  <div className="bg-rose-900/20 border border-rose-700/50 rounded p-3">
                    <h4 className="text-xs text-rose-400 mb-2">Errors:</h4>
                    <ul className="text-xs text-slate-300 space-y-1">
                      {result.errors.map((err, i) => (
                        <li key={i} className="text-rose-300">{err}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Assembly output */}
                {result.assembly && (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-xs text-slate-400">Generated Assembly</h4>
                      <div className="flex gap-1">
                        <button
                          onClick={handleDownloadAssembly}
                          className="flex items-center gap-1 px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs"
                        >
                          <Download className="w-3 h-3" />
                          .asm
                        </button>
                        <button
                          onClick={handleDownloadBytecode}
                          className="flex items-center gap-1 px-2 py-1 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs"
                        >
                          <Cpu className="w-3 h-3" />
                          .bin
                        </button>
                      </div>
                    </div>
                    <pre className="text-xs font-mono text-emerald-400 bg-slate-900 p-3 rounded overflow-auto max-h-64">
                      {result.assembly}
                    </pre>
                  </div>
                )}

                {/* Bytecode info */}
                {result.bytecode && (
                  <div>
                    <h4 className="text-xs text-slate-400 mb-2">Bytecode ({result.bytecode.length} bytes)</h4>
                    <div className="text-xs font-mono text-slate-500 bg-slate-900 p-3 rounded overflow-auto max-h-32">
                      {Array.from(result.bytecode)
                        .map((b) => b.toString(16).padStart(2, '0'))
                        .join(' ')}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-slate-500 text-sm text-center py-8">
                Enter Python code and click Compile to generate PPU assembly
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Fixed notification */}
      {showFixed && (
        <div className="absolute bottom-4 right-4 bg-emerald-600 text-white px-4 py-2 rounded shadow-lg animate-in fade-in slide-in-from-bottom-4">
          Code auto-fixed!
        </div>
      )}
    </div>
  );
};
