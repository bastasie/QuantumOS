/**
 * Natural Language Executor Component
 * Live execution of natural language with visual results
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Terminal, 
  Play, 
  RotateCcw, 
  Download, 
  Image as ImageIcon,
  Type,
  Calculator,
  Palette,
  Activity,
  Check,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { executeCommand, createExecutionContext, type ExecutionResult, type ExecutionContext } from '@/lib/nl-executor';
import { parseNaturalLanguage } from '@/lib/matrix-grammar';
import { getVocabularyStats } from '@/lib/matrix-vocabulary';

const EXAMPLE_COMMANDS = [
  'draw a red circle at 256 256 with size 50',
  'calculate 42 plus 58',
  'set coherence to 78',
  'draw a blue square at 100 100',
  'print hello world',
  'create variable x with value 100',
  'animate the circle rotating',
  'clear all graphics',
  'draw triangle at center with color green',
  'multiply 12 times 15',
];

export const NLExecutor: React.FC = () => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<Array<{ input: string; results: ExecutionResult[] }>>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [activeTab, setActiveTab] = useState<'input' | 'visualization' | 'bytecode'>('input');
  const [parsedInfo, setParsedInfo] = useState<ReturnType<typeof parseNaturalLanguage> | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const contextRef = useRef<ExecutionContext | null>(null);
  const animationRef = useRef<number | null>(null);
  
  const vocabStats = getVocabularyStats();
  
  // Initialize execution context
  useEffect(() => {
    if (canvasRef.current && !contextRef.current) {
      contextRef.current = createExecutionContext(canvasRef.current);
      
      // Set canvas size
      const canvas = canvasRef.current;
      const rect = canvas.parentElement?.getBoundingClientRect();
      if (rect) {
        canvas.width = rect.width;
        canvas.height = rect.height;
      }
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);
  
  // Parse input in real-time
  useEffect(() => {
    if (input.trim()) {
      const parsed = parseNaturalLanguage(input);
      setParsedInfo(parsed);
    } else {
      setParsedInfo(null);
    }
  }, [input]);
  
  const handleExecute = useCallback(() => {
    if (!input.trim() || !contextRef.current) return;
    
    setIsExecuting(true);
    
    // Execute command
    const result = executeCommand(input, contextRef.current);
    
    // Add to history
    setHistory(prev => [...prev, { input, results: [result] }]);
    
    // Clear input
    setInput('');
    setIsExecuting(false);
  }, [input]);
  
  const handleExecuteExample = useCallback((cmd: string) => {
    setInput(cmd);
    // Auto-execute after a short delay
    setTimeout(() => {
      if (contextRef.current) {
        const result = executeCommand(cmd, contextRef.current);
        setHistory(prev => [...prev, { input: cmd, results: [result] }]);
      }
    }, 100);
  }, []);
  
  const handleClear = useCallback(() => {
    if (contextRef.current) {
      executeCommand('clear all', contextRef.current);
    }
    setHistory([]);
    
    // Clear canvas
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }, []);
  
  const handleDownload = useCallback(() => {
    // Download execution history as JSON
    const data = {
      history,
      timestamp: Date.now(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nl_execution_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [history]);
  
  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span className="text-sm font-semibold text-slate-200">Natural Language Executor</span>
          <span className="text-xs text-slate-500 ml-2">
            {vocabStats.total.toLocaleString()} words
          </span>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={handleClear}
            className="flex items-center gap-1 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            Clear
          </button>
          <button
            onClick={handleDownload}
            disabled={history.length === 0}
            className="flex items-center gap-1 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-slate-300 rounded text-xs transition-colors"
          >
            <Download className="w-3 h-3" />
            Save
          </button>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left panel - Input and History */}
        <div className="flex-1 flex flex-col border-r border-slate-700 min-w-0">
          {/* Tabs */}
          <div className="flex border-b border-slate-700">
            {[
              { id: 'input', label: 'Input', icon: Type },
              { id: 'visualization', label: 'Visualization', icon: ImageIcon },
              { id: 'bytecode', label: 'Bytecode', icon: Terminal },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-1 px-4 py-2 text-xs transition-colors ${
                  activeTab === tab.id
                    ? 'bg-slate-700 text-white border-b-2 border-blue-500'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <tab.icon className="w-3 h-3" />
                {tab.label}
              </button>
            ))}
          </div>
          
          {/* Tab content */}
          <div className="flex-1 overflow-auto p-4">
            {activeTab === 'input' && (
              <div className="space-y-4">
                {/* Input area */}
                <div className="bg-slate-800 rounded-lg p-4">
                  <label className="text-xs text-slate-400 mb-2 block">
                    Enter natural language command
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleExecute()}
                      placeholder="e.g., draw a red circle at 256 256 with size 50"
                      className="flex-1 px-3 py-2 bg-slate-900 border border-slate-600 rounded text-sm text-slate-200"
                    />
                    <button
                      onClick={handleExecute}
                      disabled={!input.trim() || isExecuting}
                      className="flex items-center gap-1 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-600 text-white rounded text-sm transition-colors"
                    >
                      {isExecuting ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                      Run
                    </button>
                  </div>
                  
                  {/* Real-time parsing info */}
                  {parsedInfo && (
                    <div className="mt-3 p-3 bg-slate-900 rounded text-xs">
                      <div className="flex items-center gap-4 text-slate-400">
                        <span>Structure: <span className="text-blue-400">{parsedInfo.structure}</span></span>
                        <span>Action: <span className="text-emerald-400">{parsedInfo.output.action}</span></span>
                        <span>Confidence: <span className="text-amber-400">{(parsedInfo.output.confidence * 100).toFixed(0)}%</span></span>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {parsedInfo.tokens.map((t, i) => (
                          <span
                            key={i}
                            className={`px-2 py-0.5 rounded text-[10px] ${
                              t.category === 'verb' ? 'bg-emerald-900/50 text-emerald-400' :
                              t.category === 'noun' ? 'bg-blue-900/50 text-blue-400' :
                              t.category === 'adjective' ? 'bg-purple-900/50 text-purple-400' :
                              t.category === 'number' ? 'bg-amber-900/50 text-amber-400' :
                              'bg-slate-700 text-slate-400'
                            }`}
                          >
                            {t.word}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Example commands */}
                <div className="bg-slate-800 rounded-lg p-4">
                  <label className="text-xs text-slate-400 mb-2 block">Quick Examples</label>
                  <div className="flex flex-wrap gap-2">
                    {EXAMPLE_COMMANDS.map((cmd) => (
                      <button
                        key={cmd}
                        onClick={() => handleExecuteExample(cmd)}
                        className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs transition-colors"
                      >
                        {cmd}
                      </button>
                    ))}
                  </div>
                </div>
                
                {/* Execution history */}
                {history.length > 0 && (
                  <div className="bg-slate-800 rounded-lg p-4">
                    <label className="text-xs text-slate-400 mb-2 block">
                      Execution History ({history.length} commands)
                    </label>
                    <div className="space-y-2 max-h-64 overflow-auto">
                      {history.map((item, i) => (
                        <div key={i} className="bg-slate-900 rounded p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs text-slate-500">#{i + 1}</span>
                            <span className="text-sm text-slate-300 font-mono">{item.input}</span>
                          </div>
                          {item.results.map((result, j) => (
                            <div key={j} className="mt-1">
                              {result.output.map((line, k) => (
                                <div key={k} className="flex items-center gap-2 text-xs">
                                  {result.success ? (
                                    <Check className="w-3 h-3 text-emerald-400" />
                                  ) : (
                                    <AlertCircle className="w-3 h-3 text-rose-400" />
                                  )}
                                  <span className="text-emerald-400">{line}</span>
                                </div>
                              ))}
                              {result.error && (
                                <div className="text-xs text-rose-400 mt-1">{result.error}</div>
                              )}
                            </div>
                          ))}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'visualization' && (
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-slate-400">Visual Output</span>
                  <div className="flex gap-2 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <Palette className="w-3 h-3" />
                      {contextRef.current?.graphics.length || 0} objects
                    </span>
                  </div>
                </div>
                <div className="flex-1 bg-black rounded-lg overflow-hidden relative">
                  <canvas
                    ref={canvasRef}
                    className="w-full h-full"
                    style={{ imageRendering: 'pixelated' }}
                  />
                  {history.length === 0 && (
                    <div className="absolute inset-0 flex items-center justify-center text-slate-600">
                      <div className="text-center">
                        <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">Execute commands to see visual output</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {activeTab === 'bytecode' && (
              <div className="space-y-4">
                {parsedInfo?.output.ppuBytecode && (
                  <div className="bg-slate-800 rounded-lg p-4">
                    <label className="text-xs text-slate-400 mb-2 block">Generated PPU Bytecode</label>
                    <div className="bg-slate-950 p-3 rounded font-mono text-xs">
                      <div className="text-slate-500 mb-2">
                        ; {parsedInfo.input}
                      </div>
                      <div className="text-emerald-400">
                        {parsedInfo.output.ppuBytecode.map((b, i) => (
                          <span key={i}>
                            {b.toString(16).padStart(2, '0').toUpperCase()}
                            {(i + 1) % 8 === 0 ? '\n' : ' '}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="bg-slate-800 rounded-lg p-4">
                  <label className="text-xs text-slate-400 mb-2 block">Vocabulary Coverage</label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {Object.entries(vocabStats.byCategory).map(([cat, count]) => (
                      <div key={cat} className="flex justify-between bg-slate-900 rounded px-2 py-1">
                        <span className="text-slate-400 capitalize">{cat}</span>
                        <span className="text-slate-200">{count.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Right panel - Stats */}
        <div className="w-64 bg-slate-800/50 border-l border-slate-700 p-4 hidden lg:block">
          <h4 className="text-xs text-slate-400 mb-3 flex items-center gap-2">
            <Activity className="w-3 h-3" />
            Execution Stats
          </h4>
          
          <div className="space-y-3">
            <div className="bg-slate-800 rounded p-3">
              <div className="text-xs text-slate-500">Commands Executed</div>
              <div className="text-2xl font-mono text-white">{history.length}</div>
            </div>
            
            <div className="bg-slate-800 rounded p-3">
              <div className="text-xs text-slate-500">Graphics Objects</div>
              <div className="text-2xl font-mono text-emerald-400">
                {contextRef.current?.graphics.length || 0}
              </div>
            </div>
            
            <div className="bg-slate-800 rounded p-3">
              <div className="text-xs text-slate-500">Variables</div>
              <div className="text-2xl font-mono text-blue-400">
                {contextRef.current?.variables.size || 0}
              </div>
            </div>
            
            <div className="bg-slate-800 rounded p-3">
              <div className="text-xs text-slate-500">PPU Coherence</div>
              <div className="text-2xl font-mono text-purple-400">
                {(contextRef.current?.ppu.coherence || 0).toFixed(2)}
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-slate-700">
            <h4 className="text-xs text-slate-400 mb-2">Supported Commands</h4>
            <div className="space-y-1 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <Palette className="w-3 h-3" />
                draw, paint, sketch
              </div>
              <div className="flex items-center gap-2">
                <Calculator className="w-3 h-3" />
                calculate, add, multiply
              </div>
              <div className="flex items-center gap-2">
                <Type className="w-3 h-3" />
                print, show, display
              </div>
              <div className="flex items-center gap-2">
                <Activity className="w-3 h-3" />
                animate, rotate, move
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
