/**
 * Dynamic Tab Panel Component
 * Shows all instantiated apps in tabs
 */

import React from 'react';
import { X, Cpu, FileCode, MessageSquare, Eye } from 'lucide-react';
import { useDynamicTabs, type TabType } from '@/hooks/useDynamicTabs';

interface DynamicTabPanelProps {
  dynamicTabs: ReturnType<typeof useDynamicTabs>;
}

const TAB_ICONS: Record<TabType, React.ElementType> = {
  python: FileCode,
  'ppu-asm': Cpu,
  'nlp-app': MessageSquare,
  visualization: Eye,
  custom: Cpu,
};

const TAB_COLORS: Record<TabType, string> = {
  python: 'text-blue-400',
  'ppu-asm': 'text-emerald-400',
  'nlp-app': 'text-purple-400',
  visualization: 'text-amber-400',
  custom: 'text-slate-400',
};

export const DynamicTabPanel: React.FC<DynamicTabPanelProps> = ({ dynamicTabs }) => {
  const { tabs, activeTabId, setActiveTab, removeTab, getTab } = dynamicTabs;

  if (tabs.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500">
        <div className="text-center">
          <Cpu className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No apps instantiated yet</p>
          <p className="text-sm mt-2">Compile Python or translate NL to create apps</p>
        </div>
      </div>
    );
  }

  const activeTab = activeTabId ? getTab(activeTabId) : null;

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
      {/* Tab bar */}
      <div className="flex items-center bg-slate-800 border-b border-slate-700 overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = TAB_ICONS[tab.type];
          const isActive = tab.id === activeTabId;
          
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 text-sm whitespace-nowrap transition-colors border-r border-slate-700 ${
                isActive
                  ? 'bg-slate-700 text-white'
                  : 'text-slate-400 hover:bg-slate-700/50 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${TAB_COLORS[tab.type]}`} />
              <span className="max-w-32 truncate">{tab.title}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeTab(tab.id);
                }}
                className="ml-1 p-0.5 hover:bg-slate-600 rounded"
              >
                <X className="w-3 h-3" />
              </button>
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-auto p-4">
        {activeTab ? (
          <div className="space-y-4">
            {/* Tab header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {(() => {
                  const Icon = TAB_ICONS[activeTab.type];
                  return <Icon className={`w-5 h-5 ${TAB_COLORS[activeTab.type]}`} />;
                })()}
                <h3 className="text-lg font-semibold text-slate-200">{activeTab.title}</h3>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>Type: {activeTab.type}</span>
                <span>•</span>
                <span>Created: {new Date(activeTab.createdAt).toLocaleTimeString()}</span>
              </div>
            </div>

            {/* Content based on type */}
            {activeTab.content.assembly && (
              <div className="bg-slate-800 rounded-lg p-4">
                <h4 className="text-xs text-slate-400 mb-2">PPU Assembly</h4>
                <pre className="text-xs font-mono text-emerald-400 bg-slate-950 p-4 rounded overflow-auto max-h-96">
                  {activeTab.content.assembly}
                </pre>
              </div>
            )}

            {activeTab.content.bytecode && (
              <div className="bg-slate-800 rounded-lg p-4">
                <h4 className="text-xs text-slate-400 mb-2">
                  Bytecode ({activeTab.content.bytecode.length} bytes)
                </h4>
                <div className="text-xs font-mono text-slate-500 bg-slate-950 p-4 rounded overflow-auto max-h-48">
                  {Array.from(activeTab.content.bytecode)
                    .map((b, i) => (
                      <span key={i}>
                        {b.toString(16).padStart(2, '0')}
                        {(i + 1) % 16 === 0 ? '\n' : ' '}
                      </span>
                    ))}
                </div>
              </div>
            )}

            {activeTab.content.nlpInput && (
              <div className="bg-slate-800 rounded-lg p-4">
                <h4 className="text-xs text-slate-400 mb-2">Original Input</h4>
                <p className="text-sm text-slate-300">{activeTab.content.nlpInput}</p>
              </div>
            )}

            {activeTab.content.fixes && activeTab.content.fixes.length > 0 && (
              <div className="bg-amber-900/20 border border-amber-700/50 rounded-lg p-4">
                <h4 className="text-xs text-amber-400 mb-2">Auto-fixes Applied</h4>
                <ul className="text-xs text-slate-300 space-y-1">
                  {activeTab.content.fixes.map((fix, i) => (
                    <li key={i}>• {fix}</li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab.content.errors && activeTab.content.errors.length > 0 && (
              <div className="bg-rose-900/20 border border-rose-700/50 rounded-lg p-4">
                <h4 className="text-xs text-rose-400 mb-2">Errors</h4>
                <ul className="text-xs text-rose-300 space-y-1">
                  {activeTab.content.errors.map((err, i) => (
                    <li key={i}>• {err}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Download buttons */}
            <div className="flex gap-2">
              {activeTab.content.assembly && (
                <button
                  onClick={() => {
                    const blob = new Blob([activeTab.content.assembly!], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${activeTab.title.replace(/\s+/g, '_')}.asm`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs"
                >
                  Download .asm
                </button>
              )}
              {activeTab.content.bytecode && (
                <button
                  onClick={() => {
                    const bytes = activeTab.content.bytecode!;
                    const array = Array.from(bytes);
                    const blob = new Blob([new Uint8Array(array)], { type: 'application/octet-stream' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${activeTab.title.replace(/\s+/g, '_')}.bin`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs"
                >
                  Download .bin
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-500">
            Select a tab to view its content
          </div>
        )}
      </div>
    </div>
  );
};
