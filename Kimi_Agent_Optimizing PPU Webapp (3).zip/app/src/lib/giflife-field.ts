/**
 * GIFLife Field - Reaction-Diffusion Simulation Engine
 * The visual "screen" that doubles as a computational substrate
 * Integrates with PPU for coherent pattern generation
 */

import type { GIFLifeConfig, FieldSnapshot } from '@/types';
import type { PPUState } from '@/types';
import { getRDParameters } from './ppu-core';

// ============================================
// Constants
// ============================================

export const DEFAULT_CONFIG: GIFLifeConfig = {
  width: 256,
  height: 256,
  feedRate: 0.032,
  killRate: 0.053,
  diffusionA: 1.0,
  diffusionB: 0.55,
  diffusionC: 0.35,
  timeStep: 1.0,
};

// ============================================
// GIFLife Field Class
// ============================================

export class GIFLifeField {
  private width: number;
  private height: number;
  
  // Three-component reaction-diffusion fields
  private fieldA: Float32Array;
  private fieldB: Float32Array;
  private fieldC: Float32Array;
  
  // Double buffering
  private fieldA2: Float32Array;
  private fieldB2: Float32Array;
  private fieldC2: Float32Array;
  
  // Image data for rendering
  private imageData: ImageData;
  
  // Cache pointer for text burning
  private cachePtr: number = 0;
  
  constructor(canvasWidth: number, canvasHeight: number, _config?: Partial<GIFLifeConfig>) {
    // Calculate grid size based on canvas
    const target = Math.floor(Math.min(canvasWidth, canvasHeight) * 0.85);
    const gw = Math.max(170, Math.min(target, 300));
    const gh = Math.max(170, Math.min(Math.floor(target * (canvasHeight / canvasWidth)), 520));
    
    this.width = gw;
    this.height = gh;
    
    const size = gw * gh;
    this.fieldA = new Float32Array(size);
    this.fieldB = new Float32Array(size);
    this.fieldC = new Float32Array(size);
    this.fieldA2 = new Float32Array(size);
    this.fieldB2 = new Float32Array(size);
    this.fieldC2 = new Float32Array(size);
    
    this.imageData = new ImageData(gw, gh);
    
    this.initialize();
  }
  
  // ============================================
  // Initialization
  // ============================================
  
  private initialize(): void {
    const size = this.width * this.height;
    
    // Random initial conditions
    for (let i = 0; i < size; i++) {
      this.fieldA[i] = 0.12 + 0.1 * Math.random();
      this.fieldB[i] = 0.08 + 0.1 * Math.random();
      this.fieldC[i] = 0.05 + 0.1 * Math.random();
    }
    
    // Add some initial splashes
    for (let k = 0; k < 10; k++) {
      this.splash(
        Math.random() * this.width,
        Math.random() * this.height,
        16 + Math.random() * 45,
        1.0
      );
    }
  }
  
  // ============================================
  // Core Simulation Step
  // ============================================
  
  step(ppu: PPUState, dt: number): void {
    // Get PPU-modulated parameters
    const params = getRDParameters(ppu);
    
    const { feed, kill, diffusionA, diffusionB, diffusionC } = params;
    const smooth = ppu.smooth;
    
    const w = this.width;
    const h = this.height;
    
    // Reaction-diffusion with 3 components
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        
        const a = this.fieldA[i];
        const b = this.fieldB[i];
        const c = this.fieldC[i];
        
        // Laplacian
        const la = this.laplacian(this.fieldA, x, y);
        const lb = this.laplacian(this.fieldB, x, y);
        const lc = this.laplacian(this.fieldC, x, y);
        
        // Reaction term
        const ab2 = a * b * b;
        
        // Update with PPU smoothing
        let na = a + (diffusionA * la - ab2 + feed * (1 - a)) * dt;
        let nb = b + (diffusionB * lb + ab2 - (kill + feed) * b) * dt;
        let nc = c + (diffusionC * lc + 0.10 * ab2 - 0.06 * c) * dt;
        
        // Apply smoothing and clamp
        this.fieldA2[i] = this.clamp((1 - smooth) * na + smooth * a, 0, 1);
        this.fieldB2[i] = this.clamp((1 - smooth) * nb + smooth * b, 0, 1);
        this.fieldC2[i] = this.clamp((1 - smooth) * nc + smooth * c, 0, 1);
      }
    }
    
    // Swap buffers
    [this.fieldA, this.fieldA2] = [this.fieldA2, this.fieldA];
    [this.fieldB, this.fieldB2] = [this.fieldB2, this.fieldB];
    [this.fieldC, this.fieldC2] = [this.fieldC2, this.fieldC];
  }
  
  // ============================================
  // Laplacian (5-point stencil)
  // ============================================
  
  private laplacian(field: Float32Array, x: number, y: number): number {
    const w = this.width;
    const i = y * w + x;
    const v = field[i];
    return field[i - 1] + field[i + 1] + field[i - w] + field[i + w] - 4 * v;
  }
  
  // ============================================
  // Splash (add energy to field)
  // ============================================
  
  splash(x: number, y: number, radius: number, strength: number): void {
    const gx = Math.floor(x);
    const gy = Math.floor(y);
    const rr = Math.max(2, Math.floor(radius));
    const r2 = rr * rr;
    
    const w = this.width;
    const h = this.height;
    
    for (let py = gy - rr; py <= gy + rr; py++) {
      if (py < 1 || py >= h - 1) continue;
      
      for (let px = gx - rr; px <= gx + rr; px++) {
        if (px < 1 || px >= w - 1) continue;
        
        const dx = px - gx;
        const dy = py - gy;
        const d2 = dx * dx + dy * dy;
        
        if (d2 > r2) continue;
        
        const bump = strength * (1 - d2 / r2);
        const i = py * w + px;
        
        this.fieldA[i] = this.clamp(this.fieldA[i] + 0.35 * bump, 0, 1);
        this.fieldB[i] = this.clamp(this.fieldB[i] + 0.25 * bump, 0, 1);
        this.fieldC[i] = this.clamp(this.fieldC[i] + 0.15 * bump, 0, 1);
      }
    }
  }
  
  // ============================================
  // Text Burning (cache text into field)
  // ============================================
  
  burnCache(text: string): void {
    if (!text) return;
    
    const encoder = new TextEncoder();
    const bytes = encoder.encode(text.slice(0, 8192));
    
    const stripH = Math.max(18, Math.floor(this.height * 0.06));
    const y0 = this.height - stripH;
    const w = this.width;
    
    for (let i = 0; i < bytes.length; i++) {
      const b = bytes[i];
      const x = (this.cachePtr + i) % w;
      const y = y0 + Math.floor((this.cachePtr + i) / w) % stripH;
      const j = y * w + x;
      
      this.fieldA[j] = (b & 0xFF) / 255;
      this.fieldB[j] = ((b * 37) & 0xFF) / 255;
      this.fieldC[j] = ((b * 91) & 0xFF) / 255;
    }
    
    this.cachePtr = (this.cachePtr + bytes.length) % (w * stripH);
  }
  
  // ============================================
  // Rendering
  // ============================================
  
  render(ppu: PPUState): ImageData {
    const w = this.width;
    const h = this.height;
    const data = this.imageData.data;
    
    // Hue modulation from PPO poles
    const hue = 0.5 + 0.35 * Math.sin(0.9 * ppu.poles[0] + 0.4 * ppu.poles[3]);
    
    for (let i = 0; i < w * h; i++) {
      const a = this.fieldA[i];
      const b = this.fieldB[i];
      const c = this.fieldC[i];
      
      // Color mapping with PPU hue modulation
      const r = Math.floor(this.clamp(255 * (0.10 + 0.90 * a), 0, 255));
      const g = Math.floor(this.clamp(255 * (0.08 + 0.85 * (hue * b + (1 - hue) * c)), 0, 255));
      const bb = Math.floor(this.clamp(255 * (0.06 + 0.90 * (0.6 * c + 0.4 * b)), 0, 255));
      
      const p = i * 4;
      data[p] = r;
      data[p + 1] = g;
      data[p + 2] = bb;
      data[p + 3] = 255;
    }
    
    return this.imageData;
  }
  
  // ============================================
  // Utility
  // ============================================
  
  private clamp(x: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, x));
  }
  
  getDimensions(): { width: number; height: number } {
    return { width: this.width, height: this.height };
  }
  
  getFields(): { A: Float32Array; B: Float32Array; C: Float32Array } {
    return { A: this.fieldA, B: this.fieldB, C: this.fieldC };
  }
  
  /**
   * Create a snapshot for saving state
   */
  createSnapshot(ppu: PPUState): FieldSnapshot {
    return {
      timestamp: Date.now(),
      fieldA: new Float32Array(this.fieldA),
      fieldB: new Float32Array(this.fieldB),
      fieldC: new Float32Array(this.fieldC),
      ppuState: { ...ppu, poles: new Float32Array(ppu.poles), vels: new Float32Array(ppu.vels) },
    };
  }
  
  /**
   * Restore from snapshot
   */
  restoreSnapshot(snapshot: FieldSnapshot): void {
    this.fieldA.set(snapshot.fieldA);
    this.fieldB.set(snapshot.fieldB);
    this.fieldC.set(snapshot.fieldC);
  }
}

// ============================================
// FFT-based spectral analysis for the field
// ============================================

export function analyzeFieldSpectrum(field: Float32Array, width: number, height: number): {
  dominantFrequencies: Array<[number, number, number]>;
  entropy: number;
} {
  // Simplified spectral analysis
  // In a full implementation, this would use a 2D FFT
  
  const frequencies: Array<[number, number, number]> = [];
  let totalEnergy = 0;
  let entropy = 0;
  
  // Sample at different scales
  for (let scale = 1; scale <= 4; scale++) {
    for (let y = 0; y < height; y += scale * 4) {
      for (let x = 0; x < width; x += scale * 4) {
        const i = y * width + x;
        if (i < field.length) {
          const energy = field[i] * field[i];
          totalEnergy += energy;
          
          if (energy > 0.1) {
            frequencies.push([x / width, y / height, energy]);
          }
        }
      }
    }
  }
  
  // Calculate entropy
  for (const [, , energy] of frequencies) {
    if (energy > 0 && totalEnergy > 0) {
      const p = energy / totalEnergy;
      entropy -= p * Math.log(p);
    }
  }
  
  // Sort by energy and take top frequencies
  frequencies.sort((a, b) => b[2] - a[2]);
  
  return {
    dominantFrequencies: frequencies.slice(0, 10),
    entropy,
  };
}
