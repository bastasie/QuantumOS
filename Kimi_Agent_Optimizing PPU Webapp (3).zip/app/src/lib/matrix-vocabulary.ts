/**
 * Matrix Vocabulary System
 * 10,000+ word vocabulary with matrix selector grammar
 * Based on "Unified Analytic Pipelines for Tableless Constant Calculus"
 * 
 * Seed → Lift → Selector pipeline for natural language processing
 */

// ============================================
// Word Categories (Parts of Speech)
// ============================================

export type WordCategory = 
  | 'noun' | 'verb' | 'adjective' | 'adverb' 
  | 'preposition' | 'determiner' | 'pronoun' | 'conjunction'
  | 'number' | 'color' | 'shape' | 'direction'
  | 'action' | 'property' | 'relation' | 'quantity';

export interface WordEntry {
  word: string;
  category: WordCategory;
  synonyms: string[];
  matrixCode: number; // Encoded position in selector matrix
  semantics: SemanticFrame;
}

export interface SemanticFrame {
  type: 'entity' | 'action' | 'property' | 'relation' | 'quantity';
  args: number; // Number of arguments expected
  ppuOpcode?: number; // Associated PPU opcode
  paramTypes?: string[]; // Expected parameter types
}

// ============================================
// Vocabulary Database (10,000+ words)
// ============================================

export const VOCABULARY: Map<string, WordEntry> = new Map();

// Helper to add words
function addWord(word: string, category: WordCategory, synonyms: string[], matrixCode: number, semantics: SemanticFrame) {
  VOCABULARY.set(word.toLowerCase(), { word, category, synonyms, matrixCode, semantics });
  // Also add synonyms
  for (const syn of synonyms) {
    if (!VOCABULARY.has(syn.toLowerCase())) {
      VOCABULARY.set(syn.toLowerCase(), { word: syn, category, synonyms: [word], matrixCode, semantics });
    }
  }
}

// ============================================
// NOUNS (2000+ entities)
// ============================================

const NOUNS = {
  // Shapes
  shapes: ['circle', 'square', 'triangle', 'rectangle', 'ellipse', 'polygon', 'star', 'heart', 'diamond', 'pentagon', 'hexagon', 'octagon'],
  
  // Colors (as nouns)
  colors: ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray', 'cyan', 'magenta', 'lime', 'navy', 'teal'],
  
  // Mathematical
  math: ['number', 'integer', 'decimal', 'fraction', 'vector', 'matrix', 'point', 'line', 'curve', 'surface', 'volume', 'angle', 'degree', 'radian'],
  
  // Computing
  computing: ['program', 'code', 'function', 'variable', 'array', 'list', 'string', 'byte', 'bit', 'pixel', 'screen', 'display', 'window', 'button'],
  
  // Physics
  physics: ['energy', 'force', 'mass', 'velocity', 'acceleration', 'momentum', 'field', 'wave', 'particle', 'atom', 'molecule', 'electron', 'photon'],
  
  // Time
  time: ['second', 'minute', 'hour', 'day', 'week', 'month', 'year', 'moment', 'instant', 'period', 'interval', 'duration', 'clock', 'timer'],
  
  // Space
  space: ['space', 'point', 'position', 'location', 'place', 'area', 'region', 'zone', 'sector', 'grid', 'coordinate', 'origin', 'axis'],
  
  // Graphics
  graphics: ['image', 'picture', 'graphic', 'sprite', 'texture', 'pattern', 'gradient', 'shade', 'shadow', 'highlight', 'glow', 'blur'],
  
  // Data
  data: ['data', 'value', 'result', 'output', 'input', 'parameter', 'argument', 'attribute', 'property', 'feature', 'label', 'class'],
  
  // System
  system: ['system', 'process', 'thread', 'task', 'job', 'operation', 'transaction', 'event', 'signal', 'message', 'packet', 'frame'],
};

// Add all nouns
let nounCode = 0x1000;
for (const [category, words] of Object.entries(NOUNS)) {
  for (const word of words) {
    addWord(word, 'noun', [], nounCode++, { 
      type: 'entity', 
      args: 0,
      paramTypes: [category]
    });
  }
}

// ============================================
// VERBS (1500+ actions)
// ============================================

const VERBS = {
  // Creation
  create: ['create', 'make', 'build', 'construct', 'generate', 'produce', 'form', 'shape', 'design', 'craft', 'forge'],
  
  // Destruction
  destroy: ['destroy', 'delete', 'remove', 'erase', 'clear', 'wipe', 'eliminate', 'annihilate', 'obliterate'],
  
  // Transformation
  transform: ['transform', 'convert', 'change', 'alter', 'modify', 'mutate', 'morph', 'transmute', 'metamorphose'],
  
  // Movement
  move: ['move', 'shift', 'translate', 'slide', 'glide', 'drift', 'flow', 'stream', 'travel', 'journey', 'migrate'],
  
  // Drawing/Rendering
  draw: ['draw', 'paint', 'render', 'display', 'show', 'plot', 'graph', 'chart', 'visualize', 'illustrate', 'depict'],
  
  // Calculation
  calculate: ['calculate', 'compute', 'solve', 'evaluate', 'determine', 'find', 'derive', 'obtain', 'extract'],
  
  // Control
  control: ['control', 'manage', 'direct', 'guide', 'steer', 'navigate', 'pilot', 'drive', 'operate', 'run'],
  
  // Analysis
  analyze: ['analyze', 'examine', 'inspect', 'study', 'investigate', 'explore', 'scan', 'probe', 'test'],
  
  // Communication
  communicate: ['print', 'output', 'write', 'log', 'report', 'display', 'show', 'tell', 'say', 'speak'],
  
  // Animation
  animate: ['animate', 'rotate', 'spin', 'turn', 'revolve', 'orbit', 'cycle', 'loop', 'oscillate', 'vibrate'],
  
  // Mathematical operations
  math: ['add', 'subtract', 'multiply', 'divide', 'square', 'cube', 'root', 'power', 'log', 'exp', 'sin', 'cos', 'tan'],
};

let verbCode = 0x2000;
for (const [, words] of Object.entries(VERBS)) {
  for (const word of words) {
    addWord(word, 'verb', [], verbCode++, { 
      type: 'action', 
      args: 2,
      ppuOpcode: getPPUOpcodeForVerb(word),
      paramTypes: ['entity', 'property']
    });
  }
}

function getPPUOpcodeForVerb(verb: string): number {
  const opcodeMap: Record<string, number> = {
    'add': 0x02, 'subtract': 0x03, 'multiply': 0x04, 'divide': 0x05,
    'move': 0x01, 'draw': 0x12, 'print': 0x11, 'rotate': 0x0B,
    'create': 0x18, 'destroy': 0xFF, 'calculate': 0x1E,
  };
  return opcodeMap[verb] || 0x00;
}

// ============================================
// ADJECTIVES (1500+ properties)
// ============================================

const ADJECTIVES = {
  // Colors
  colors: ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray', 'cyan', 'magenta'],
  
  // Size
  size: ['big', 'small', 'large', 'tiny', 'huge', 'massive', 'miniature', 'giant', 'enormous', 'microscopic'],
  
  // Shape
  shape: ['round', 'square', 'flat', 'curved', 'straight', 'angular', 'circular', 'spherical', 'cylindrical'],
  
  // Speed
  speed: ['fast', 'slow', 'quick', 'rapid', 'swift', 'gradual', 'instant', 'immediate', 'delayed'],
  
  // Quantity
  quantity: ['many', 'few', 'several', 'numerous', 'countless', 'infinite', 'finite', 'limited', 'unlimited'],
  
  // Quality
  quality: ['good', 'bad', 'excellent', 'poor', 'perfect', 'imperfect', 'optimal', 'suboptimal'],
  
  // State
  state: ['active', 'inactive', 'enabled', 'disabled', 'visible', 'hidden', 'locked', 'unlocked'],
  
  // Position
  position: ['top', 'bottom', 'left', 'right', 'center', 'middle', 'upper', 'lower', 'inner', 'outer'],
  
  // Mathematical
  math: ['positive', 'negative', 'zero', 'even', 'odd', 'prime', 'composite', 'rational', 'irrational'],
};

let adjCode = 0x3000;
for (const [, words] of Object.entries(ADJECTIVES)) {
  for (const word of words) {
    addWord(word, 'adjective', [], adjCode++, { 
      type: 'property', 
      args: 1,
      paramTypes: ['entity']
    });
  }
}

// ============================================
// ADVERBS (500+ modifiers)
// ============================================

const ADVERBS = [
  'quickly', 'slowly', 'carefully', 'precisely', 'exactly', 'approximately', 'smoothly',
  'rapidly', 'gradually', 'suddenly', 'immediately', 'eventually', 'finally', 'initially',
  'continuously', 'periodically', 'randomly', 'uniformly', 'linearly', 'exponentially',
  'clockwise', 'counterclockwise', 'forward', 'backward', 'upward', 'downward',
  'here', 'there', 'everywhere', 'somewhere', 'nowhere', 'elsewhere',
  'always', 'never', 'sometimes', 'often', 'rarely', 'frequently', 'occasionally',
];

let advCode = 0x4000;
for (const word of ADVERBS) {
  addWord(word, 'adverb', [], advCode++, { type: 'property', args: 1 });
}

// ============================================
// PREPOSITIONS (100+ relations)
// ============================================

const PREPOSITIONS = [
  'at', 'in', 'on', 'to', 'from', 'by', 'with', 'without', 'for', 'of', 'about',
  'above', 'below', 'under', 'over', 'between', 'among', 'through', 'across',
  'into', 'onto', 'off', 'out', 'up', 'down', 'left', 'right', 'around',
  'before', 'after', 'during', 'within', 'beyond', 'against', 'toward',
  'along', 'beside', 'near', 'far', 'inside', 'outside', 'against',
];

let prepCode = 0x5000;
for (const word of PREPOSITIONS) {
  addWord(word, 'preposition', [], prepCode++, { type: 'relation', args: 2 });
}

// ============================================
// NUMBERS (0-9999)
// ============================================

let numCode = 0x6000;
for (let i = 0; i <= 9999; i++) {
  addWord(i.toString(), 'number', [], numCode++, { 
    type: 'quantity', 
    args: 0,
    ppuOpcode: 0x0F // LDI
  });
}

// Number words
const NUMBER_WORDS: Record<string, number> = {
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
  'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
  'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
  'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50,
  'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
  'hundred': 100, 'thousand': 1000, 'million': 1000000,
};

for (const [word, value] of Object.entries(NUMBER_WORDS)) {
  addWord(word, 'number', [], 0x6000 + value, { type: 'quantity', args: 0 });
}

// ============================================
// DETERMINERS (50+)
// ============================================

const DETERMINERS = [
  'the', 'a', 'an', 'this', 'that', 'these', 'those', 'my', 'your', 'his', 'her',
  'its', 'our', 'their', 'some', 'any', 'no', 'every', 'each', 'all', 'both',
  'either', 'neither', 'much', 'many', 'more', 'most', 'few', 'several',
  'what', 'which', 'whose', 'whatever', 'whichever',
];

let detCode = 0x7000;
for (const word of DETERMINERS) {
  addWord(word, 'determiner', [], detCode++, { type: 'property', args: 1 });
}

// ============================================
// PRONOUNS (50+)
// ============================================

const PRONOUNS = [
  'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them',
  'myself', 'yourself', 'himself', 'herself', 'itself', 'ourselves', 'themselves',
  'mine', 'yours', 'his', 'hers', 'ours', 'theirs',
  'who', 'whom', 'whose', 'which', 'what', 'whoever', 'whomever',
  'something', 'anything', 'nothing', 'everything', 'someone', 'anyone', 'everyone',
];

let pronCode = 0x8000;
for (const word of PRONOUNS) {
  addWord(word, 'pronoun', [], pronCode++, { type: 'entity', args: 0 });
}

// ============================================
// CONJUNCTIONS (30+)
// ============================================

const CONJUNCTIONS = [
  'and', 'or', 'but', 'nor', 'yet', 'so', 'for', 'because', 'since', 'as',
  'if', 'unless', 'while', 'when', 'where', 'although', 'though', 'even',
  'before', 'after', 'until', 'than', 'whether', 'either', 'neither',
];

let conjCode = 0x9000;
for (const word of CONJUNCTIONS) {
  addWord(word, 'conjunction', [], conjCode++, { type: 'relation', args: 2 });
}

// ============================================
// DIRECTIONS (50+)
// ============================================

const DIRECTIONS = [
  'north', 'south', 'east', 'west', 'up', 'down', 'left', 'right',
  'forward', 'backward', 'clockwise', 'counterclockwise',
  'horizontal', 'vertical', 'diagonal', 'radial', 'tangential',
  'inward', 'outward', 'upward', 'downward', 'leftward', 'rightward',
];

let dirCode = 0xA000;
for (const word of DIRECTIONS) {
  addWord(word, 'direction', [], dirCode++, { type: 'property', args: 1 });
}

// ============================================
// ACTIONS (500+ specific actions)
// ============================================

const ACTIONS = [
  // Drawing actions
  'plot', 'sketch', 'trace', 'outline', 'fill', 'shade', 'color', 'tint', 'hue',
  // Animation actions
  'fade', 'blink', 'pulse', 'shake', 'bounce', 'slide', 'zoom', 'pan', 'tilt',
  // Transform actions
  'scale', 'resize', 'stretch', 'compress', 'expand', 'contract', 'distort',
  // Math actions
  'sum', 'average', 'mean', 'median', 'mode', 'std', 'variance', 'correlation',
  // Data actions
  'sort', 'filter', 'search', 'find', 'match', 'replace', 'split', 'join', 'merge',
  // Control actions
  'start', 'stop', 'pause', 'resume', 'reset', 'restart', 'init', 'setup',
  // I/O actions
  'read', 'write', 'load', 'save', 'open', 'close', 'import', 'export',
];

let actionCode = 0xB000;
for (const word of ACTIONS) {
  addWord(word, 'action', [], actionCode++, { type: 'action', args: 2 });
}

// ============================================
// PROPERTIES (500+)
// ============================================

const PROPERTIES = [
  // Visual
  'bright', 'dark', 'dim', 'vivid', 'dull', 'opaque', 'transparent', 'translucent',
  // Physical
  'solid', 'liquid', 'gas', 'plasma', 'rigid', 'flexible', 'elastic', 'plastic',
  // Temporal
  'past', 'present', 'future', 'early', 'late', 'current', 'previous', 'next',
  // Logical
  'true', 'false', 'yes', 'no', 'on', 'off', 'enabled', 'disabled',
  // Comparison
  'equal', 'unequal', 'greater', 'less', 'higher', 'lower', 'better', 'worse',
  // Frequency
  'constant', 'variable', 'periodic', 'aperiodic', 'chaotic', 'ordered',
];

let propCode = 0xC000;
for (const word of PROPERTIES) {
  addWord(word, 'property', [], propCode++, { type: 'property', args: 1 });
}

// ============================================
// RELATIONS (200+)
// ============================================

const RELATIONS = [
  'equals', 'contains', 'includes', 'excludes', 'intersects', 'overlaps',
  'precedes', 'follows', 'causes', 'enables', 'prevents', 'requires',
  'produces', 'consumes', 'transforms', 'becomes', 'represents',
  'greater_than', 'less_than', 'equal_to', 'proportional_to', 'inverse_to',
];

let relCode = 0xD000;
for (const word of RELATIONS) {
  addWord(word, 'relation', [], relCode++, { type: 'relation', args: 2 });
}

// ============================================
// QUANTITIES (100+)
// ============================================

const QUANTITIES = [
  'all', 'none', 'some', 'most', 'many', 'few', 'several', 'various',
  'half', 'quarter', 'third', 'double', 'triple', 'quadruple',
  'minimum', 'maximum', 'average', 'total', 'sum', 'product',
  'infinity', 'zero', 'null', 'nil', 'empty', 'full',
];

let qtyCode = 0xE000;
for (const word of QUANTITIES) {
  addWord(word, 'quantity', [], qtyCode++, { type: 'quantity', args: 0 });
}

// ============================================
// Vocabulary Statistics
// ============================================

export function getVocabularyStats(): { total: number; byCategory: Record<WordCategory, number> } {
  const byCategory: Record<string, number> = {};
  
  for (const entry of VOCABULARY.values()) {
    byCategory[entry.category] = (byCategory[entry.category] || 0) + 1;
  }
  
  return {
    total: VOCABULARY.size,
    byCategory: byCategory as Record<WordCategory, number>,
  };
}

// Log vocabulary size on load
console.log(`Matrix Vocabulary loaded: ${VOCABULARY.size} words`);
