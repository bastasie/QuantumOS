/**
 * Multisensory Glyph-Convolutional Theory (MGCT)
 * Based on "Multisensory Glyph-Convolutional Theory: Unifying Sensory Perception, 
 * Poetic Forms, and Combinatorial Hierarchies"
 * Implements glyph algebra, spectral ladders, and the Nashīd al-Arūd fixed point
 */

import type { GlyphAtom, Glyph, ModalityConfig, SpectralLadder, Complex } from '@/types';

// ============================================
// Constants
// ============================================

export const BASE_B = 10; // Base for digit reduction

// Sensory modalities
export const SENSORY_MODALITIES: ModalityConfig[] = [
  { name: 'vision', layers: 8, templates: [0, 1, 2, 3, 4, 5], polarities: ['+', '-'] },
  { name: 'audition', layers: 12, templates: [0, 1, 2, 3, 4, 5, 6, 7], polarities: ['+', '-'] },
  { name: 'touch', layers: 6, templates: [0, 1, 2, 3], polarities: ['+', '-'] },
  { name: 'taste', layers: 4, templates: [0, 1, 2, 3, 4, 5], polarities: ['+', '-'] },
  { name: 'smell', layers: 10, templates: Array.from({ length: 20 }, (_, i) => i), polarities: ['+', '-'] },
  { name: 'proprioception', layers: 6, templates: [0, 1, 2, 3], polarities: ['+', '-'] },
];

// Poetry tribes (Arabic poetry circles)
export const POETRY_TRIBES = ['Abs', 'Dhubyān', 'Bakr', 'Taghlib', 'Tamīm', 'Qays'];

// Classical meters (buḥūr)
export const CLASSICAL_METERS = ['ṭawīl', 'madīd', 'basīṭ', 'kamil', 'wāfir', 'rajaz', 'ramal', 'sariʻ'];

// ============================================
// Glyph Atom Operations
// ============================================

export function createAtom(
  layer: number,
  modality: string,
  template: number,
  polarity: '+' | '-'
): GlyphAtom {
  return { layer, modality, template, polarity };
}

export function atomKey(atom: GlyphAtom): string {
  return `${atom.layer}:${atom.modality}:${atom.template}:${atom.polarity}`;
}

export function parseAtomKey(key: string): GlyphAtom {
  const [layer, modality, template, polarity] = key.split(':');
  return {
    layer: parseInt(layer),
    modality,
    template: parseInt(template),
    polarity: polarity as '+' | '-',
  };
}

// ============================================
// Glyph Operations
// ============================================

export function createEmptyGlyph(): Glyph {
  return {
    atoms: new Map(),
    support: new Set(),
  };
}

export function addAtomToGlyph(glyph: Glyph, atom: GlyphAtom, multiplicity: number = 1): Glyph {
  const key = atomKey(atom);
  const current = glyph.atoms.get(key) || 0;
  
  if (current + multiplicity === 0) {
    glyph.atoms.delete(key);
    glyph.support.delete(key);
  } else {
    glyph.atoms.set(key, current + multiplicity);
    glyph.support.add(key);
  }
  
  return glyph;
}

export function overlayGlyphs(g1: Glyph, g2: Glyph): Glyph {
  const result = createEmptyGlyph();
  
  // Add all atoms from g1
  for (const [key, mult] of g1.atoms) {
    result.atoms.set(key, mult);
    result.support.add(key);
  }
  
  // Add all atoms from g2
  for (const [key, mult] of g2.atoms) {
    const current = result.atoms.get(key) || 0;
    result.atoms.set(key, current + mult);
    if (current + mult > 0) {
      result.support.add(key);
    }
  }
  
  return result;
}

// ============================================
// Normalization Pass (P1, P2, P3)
// ============================================

/**
 * P1: Cancellation - antagonistic pairs annihilate
 */
export function cancellation(glyph: Glyph): Glyph {
  const result = createEmptyGlyph();
  const processed = new Set<string>();
  
  for (const key of glyph.support) {
    if (processed.has(key)) continue;
    
    const atom = parseAtomKey(key);
    const oppositeKey = atomKey({ ...atom, polarity: atom.polarity === '+' ? '-' : '+' });
    
    const posCount = glyph.atoms.get(key) || 0;
    const negCount = glyph.atoms.get(oppositeKey) || 0;
    
    if (atom.polarity === '+') {
      const net = posCount - negCount;
      if (net > 0) {
        addAtomToGlyph(result, atom, net);
      } else if (net < 0) {
        addAtomToGlyph(result, { ...atom, polarity: '-' }, -net);
      }
    }
    
    processed.add(key);
    processed.add(oppositeKey);
  }
  
  return result;
}

/**
 * P2: Digit reduction - base-b aggregation with carry
 */
export function digitReduction(glyph: Glyph, base: number = BASE_B): Glyph {
  const result = createEmptyGlyph();
  const layerTotals = new Map<string, number>();
  
  // Group by (layer, modality, polarity)
  for (const key of glyph.support) {
    const atom = parseAtomKey(key);
    const mult = glyph.atoms.get(key) || 0;
    const groupKey = `${atom.layer}:${atom.modality}:${atom.polarity}`;
    
    const current = layerTotals.get(groupKey) || 0;
    layerTotals.set(groupKey, current + mult * atom.template);
  }
  
  // Apply digit reduction
  for (const [groupKey, total] of layerTotals) {
    const [layer, modality, polarity] = groupKey.split(':');
    const remainder = total % base;
    const carry = Math.floor(total / base);
    
    if (remainder > 0) {
      addAtomToGlyph(result, createAtom(
        parseInt(layer),
        modality,
        remainder,
        polarity as '+' | '-'
      ));
    }
    
    if (carry > 0) {
      addAtomToGlyph(result, createAtom(
        parseInt(layer) + 1,
        modality,
        1,
        polarity as '+' | '-'
      ), carry);
    }
  }
  
  return result;
}

/**
 * P3: Global stabilization - iterate until fixed point
 */
export function normalizeGlyph(glyph: Glyph, maxIterations: number = 100): Glyph {
  let current = glyph;
  
  for (let i = 0; i < maxIterations; i++) {
    const cancelled = cancellation(current);
    const reduced = digitReduction(cancelled);
    
    // Check if fixed point reached
    if (glyphsEqual(current, reduced)) {
      break;
    }
    
    current = reduced;
  }
  
  return current;
}

export function glyphsEqual(g1: Glyph, g2: Glyph): boolean {
  if (g1.support.size !== g2.support.size) return false;
  
  for (const key of g1.support) {
    if (g1.atoms.get(key) !== g2.atoms.get(key)) return false;
  }
  
  return true;
}

// ============================================
// Intrinsic Sum (⊕)
// ============================================

export function intrinsicSum(g1: Glyph, g2: Glyph): Glyph {
  const overlaid = overlayGlyphs(g1, g2);
  return normalizeGlyph(overlaid);
}

// ============================================
// Spectral Ladder (MCT Tail)
// ============================================

/**
 * Compute Fourier transform for a modality's kernel
 */
export function computeSpectralLadder(
  glyph: Glyph,
  modality: string,
  size: number
): SpectralLadder {
  // Extract kernel for this modality
  const kernel: number[] = new Array(size).fill(0);
  
  for (const key of glyph.support) {
    const atom = parseAtomKey(key);
    if (atom.modality === modality) {
      const idx = atom.layer % size;
      kernel[idx] += (glyph.atoms.get(key) || 0) * atom.template * (atom.polarity === '+' ? 1 : -1);
    }
  }
  
  // Compute DFT
  const eigenvalues: Complex[] = [];
  for (let m = 0; m < size; m++) {
    let real = 0;
    let imag = 0;
    
    for (let j = 0; j < size; j++) {
      const angle = -2 * Math.PI * m * j / size;
      real += kernel[j] * Math.cos(angle);
      imag += kernel[j] * Math.sin(angle);
    }
    
    eigenvalues.push({ re: real, im: imag });
  }
  
  // Determinant = product of eigenvalues
  let determinant = 1;
  for (const ev of eigenvalues) {
    determinant *= Math.sqrt(ev.re * ev.re + ev.im * ev.im);
  }
  
  return { modality, eigenvalues, determinant };
}

/**
 * Global determinant across all modalities
 */
export function globalDeterminant(glyph: Glyph): number {
  const modalities = new Set<string>();
  for (const key of glyph.support) {
    modalities.add(parseAtomKey(key).modality);
  }
  
  let det = 1;
  for (const modality of modalities) {
    const ladder = computeSpectralLadder(glyph, modality, 16);
    det *= ladder.determinant;
  }
  
  return det;
}

// ============================================
// Combinatorial Generators
// ============================================

/**
 * Generate k-permutations of templates
 */
export function generatePermutations<T>(items: T[], k: number): T[][] {
  if (k === 0) return [[]];
  if (items.length < k) return [];
  
  const result: T[][] = [];
  
  function permute(current: T[], remaining: T[], depth: number) {
    if (depth === 0) {
      result.push([...current]);
      return;
    }
    
    for (let i = 0; i < remaining.length; i++) {
      current.push(remaining[i]);
      permute(
        current,
        [...remaining.slice(0, i), ...remaining.slice(i + 1)],
        depth - 1
      );
      current.pop();
    }
  }
  
  permute([], items, k);
  return result;
}

/**
 * Generate k-combinations of templates
 */
export function generateCombinations<T>(items: T[], k: number): T[][] {
  if (k === 0) return [[]];
  if (items.length < k) return [];
  
  const result: T[][] = [];
  
  function combine(start: number, current: T[]) {
    if (current.length === k) {
      result.push([...current]);
      return;
    }
    
    for (let i = start; i < items.length; i++) {
      current.push(items[i]);
      combine(i + 1, current);
      current.pop();
    }
  }
  
  combine(0, []);
  return result;
}

/**
 * Permutation operator: Perm_k(G)
 */
export function permutationOperator(
  glyph: Glyph,
  k: number,
  modality: string
): Glyph {
  const result = createEmptyGlyph();
  
  // Get templates for this modality
  const templates: number[] = [];
  for (const key of glyph.support) {
    const atom = parseAtomKey(key);
    if (atom.modality === modality) {
      for (let i = 0; i < (glyph.atoms.get(key) || 0); i++) {
        templates.push(atom.template);
      }
    }
  }
  
  // Generate k-permutations
  const perms = generatePermutations(templates, k);
  
  for (const perm of perms) {
    // Create atom for this permutation
    const permValue = perm.reduce((sum, t, i) => sum + t * Math.pow(BASE_B, i), 0);
    const maxLayer = Math.max(...Array.from(glyph.support).map(k => parseAtomKey(k).layer));
    
    addAtomToGlyph(result, createAtom(
      maxLayer + 1,
      modality,
      permValue % BASE_B,
      '+'
    ));
  }
  
  return normalizeGlyph(result);
}

// ============================================
// Nashīd al-Arūd (Universal Fixed Point)
// ============================================

/**
 * Nashīd endomorphism: T(G) = ∅ ⊕ ⨆_k (X ⊗ Perm_k(G))
 */
export function nashidEndomorphism(
  glyph: Glyph,
  maxK: number = 4,
  modality: string = 'poetry'
): Glyph {
  // Shift generator: X = E_{1,modality,1,+}
  let result = createEmptyGlyph();
  
  for (let k = 1; k <= maxK; k++) {
    const perm = permutationOperator(glyph, k, modality);
    
    // X ⊗ Perm_k(G) - shift and overlay
    for (const key of perm.support) {
      const atom = parseAtomKey(key);
      const shifted = createAtom(atom.layer + 1, atom.modality, atom.template, atom.polarity);
      addAtomToGlyph(result, shifted, perm.atoms.get(key) || 0);
    }
  }
  
  return normalizeGlyph(result);
}

/**
 * Find Nashīd fixed point by iteration
 */
export function findNashidFixedPoint(
  initial: Glyph,
  maxIterations: number = 100
): Glyph {
  let current = initial;
  
  for (let i = 0; i < maxIterations; i++) {
    const next = nashidEndomorphism(current);
    
    if (glyphsEqual(current, next)) {
      return next;
    }
    
    current = next;
  }
  
  return current;
}

// ============================================
// Poetry Circle (Rawḍ al-Ṭarīq)
// ============================================

export interface PoetryCircle {
  tribe: string;
  meter: string;
  rhyme: string;
  polarity: '+' | '-';
  glyph: Glyph;
}

/**
 * Create a poetry circle glyph
 */
export function createPoetryCircle(
  tribe: string,
  meter: string,
  rhyme: string,
  polarity: '+' | '-' = '+'
): PoetryCircle {
  const glyph = createEmptyGlyph();
  
  // Add tribal identity
  const tribeIndex = POETRY_TRIBES.indexOf(tribe);
  if (tribeIndex >= 0) {
    addAtomToGlyph(glyph, createAtom(0, 'tribe', tribeIndex, polarity));
  }
  
  // Add meter
  const meterIndex = CLASSICAL_METERS.indexOf(meter);
  if (meterIndex >= 0) {
    addAtomToGlyph(glyph, createAtom(1, 'meter', meterIndex, polarity));
  }
  
  // Add rhyme (encoded as character codes)
  for (let i = 0; i < rhyme.length; i++) {
    addAtomToGlyph(glyph, createAtom(2, 'rhyme', rhyme.charCodeAt(i) % BASE_B, polarity));
  }
  
  return { tribe, meter, rhyme, polarity, glyph: normalizeGlyph(glyph) };
}

/**
 * Check if poetry circle satisfies Hadamard condition
 * |λ_m|² = N for all m
 */
export function checkHadamardCondition(
  circle: PoetryCircle,
  size: number = 16
): { satisfied: boolean; maxDeviation: number } {
  const ladder = computeSpectralLadder(circle.glyph, 'meter', size);
  
  const targetMagnitude = size;
  let maxDeviation = 0;
  
  for (const ev of ladder.eigenvalues) {
    const magnitude = ev.re * ev.re + ev.im * ev.im;
    const deviation = Math.abs(magnitude - targetMagnitude);
    maxDeviation = Math.max(maxDeviation, deviation);
  }
  
  return {
    satisfied: maxDeviation < 0.1,
    maxDeviation,
  };
}

// ============================================
// Cross-Modal Operations
// ============================================

/**
 * Synesthesia: combine visual and auditory glyphs
 */
export function synesthesia(visual: Glyph, auditory: Glyph): Glyph {
  // Overlay with cross-modal normalization
  const combined = overlayGlyphs(visual, auditory);
  
  // The determinant factorizes: Det_{vision+audition} = Det_{vision} · Det_{audition}
  return normalizeGlyph(combined);
}

/**
 * Molecular-poetic binding
 */
export function molecularPoeticBinding(
  molecule: Glyph,
  verse: Glyph
): Glyph {
  // Tensor product normalized to canonical valence
  const product = overlayGlyphs(molecule, verse);
  return normalizeGlyph(product);
}

// ============================================
// Visualization Helpers
// ============================================

export interface GlyphVisualization {
  atoms: Array<{
    layer: number;
    modality: string;
    template: number;
    polarity: string;
    multiplicity: number;
  }>;
  layerDistribution: Map<number, number>;
  modalityDistribution: Map<string, number>;
  determinant: number;
}

export function visualizeGlyph(glyph: Glyph): GlyphVisualization {
  const atoms: GlyphVisualization['atoms'] = [];
  const layerDistribution = new Map<number, number>();
  const modalityDistribution = new Map<string, number>();
  
  for (const key of glyph.support) {
    const atom = parseAtomKey(key);
    const mult = glyph.atoms.get(key) || 0;
    
    atoms.push({
      layer: atom.layer,
      modality: atom.modality,
      template: atom.template,
      polarity: atom.polarity,
      multiplicity: mult,
    });
    
    layerDistribution.set(atom.layer, (layerDistribution.get(atom.layer) || 0) + mult);
    modalityDistribution.set(atom.modality, (modalityDistribution.get(atom.modality) || 0) + mult);
  }
  
  return {
    atoms,
    layerDistribution,
    modalityDistribution,
    determinant: globalDeterminant(glyph),
  };
}
