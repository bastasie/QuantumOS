/**
 * GIF Executor - Runs code inside the GIF field at 60fps
 * Every line of code is held in GIF frames
 * Auto-calibrates screen sizing within the GIF layout
 */

// PPUState type not needed in this module

// ============================================
// Execution Frame Types
// ============================================

export interface ExecutionFrame {
  lineNumber: number;
  code: string;
  result?: unknown;
  poleUses: number[];
  timestamp: number;
  canvasState?: ImageData;
}

export interface ExecutionSession {
  frames: ExecutionFrame[];
  currentFrame: number;
  isRunning: boolean;
  fps: number;
  lastFrameTime: number;
  code: string;
  language: 'python' | 'ppu-assembly' | 'natural-language';
}

// ============================================
// Code Parser for Frame Extraction
// ============================================

export function parseCodeToFrames(code: string, language: 'python' | 'ppu-assembly'): ExecutionFrame[] {
  const frames: ExecutionFrame[] = [];
  const lines = code.split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Determine pole uses based on operation type
    const poleUses = determinePoleUses(line, language);
    
    frames.push({
      lineNumber: i,
      code: line,
      poleUses,
      timestamp: i * (1000 / 60), // 60fps timing
    });
  }
  
  return frames;
}

function determinePoleUses(line: string, language: 'python' | 'ppu-assembly'): number[] {
  const poles: number[] = [];
  const lower = line.toLowerCase();
  
  if (language === 'python') {
    // Python operations map to poles
    if (lower.includes('=') && !lower.includes('==')) poles.push(0); // Assignment
    if (lower.includes('+')) poles.push(1); // Addition
    if (lower.includes('-') && !lower.includes('for')) poles.push(2); // Subtraction
    if (lower.includes('*') || lower.includes('logmul')) poles.push(3, 8); // Multiplication
    if (lower.includes('/')) poles.push(4); // Division
    if (lower.includes('%')) poles.push(5); // Modulo
    if (lower.includes('&')) poles.push(6); // AND
    if (lower.includes('|')) poles.push(7); // OR
    if (lower.includes('^')) poles.push(8); // XOR
    if (lower.includes('~')) poles.push(9); // NOT
    if (lower.includes('print') || lower.includes('fbset')) poles.push(2, 3); // I/O, Graphics
    if (lower.includes('if') || lower.includes('for') || lower.includes('while')) poles.push(4); // Control flow
    if (lower.includes('prime')) poles.push(7); // Prime domain
    if (lower.includes('baz')) poles.push(9); // BAZ
  } else {
    // Assembly operations
    if (lower.startsWith('mov') || lower.startsWith('ldi')) poles.push(0);
    if (lower.startsWith('add')) poles.push(1);
    if (lower.startsWith('sub')) poles.push(2);
    if (lower.startsWith('mul') || lower.startsWith('logmul')) poles.push(3, 8);
    if (lower.startsWith('div')) poles.push(4);
    if (lower.startsWith('mod')) poles.push(5);
    if (lower.startsWith('and')) poles.push(6);
    if (lower.startsWith('or')) poles.push(7);
    if (lower.startsWith('xor')) poles.push(8);
    if (lower.startsWith('not')) poles.push(9);
    if (lower.startsWith('out') || lower.startsWith('fbset')) poles.push(2, 3);
    if (lower.startsWith('jmp') || lower.startsWith('jz') || lower.startsWith('jnz')) poles.push(4);
    if (lower.startsWith('prime')) poles.push(7);
    if (lower.startsWith('baz')) poles.push(9);
  }
  
  return [...new Set(poles)]; // Remove duplicates
}

// ============================================
// Frame Executor
// ============================================

export class GIFExecutor {
  private session: ExecutionSession | null = null;
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private animationId: number | null = null;
  private onFrame: ((frame: ExecutionFrame) => void) | null = null;
  private onComplete: (() => void) | null = null;
  
  // Canvas state for drawing operations
  private drawingState = {
    x: 128,
    y: 128,
    color: '#FF0000',
    size: 10,
  };
  
  constructor(canvas?: HTMLCanvasElement) {
    if (canvas) {
      this.setCanvas(canvas);
    }
  }
  
  setCanvas(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
  }
  
  setCallbacks(
    onFrame: (frame: ExecutionFrame) => void,
    onComplete: () => void
  ): void {
    this.onFrame = onFrame;
    this.onComplete = onComplete;
  }
  
  /**
   * Start executing code at 60fps
   * Each line becomes a frame
   */
  execute(code: string, language: 'python' | 'ppu-assembly' | 'natural-language'): void {
    // Parse natural language to code first
    let executableCode = code;
    if (language === 'natural-language') {
      executableCode = this.translateNLToCode(code);
    }
    
    const frames = parseCodeToFrames(executableCode, language === 'natural-language' ? 'python' : language as 'python' | 'ppu-assembly');
    
    this.session = {
      frames,
      currentFrame: 0,
      isRunning: true,
      fps: 60,
      lastFrameTime: performance.now(),
      code: executableCode,
      language: language === 'natural-language' ? 'python' : language as 'python' | 'ppu-assembly',
    };
    
    this.startFrameLoop();
  }
  
  private translateNLToCode(nl: string): string {
    // Simple NL to code translation
    const lower = nl.toLowerCase().trim();
    
    if (lower.includes('draw') && lower.includes('circle')) {
      const color = lower.includes('red') ? '0xFF0000' : lower.includes('blue') ? '0x0000FF' : lower.includes('green') ? '0x00FF00' : '0xFFFFFF';
      const match = lower.match(/(\d+).*?(\d+)/);
      const x = match ? match[1] : '128';
      const y = match ? match[2] : '128';
      const size = lower.match(/size\s+(\d+)/)?.[1] || '30';
      return `# Draw circle at (${x}, ${y})
center_x = ${x}
center_y = ${y}
radius = ${size}
color = ${color}
fbset(center_x, center_y, color)`;
    }
    
    if (lower.includes('draw') && lower.includes('square')) {
      const color = lower.includes('red') ? '0xFF0000' : lower.includes('blue') ? '0x0000FF' : '0xFFFFFF';
      return `# Draw square
x = 100
y = 100
size = 50
color = ${color}
fbset(x, y, color)`;
    }
    
    if (lower.includes('calculate') || lower.includes('plus') || lower.includes('times')) {
      const match = lower.match(/(\d+).*?(\d+)/);
      if (match) {
        const a = match[1];
        const b = match[2];
        if (lower.includes('plus')) {
          return `# Calculate ${a} + ${b}
a = ${a}
b = ${b}
result = a + b
print(result)`;
        }
        if (lower.includes('times')) {
          return `# Calculate ${a} * ${b}
a = ${a}
b = ${b}
result = logmul(a, b)
print(result)`;
        }
      }
    }
    
    if (lower.includes('animate')) {
      return `# Animation
x = 0
y = 128
color = 0xFF0000
for i in range(100):
    x = x + 1
    fbset(x, y, color)`;
    }
    
    if (lower.includes('clear')) {
      return `# Clear screen
for x in range(256):
    for y in range(256):
        fbset(x, y, 0x000000)`;
    }
    
    // Default
    return `# Natural language: ${nl}
print("Executed: ${nl}")`;
  }
  
  private startFrameLoop(): void {
    if (!this.session) return;
    
    const frameInterval = 1000 / this.session.fps;
    
    const loop = (currentTime: number) => {
      if (!this.session || !this.session.isRunning) return;
      
      const elapsed = currentTime - this.session.lastFrameTime;
      
      if (elapsed >= frameInterval) {
        this.executeFrame();
        this.session.lastFrameTime = currentTime;
      }
      
      if (this.session.isRunning) {
        this.animationId = requestAnimationFrame(loop);
      }
    };
    
    this.animationId = requestAnimationFrame(loop);
  }
  
  private executeFrame(): void {
    if (!this.session || !this.ctx || !this.canvas) return;
    
    const frame = this.session.frames[this.session.currentFrame];
    if (!frame) {
      this.stop();
      return;
    }
    
    // Execute the code line
    const result = this.executeLine(frame.code);
    frame.result = result;
    frame.canvasState = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
    
    // Notify callback
    if (this.onFrame) {
      this.onFrame(frame);
    }
    
    // Advance to next frame
    this.session.currentFrame++;
    
    if (this.session.currentFrame >= this.session.frames.length) {
      this.stop();
    }
  }
  
  private executeLine(line: string): unknown {
    if (!this.ctx || !this.canvas) return null;
    
    const lower = line.toLowerCase().trim();
    
    // Handle variable assignment
    const assignMatch = line.match(/^(\w+)\s*=\s*(.+)$/);
    if (assignMatch && !lower.startsWith('for') && !lower.startsWith('if')) {
      const [, varName, expr] = assignMatch;
      const value = this.evaluateExpression(expr.trim());
      (this.drawingState as Record<string, unknown>)[varName] = value;
      return value;
    }
    
    // Handle fbset (framebuffer set pixel)
    if (lower.includes('fbset')) {
      const match = line.match(/fbset\(([^,]+),\s*([^,]+),\s*([^)]+)\)/);
      if (match) {
        const x = this.evaluateExpression(match[1].trim());
        const y = this.evaluateExpression(match[2].trim());
        const color = this.evaluateExpression(match[3].trim());
        this.drawPixel(Number(x), Number(y), Number(color));
        return { x, y, color };
      }
    }
    
    // Handle print
    if (lower.includes('print')) {
      const match = line.match(/print\(([^)]+)\)/);
      if (match) {
        const value = this.evaluateExpression(match[1].trim());
        return { printed: value };
      }
    }
    
    // Handle for loop (simplified)
    if (lower.startsWith('for')) {
      // Loop structure handled at frame level
      return { loop: true };
    }
    
    return null;
  }
  
  private evaluateExpression(expr: string): number | string {
    expr = expr.trim();
    
    // Check if it's a variable
    if (/^\w+$/.test(expr) && !/^\d/.test(expr)) {
      const value = (this.drawingState as Record<string, unknown>)[expr];
      return typeof value === 'number' ? value : 0;
    }
    
    // Hex color
    if (expr.startsWith('0x')) {
      return parseInt(expr, 16);
    }
    
    // Number
    if (/^\d+$/.test(expr)) {
      return parseInt(expr, 10);
    }
    
    // Binary operation (simplified)
    const binOpMatch = expr.match(/^(.+?)\s*([+\-*/])\s*(.+)$/);
    if (binOpMatch) {
      const left = Number(this.evaluateExpression(binOpMatch[1]));
      const op = binOpMatch[2];
      const right = Number(this.evaluateExpression(binOpMatch[3]));
      
      switch (op) {
        case '+': return left + right;
        case '-': return left - right;
        case '*': return left * right;
        case '/': return right !== 0 ? left / right : 0;
      }
    }
    
    // Function calls
    if (expr.includes('logmul')) {
      const match = expr.match(/logmul\(([^,]+),\s*([^)]+)\)/);
      if (match) {
        const a = Number(this.evaluateExpression(match[1]));
        const b = Number(this.evaluateExpression(match[2]));
        return Math.exp(Math.log(a) + Math.log(b));
      }
    }
    
    return 0;
  }
  
  private drawPixel(x: number, y: number, color: number): void {
    if (!this.ctx || !this.canvas) return;
    
    // Extract RGB from color value
    const r = (color >> 16) & 0xFF;
    const g = (color >> 8) & 0xFF;
    const b = color & 0xFF;
    
    this.ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
    this.ctx.fillRect(x, y, 2, 2); // 2x2 pixel for visibility
  }
  
  stop(): void {
    if (this.animationId !== null) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
    if (this.session) {
      this.session.isRunning = false;
    }
    if (this.onComplete) {
      this.onComplete();
    }
  }
  
  reset(): void {
    this.stop();
    this.session = null;
    if (this.ctx && this.canvas) {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    this.drawingState = { x: 128, y: 128, color: '#FF0000', size: 10 };
  }
  
  getCurrentFrame(): ExecutionFrame | null {
    if (!this.session) return null;
    return this.session.frames[this.session.currentFrame] || null;
  }
  
  getProgress(): number {
    if (!this.session || this.session.frames.length === 0) return 0;
    return this.session.currentFrame / this.session.frames.length;
  }
}

// ============================================
// Auto-calibration for screen sizing
// ============================================

export interface CalibratedLayout {
  canvasWidth: number;
  canvasHeight: number;
  codePanelHeight: number;
  statusPanelHeight: number;
  touchTargets: Array<{ x: number; y: number; width: number; height: number; action: string }>;
}

/**
 * Auto-calibrate the layout to fit within GIF dimensions
 */
export function calibrateLayout(
  containerWidth: number,
  containerHeight: number,
  gifWidth: number,
  gifHeight: number
): CalibratedLayout {
  // Scale GIF to fit container while maintaining aspect ratio
  const scale = Math.min(
    containerWidth / gifWidth,
    containerHeight / gifHeight
  );
  
  const canvasWidth = Math.floor(gifWidth * scale);
  const canvasHeight = Math.floor(gifHeight * scale);
  
  // Reserve space for code panel (20% of height)
  const codePanelHeight = Math.floor(canvasHeight * 0.20);
  
  // Reserve space for status panel (10% of height)
  const statusPanelHeight = Math.floor(canvasHeight * 0.10);
  
  // Touch targets for common actions
  const touchTargets = [
    { x: 10, y: 10, width: 60, height: 40, action: 'run' },
    { x: 80, y: 10, width: 60, height: 40, action: 'stop' },
    { x: 150, y: 10, width: 60, height: 40, action: 'reset' },
    { x: canvasWidth - 70, y: 10, width: 60, height: 40, action: 'menu' },
  ];
  
  return {
    canvasWidth,
    canvasHeight,
    codePanelHeight,
    statusPanelHeight,
    touchTargets,
  };
}
