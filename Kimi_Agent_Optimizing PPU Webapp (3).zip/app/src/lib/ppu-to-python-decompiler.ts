/**
 * PPU Assembly to Python Decompiler
 * Two-way translation: PPU Assembly → Python
 * Each line of assembly becomes a Python statement
 * Every pole use is captured in our math
 */

import { PPU_OPCODES } from './python-to-ppu-compiler';

// ============================================
// Decompiler State
// ============================================

interface DecompilerState {
  python: string[];
  variables: Map<number, string>;  // Register to variable name
  labels: Map<string, number>;     // Label to line number
  indent: number;
  poleUses: number[];              // Track which poles are used
}

// ============================================
// Opcode to Python Mapping
// ============================================

const OPCODE_TO_PYTHON: Record<number, (args: number[], state: DecompilerState) => string | null> = {
  [PPU_OPCODES.NOP]: () => '# NOP - No operation',
  [PPU_OPCODES.MOV]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 0); // Pole 0 for moves
    return `${dst} = ${src}`;
  },
  [PPU_OPCODES.ADD]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 1); // Pole 1 for addition
    return `${dst} = ${dst} + ${src}`;
  },
  [PPU_OPCODES.SUB]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 2); // Pole 2 for subtraction
    return `${dst} = ${dst} - ${src}`;
  },
  [PPU_OPCODES.MUL]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 3); // Pole 3 for multiplication
    return `${dst} = ${dst} * ${src}`;
  },
  [PPU_OPCODES.DIV]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 4); // Pole 4 for division
    return `${dst} = ${dst} / ${src}`;
  },
  [PPU_OPCODES.MOD]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 5); // Pole 5 for modulo
    return `${dst} = ${dst} % ${src}`;
  },
  [PPU_OPCODES.AND]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 6); // Pole 6 for AND
    return `${dst} = ${dst} & ${src}`;
  },
  [PPU_OPCODES.OR]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 7); // Pole 7 for OR
    return `${dst} = ${dst} | ${src}`;
  },
  [PPU_OPCODES.XOR]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 8); // Pole 8 for XOR
    return `${dst} = ${dst} ^ ${src}`;
  },
  [PPU_OPCODES.NOT]: (args, state) => {
    const dst = getVarName(state, args[0]);
    recordPoleUse(state, 9); // Pole 9 for NOT
    return `${dst} = ~${dst}`;
  },
  [PPU_OPCODES.SHL]: (args, state) => {
    const dst = getVarName(state, args[0]);
    recordPoleUse(state, 10); // Pole 10 for shift
    return `${dst} = ${dst} << ${args[1]}`;
  },
  [PPU_OPCODES.SHR]: (args, state) => {
    const dst = getVarName(state, args[0]);
    recordPoleUse(state, 10); // Pole 10 for shift
    return `${dst} = ${dst} >> ${args[1]}`;
  },
  [PPU_OPCODES.LDI]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const value = args[1] | (args[2] << 8) | (args[3] << 16) | (args[4] << 24);
    recordPoleUse(state, 0); // Pole 0 for load immediate
    return `${dst} = ${value}`;
  },
  [PPU_OPCODES.LD]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const addr = args[1] | (args[2] << 8);
    recordPoleUse(state, 1); // Pole 1 for memory
    return `${dst} = memory[${addr}]`;
  },
  [PPU_OPCODES.ST]: (args, state) => {
    const src = getVarName(state, args[2]);
    const addr = args[0] | (args[1] << 8);
    recordPoleUse(state, 1); // Pole 1 for memory
    return `memory[${addr}] = ${src}`;
  },
  [PPU_OPCODES.IN]: (args, state) => {
    const dst = getVarName(state, args[0]);
    recordPoleUse(state, 2); // Pole 2 for I/O
    return `${dst} = input_port(${args[1]})`;
  },
  [PPU_OPCODES.OUT]: (args, state) => {
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 2); // Pole 2 for I/O
    return `print(${src})  # Output to port ${args[0]}`;
  },
  [PPU_OPCODES.FBSET]: (args, state) => {
    recordPoleUse(state, 3); // Pole 3 for graphics
    return `fbset(r${args[0]}, r${args[1]}, r${args[2]})  # Set pixel`;
  },
  [PPU_OPCODES.FBLIT]: (args, state) => {
    recordPoleUse(state, 3); // Pole 3 for graphics
    return `fblit(r${args[0]}, r${args[1]}, r${args[2]}, r${args[3]}, r${args[4]})  # Blit image`;
  },
  [PPU_OPCODES.JMP]: (args, state) => {
    recordPoleUse(state, 4); // Pole 4 for control flow
    return `# JMP to ${args[0] | (args[1] << 8)}`;
  },
  [PPU_OPCODES.JZ]: (args, state) => {
    recordPoleUse(state, 4); // Pole 4 for control flow
    return `if r${args[0]} == 0:`;
  },
  [PPU_OPCODES.JNZ]: (args, state) => {
    recordPoleUse(state, 4); // Pole 4 for control flow
    return `if r${args[0]} != 0:`;
  },
  [PPU_OPCODES.JL]: (args, state) => {
    recordPoleUse(state, 4); // Pole 4 for control flow
    return `if r${args[0]} < r${args[1]}:`;
  },
  [PPU_OPCODES.CALL]: (args, state) => {
    recordPoleUse(state, 5); // Pole 5 for calls
    return `call_${args[0] | (args[1] << 8)}()`;
  },
  [PPU_OPCODES.RET]: () => {
    return 'return';
  },
  [PPU_OPCODES.PUSH]: (args, state) => {
    recordPoleUse(state, 5); // Pole 5 for stack
    return `stack.push(r${args[0]})`;
  },
  [PPU_OPCODES.POP]: (args, state) => {
    recordPoleUse(state, 5); // Pole 5 for stack
    return `r${args[0]} = stack.pop()`;
  },
  [PPU_OPCODES.CMP]: (args, state) => {
    recordPoleUse(state, 6); // Pole 6 for compare
    return `flags = compare(r${args[0]}, r${args[1]})`;
  },
  [PPU_OPCODES.PRIME]: (args, state) => {
    const dst = getVarName(state, args[0]);
    recordPoleUse(state, 7); // Pole 7 for prime domain
    return `${dst} = prime(${dst})  # Convert to prime domain`;
  },
  [PPU_OPCODES.LOGMUL]: (args, state) => {
    const dst = getVarName(state, args[0]);
    const src = getVarName(state, args[1]);
    recordPoleUse(state, 8); // Pole 8 for log-domain
    return `${dst} = logmul(${dst}, ${src})  # Log-domain multiply`;
  },
  [PPU_OPCODES.BAZ]: (args, state) => {
    const dst = getVarName(state, args[0]);
    recordPoleUse(state, 9); // Pole 9 for BAZ
    return `${dst} = baz(${dst})  # BAZ normalization`;
  },
  [PPU_OPCODES.HALT]: () => {
    return '# HALT - Program end';
  },
};

// ============================================
// Helper Functions
// ============================================

function getVarName(state: DecompilerState, reg: number): string {
  if (!state.variables.has(reg)) {
    state.variables.set(reg, `r${reg}`);
  }
  return state.variables.get(reg)!;
}

function recordPoleUse(state: DecompilerState, pole: number): void {
  if (!state.poleUses.includes(pole)) {
    state.poleUses.push(pole);
  }
}

// ============================================
// Main Decompiler
// ============================================

export interface DecompileResult {
  python: string;
  poleUses: number[];
  lineCount: number;
  success: boolean;
  errors: string[];
}

/**
 * Decompile PPU bytecode to Python
 * Each bytecode instruction becomes a Python line
 */
export function decompilePPUToPython(bytecode: Uint8Array): DecompileResult {
  const state: DecompilerState = {
    python: [],
    variables: new Map(),
    labels: new Map(),
    indent: 0,
    poleUses: [],
  };
  
  const errors: string[] = [];
  let i = 0;
  let lineNum = 1;
  
  // Add header with pole math
  state.python.push('# Decompiled from PPU Assembly');
  state.python.push('# PPU Pole Usage: ' + Array.from({length: 12}, (_, i) => `P${i}`).join(', '));
  state.python.push('');
  state.python.push('def ppu_program():');
  state.indent = 1;
  
  while (i < bytecode.length) {
    const opcode = bytecode[i];
    const handler = OPCODE_TO_PYTHON[opcode];
    
    if (handler) {
      // Determine argument count based on opcode
      let argCount = 0;
      const op = opcode as number;
      
      // Use a function to get arg count to avoid TypeScript narrowing issues
      const getArgCount = (o: number): number => {
        if (o === PPU_OPCODES.LDI) return 5;
        if (o === PPU_OPCODES.LD || o === PPU_OPCODES.ST) return 3;
        if (o === PPU_OPCODES.JMP || o === PPU_OPCODES.CALL) return 2;
        if (o === PPU_OPCODES.JZ || o === PPU_OPCODES.JNZ) return 3;
        if (o === PPU_OPCODES.JL) return 4;
        if (o === PPU_OPCODES.FBSET) return 3;
        if (o === PPU_OPCODES.FBLIT) return 5;
        if (o === PPU_OPCODES.NOT || o === PPU_OPCODES.PUSH || 
            o === PPU_OPCODES.POP || o === PPU_OPCODES.PRIME ||
            o === PPU_OPCODES.BAZ) return 1;
        if (o === PPU_OPCODES.NOP || o === PPU_OPCODES.HALT || 
            o === PPU_OPCODES.RET) return 0;
        return 2; // Default for most 2-arg opcodes
      };
      
      argCount = getArgCount(op);
      
      const args = Array.from({length: argCount}, (_, j) => bytecode[i + 1 + j] || 0);
      
      try {
        const line = handler(args, state);
        if (line !== null) {
          const indent = '    '.repeat(state.indent);
          state.python.push(`${indent}${line}`);
          lineNum++;
        }
      } catch (e) {
        errors.push(`Error at byte ${i}: ${e}`);
      }
      
      i += 1 + argCount;
    } else if (opcode === 0xFF) {
      // HALT
      state.python.push(`${'    '.repeat(state.indent)}# HALT`);
      break;
    } else {
      errors.push(`Unknown opcode: 0x${opcode.toString(16)} at position ${i}`);
      i++;
    }
  }
  
  // Add footer
  state.python.push('');
  state.python.push('# Pole usage summary');
  state.python.push(`poles_used = [${state.poleUses.join(', ')}]`);
  
  return {
    python: state.python.join('\n'),
    poleUses: state.poleUses,
    lineCount: lineNum,
    success: errors.length === 0,
    errors,
  };
}

/**
 * Decompile PPU assembly text to Python
 */
export function decompileAssemblyToPython(assembly: string): DecompileResult {
  const lines = assembly.split('\n').filter(l => l.trim() && !l.trim().startsWith(';'));
  const state: DecompilerState = {
    python: [],
    variables: new Map(),
    labels: new Map(),
    indent: 0,
    poleUses: [],
  };
  
  const errors: string[] = [];
  
  // Add header
  state.python.push('# Decompiled from PPU Assembly');
  state.python.push('# PPU Pole Usage: P0-P11 (12-pole harmonic oscillator)');
  state.python.push('');
  state.python.push('def ppu_program():');
  state.indent = 1;
  
  for (const line of lines) {
    const trimmed = line.trim();
    const parts = trimmed.split(/\s+/);
    const mnemonic = parts[0].toUpperCase();
    
    // Parse operands
    const operands = parts.slice(1).join('').split(',').map(s => s.trim()).filter(Boolean);
    
    // Convert to Python
    let pythonLine = '';
    
    switch (mnemonic) {
      case 'MOV':
        if (operands.length >= 2) {
          pythonLine = `${operands[0]} = ${operands[1]}`;
          recordPoleUse(state, 0);
        }
        break;
      case 'LDI':
        if (operands.length >= 2) {
          pythonLine = `${operands[0]} = ${operands[1]}`;
          recordPoleUse(state, 0);
        }
        break;
      case 'ADD':
        if (operands.length >= 2) {
          pythonLine = `${operands[0]} = ${operands[0]} + ${operands[1]}`;
          recordPoleUse(state, 1);
        }
        break;
      case 'SUB':
        if (operands.length >= 2) {
          pythonLine = `${operands[0]} = ${operands[0]} - ${operands[1]}`;
          recordPoleUse(state, 2);
        }
        break;
      case 'MUL':
      case 'LOGMUL':
        if (operands.length >= 2) {
          pythonLine = `${operands[0]} = logmul(${operands[0]}, ${operands[1]})`;
          recordPoleUse(state, 8);
        }
        break;
      case 'DIV':
        if (operands.length >= 2) {
          pythonLine = `${operands[0]} = ${operands[0]} / ${operands[1]}`;
          recordPoleUse(state, 4);
        }
        break;
      case 'OUT':
        if (operands.length >= 2) {
          pythonLine = `print(${operands[1]})`;
          recordPoleUse(state, 2);
        }
        break;
      case 'FBSET':
        pythonLine = `fbset(${operands.join(', ')})`;
        recordPoleUse(state, 3);
        break;
      case 'PRIME':
        if (operands.length >= 1) {
          pythonLine = `${operands[0]} = prime(${operands[0]})`;
          recordPoleUse(state, 7);
        }
        break;
      case 'BAZ':
        if (operands.length >= 1) {
          pythonLine = `${operands[0]} = baz(${operands[0]})`;
          recordPoleUse(state, 9);
        }
        break;
      case 'HALT':
        pythonLine = '# Program end';
        break;
      default:
        pythonLine = `# ${mnemonic} ${operands.join(', ')}`;
    }
    
    if (pythonLine) {
      const indent = '    '.repeat(state.indent);
      state.python.push(`${indent}${pythonLine}`);
    }
  }
  
  // Add footer
  state.python.push('');
  state.python.push('# Pole usage summary');
  state.python.push(`poles_used = [${state.poleUses.join(', ')}]`);
  
  return {
    python: state.python.join('\n'),
    poleUses: state.poleUses,
    lineCount: state.python.length,
    success: errors.length === 0,
    errors,
  };
}

// ============================================
// Two-way Translator
// ============================================

export interface TwoWayTranslation {
  original: string;
  translated: string;
  direction: 'python-to-ppu' | 'ppu-to-python';
  poleUses: number[];
  lineMapping: Map<number, number>;  // Maps lines between representations
}

/**
 * Create bidirectional translation with line mapping
 */
export function createTwoWayTranslation(
  python: string,
  assembly: string,
  bytecode: Uint8Array
): TwoWayTranslation {
  const decompiled = decompilePPUToPython(bytecode);
  
  // Create line mapping
  const lineMapping = new Map<number, number>();
  const pythonLines = python.split('\n').filter(l => l.trim());
  const asmLines = assembly.split('\n').filter(l => l.trim() && !l.trim().startsWith(';'));
  
  // Simple 1:1 mapping (can be enhanced for complex control flow)
  for (let i = 0; i < Math.min(pythonLines.length, asmLines.length); i++) {
    lineMapping.set(i, i);
  }
  
  return {
    original: assembly,
    translated: decompiled.python,
    direction: 'ppu-to-python',
    poleUses: decompiled.poleUses,
    lineMapping,
  };
}
