/**
 * Matrix Selector Grammar for English
 * Implements Seed-Lift-Selector pipeline from Unified Analytic Pipelines paper
 * 
 * F = S · T · E(0)
 * where:
 * - E(0) = seed (token vector)
 * - T = lift (grammar transformation matrix)
 * - S = selector (extraction matrix)
 */

import { VOCABULARY, type WordCategory } from './matrix-vocabulary';

// ============================================
// Matrix Operations
// ============================================

export class Matrix {
  data: Float32Array;
  rows: number;
  cols: number;

  constructor(rows: number, cols: number, data?: Float32Array) {
    this.rows = rows;
    this.cols = cols;
    this.data = data || new Float32Array(rows * cols);
  }

  get(r: number, c: number): number {
    return this.data[r * this.cols + c];
  }

  set(r: number, c: number, v: number): void {
    this.data[r * this.cols + c] = v;
  }

  multiply(other: Matrix): Matrix {
    if (this.cols !== other.rows) {
      throw new Error('Matrix dimensions mismatch');
    }
    
    const result = new Matrix(this.rows, other.cols);
    
    for (let i = 0; i < this.rows; i++) {
      for (let j = 0; j < other.cols; j++) {
        let sum = 0;
        for (let k = 0; k < this.cols; k++) {
          sum += this.get(i, k) * other.get(k, j);
        }
        result.set(i, j, sum);
      }
    }
    
    return result;
  }

  transpose(): Matrix {
    const result = new Matrix(this.cols, this.rows);
    for (let i = 0; i < this.rows; i++) {
      for (let j = 0; j < this.cols; j++) {
        result.set(j, i, this.get(i, j));
      }
    }
    return result;
  }

  static identity(n: number): Matrix {
    const m = new Matrix(n, n);
    for (let i = 0; i < n; i++) {
      m.set(i, i, 1);
    }
    return m;
  }

  static diagonal(values: number[]): Matrix {
    const m = new Matrix(values.length, values.length);
    for (let i = 0; i < values.length; i++) {
      m.set(i, i, values[i]);
    }
    return m;
  }

  static blockDiagonal(blocks: Matrix[]): Matrix {
    const totalSize = blocks.reduce((sum, b) => sum + b.rows, 0);
    const result = new Matrix(totalSize, totalSize);
    
    let offset = 0;
    for (const block of blocks) {
      for (let i = 0; i < block.rows; i++) {
        for (let j = 0; j < block.cols; j++) {
          result.set(offset + i, offset + j, block.get(i, j));
        }
      }
      offset += block.rows;
    }
    
    return result;
  }

  // Rotation block R(c, s) from the paper
  static rotation(c: number, s: number): Matrix {
    const m = new Matrix(2, 2);
    m.set(0, 0, c);  m.set(0, 1, -s);
    m.set(1, 0, s);  m.set(1, 1, c);
    return m;
  }

  // Cycle shift block P_m from the paper
  static cycleShift(m: number): Matrix {
    const mat = new Matrix(m, m);
    for (let i = 0; i < m - 1; i++) {
      mat.set(i + 1, i, 1);
    }
    mat.set(0, m - 1, 1);
    return mat;
  }

  // Affine monodromy block M_π from the paper
  static monodromy(): Matrix {
    const m = new Matrix(2, 2);
    m.set(0, 0, 1);  m.set(0, 1, 2 * Math.PI);
    m.set(1, 0, 0);  m.set(1, 1, 1);
    return m;
  }

  trace(): number {
    if (this.rows !== this.cols) return 0;
    let sum = 0;
    for (let i = 0; i < this.rows; i++) {
      sum += this.get(i, i);
    }
    return sum;
  }

  determinant(): number {
    if (this.rows !== this.cols) return 0;
    if (this.rows === 2) {
      return this.get(0, 0) * this.get(1, 1) - this.get(0, 1) * this.get(1, 0);
    }
    // For larger matrices, use LU decomposition or other method
    // Simplified for now
    return this.pseudoDeterminant();
  }

  // Reduced determinant / pseudodeterminant from the paper
  pseudoDeterminant(): number {
    // Product of non-zero eigenvalues
    // Simplified: just return absolute value of determinant
    return Math.abs(this.determinant());
  }
}

// ============================================
// Grammar Matrices
// ============================================

// English grammar rules encoded as matrices
export const GRAMMAR_MATRICES = {
  // Sentence structure: S → NP VP
  sentence: Matrix.blockDiagonal([
    Matrix.identity(8),  // Noun phrase slots
    Matrix.identity(8),  // Verb phrase slots
  ]),

  // Noun phrase: NP → (Det) (Adj*) N
  nounPhrase: Matrix.blockDiagonal([
    Matrix.identity(2),  // Determiner
    Matrix.identity(4),  // Adjectives
    Matrix.identity(4),  // Noun
  ]),

  // Verb phrase: VP → V (NP) (PP) (Adv*)
  verbPhrase: Matrix.blockDiagonal([
    Matrix.identity(4),  // Verb
    Matrix.identity(8),  // Object NP
    Matrix.identity(4),  // Prepositional phrase
    Matrix.identity(4),  // Adverbs
  ]),

  // Prepositional phrase: PP → P NP
  prepPhrase: Matrix.blockDiagonal([
    Matrix.identity(2),  // Preposition
    Matrix.identity(8),  // NP
  ]),

  // Coordinate structure: X → X conj X
  coordination: new Matrix(3, 3),

  // Relative clause: NP → NP Rel VP
  relativeClause: Matrix.blockDiagonal([
    Matrix.identity(8),  // Base NP
    Matrix.identity(2),  // Relative pronoun
    Matrix.identity(8),  // VP
  ]),
};

// ============================================
// Seed Vector (Token Encoding)
// ============================================

export interface Token {
  word: string;
  category: WordCategory;
  matrixCode: number;
  position: number;
}

export function tokenize(input: string): Token[] {
  const words = input.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 0);
  
  return words.map((word, position) => {
    const entry = VOCABULARY.get(word);
    if (entry) {
      return {
        word,
        category: entry.category,
        matrixCode: entry.matrixCode,
        position,
      };
    }
    // Unknown word - treat as noun with generic code
    return {
      word,
      category: 'noun',
      matrixCode: 0xFFFF,
      position,
    };
  });
}

// ============================================
// Lift Operation (Grammar Transformation)
// ============================================

export interface LiftedStructure {
  tokens: Token[];
  structure: string;
  matrix: Matrix;
  categories: WordCategory[];
}

export function lift(tokens: Token[]): LiftedStructure {
  // Analyze sentence structure
  const categories = tokens.map(t => t.category);
  
  // Identify pattern
  const pattern = identifyPattern(categories);
  
  // Build transformation matrix based on pattern
  const matrix = buildLiftMatrix(pattern, tokens);
  
  return {
    tokens,
    structure: pattern.name,
    matrix,
    categories,
  };
}

interface Pattern {
  name: string;
  matcher: (cats: WordCategory[]) => boolean;
  matrix: Matrix;
}

const PATTERNS: Pattern[] = [
  {
    name: 'imperative_action',
    matcher: (cats) => cats[0] === 'verb' || cats[0] === 'action',
    matrix: Matrix.blockDiagonal([
      Matrix.identity(16),  // Action
      Matrix.identity(32),  // Arguments
    ]),
  },
  {
    name: 'subject_predicate',
    matcher: (cats) => 
      (cats[0] === 'noun' || cats[0] === 'pronoun') &&
      cats.slice(1).some(c => c === 'verb'),
    matrix: Matrix.blockDiagonal([
      Matrix.identity(16),  // Subject
      Matrix.identity(32),  // Predicate
    ]),
  },
  {
    name: 'declaration',
    matcher: (cats) => 
      cats.includes('noun') && cats.includes('verb') && cats.includes('preposition'),
    matrix: Matrix.blockDiagonal([
      Matrix.identity(16),  // Subject
      Matrix.identity(16),  // Verb
      Matrix.identity(16),  // Object/PP
    ]),
  },
  {
    name: 'question',
    matcher: (cats) => 
      cats.includes('pronoun') || cats.includes('determiner'),
    matrix: Matrix.blockDiagonal([
      Matrix.identity(8),   // Question word
      Matrix.identity(32),  // Rest
    ]),
  },
  {
    name: 'generic',
    matcher: () => true,
    matrix: Matrix.identity(64),
  },
];

function identifyPattern(categories: WordCategory[]): Pattern {
  for (const pattern of PATTERNS) {
    if (pattern.matcher(categories)) {
      return pattern;
    }
  }
  return PATTERNS[PATTERNS.length - 1];
}

function buildLiftMatrix(_pattern: Pattern, tokens: Token[]): Matrix {
  // Create a transformation matrix based on token codes
  const size = Math.max(32, tokens.length * 8);
  const matrix = new Matrix(size, size);
  
  // Encode token positions and codes into matrix
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    const code = token.matrixCode & 0xFF;
    
    // Position encoding
    matrix.set(i * 2, i * 2, Math.cos(code * 0.01));
    matrix.set(i * 2, i * 2 + 1, -Math.sin(code * 0.01));
    matrix.set(i * 2 + 1, i * 2, Math.sin(code * 0.01));
    matrix.set(i * 2 + 1, i * 2 + 1, Math.cos(code * 0.01));
  }
  
  return matrix;
}

// ============================================
// Selector Operation (Output Extraction)
// ============================================

export interface SelectedOutput {
  action: string;
  subject?: string;
  object?: string;
  parameters: Record<string, number | string>;
  ppuBytecode: number[];
  confidence: number;
}

export function select(lifted: LiftedStructure): SelectedOutput {
  const { tokens, structure } = lifted;
  
  // Extract components based on structure
  const verb = tokens.find(t => t.category === 'verb' || t.category === 'action');
  const subject = tokens.find(t => t.category === 'noun' && tokens.indexOf(t) < (verb ? tokens.indexOf(verb) : 999));
  const object = tokens.find(t => 
    t.category === 'noun' && 
    verb && 
    tokens.indexOf(t) > tokens.indexOf(verb)
  );
  
  // Extract numbers
  const numbers = tokens
    .filter(t => t.category === 'number')
    .map(t => parseInt(t.word) || 0);
  
  // Extract colors
  const colors = tokens
    .filter(t => t.category === 'adjective' && isColor(t.word))
    .map(t => t.word);
  
  // Extract shapes
  const shapes = tokens
    .filter(t => t.word.match(/circle|square|triangle|rectangle|ellipse|polygon/))
    .map(t => t.word);
  
  // Build parameters
  const parameters: Record<string, number | string> = {};
  if (numbers.length > 0) parameters.value = numbers[0];
  if (numbers.length > 1) parameters.value2 = numbers[1];
  if (colors.length > 0) parameters.color = colors[0];
  if (shapes.length > 0) parameters.shape = shapes[0];
  
  // Generate PPU bytecode
  const ppuBytecode = generatePPUBytecode(verb?.word || 'nop', parameters);
  
  return {
    action: verb?.word || 'unknown',
    subject: subject?.word,
    object: object?.word,
    parameters,
    ppuBytecode,
    confidence: calculateConfidence(tokens, structure),
  };
}

function isColor(word: string): boolean {
  const colors = ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray', 'cyan', 'magenta'];
  return colors.includes(word);
}

function calculateConfidence(tokens: Token[], structure: string): number {
  let score = 0.5;
  
  // Known words increase confidence
  const knownWords = tokens.filter(t => t.matrixCode !== 0xFFFF).length;
  score += (knownWords / tokens.length) * 0.3;
  
  // Recognized structure increases confidence
  if (structure !== 'generic') {
    score += 0.2;
  }
  
  return Math.min(score, 1);
}

// ============================================
// PPU Bytecode Generation
// ============================================

function generatePPUBytecode(action: string, params: Record<string, number | string>): number[] {
  const bytecode: number[] = [];
  
  // Action mapping to opcodes
  const opcodeMap: Record<string, number> = {
    'draw': 0x12, 'paint': 0x12, 'render': 0x12,
    'move': 0x01, 'shift': 0x01, 'translate': 0x01,
    'add': 0x02, 'sum': 0x02,
    'subtract': 0x03, 'sub': 0x03,
    'multiply': 0x04, 'mul': 0x04, 'times': 0x04,
    'divide': 0x05, 'div': 0x05,
    'create': 0x18, 'make': 0x18, 'build': 0x18,
    'destroy': 0xFF, 'delete': 0xFF, 'remove': 0xFF,
    'print': 0x11, 'output': 0x11, 'show': 0x11,
    'rotate': 0x0B, 'spin': 0x0B, 'turn': 0x0B,
    'calculate': 0x1E, 'compute': 0x1E, 'solve': 0x1E,
  };
  
  const opcode = opcodeMap[action] || 0x00;
  bytecode.push(opcode);
  
  // Add parameters
  if (typeof params.value === 'number') {
    bytecode.push(0x0F); // LDI
    bytecode.push(params.value & 0xFF);
    bytecode.push((params.value >> 8) & 0xFF);
  }
  
  if (params.color) {
    const colorValue = colorToHex(params.color as string);
    bytecode.push(0x0F);
    bytecode.push(colorValue & 0xFF);
    bytecode.push((colorValue >> 8) & 0xFF);
    bytecode.push((colorValue >> 16) & 0xFF);
    bytecode.push((colorValue >> 24) & 0xFF);
  }
  
  bytecode.push(0xFF); // HALT
  
  return bytecode;
}

function colorToHex(color: string): number {
  const colors: Record<string, number> = {
    'red': 0xFF0000, 'blue': 0x0000FF, 'green': 0x00FF00,
    'yellow': 0xFFFF00, 'orange': 0xFFA500, 'purple': 0x800080,
    'pink': 0xFFC0CB, 'brown': 0x8B4513, 'black': 0x000000,
    'white': 0xFFFFFF, 'gray': 0x808080, 'cyan': 0x00FFFF,
    'magenta': 0xFF00FF,
  };
  return colors[color] || 0x000000;
}

// ============================================
// Full Pipeline: Seed → Lift → Select
// ============================================

export interface ParsedCommand {
  input: string;
  tokens: Token[];
  structure: string;
  output: SelectedOutput;
  executionResult?: unknown;
}

export function parseNaturalLanguage(input: string): ParsedCommand {
  // Step 1: Seed - Tokenize
  const tokens = tokenize(input);
  
  // Step 2: Lift - Apply grammar transformation
  const lifted = lift(tokens);
  
  // Step 3: Select - Extract meaning
  const output = select(lifted);
  
  return {
    input,
    tokens,
    structure: lifted.structure,
    output,
  };
}

// ============================================
// Multi-Master Stacking (Parallel Processing)
// ============================================

export function parseMultipleCommands(input: string): ParsedCommand[] {
  // Split by sentence delimiters
  const sentences = input
    .split(/[.!?;]+/)
    .map(s => s.trim())
    .filter(s => s.length > 0);
  
  // Parse each sentence
  return sentences.map(parseNaturalLanguage);
}

// ============================================
// Liberated Selector (Full GL_n(C))
// ============================================

export function liberatedSelect(lifted: LiftedStructure, M: Matrix): SelectedOutput {
  // Apply full GL_n(C) transformation
  const transformed = M.multiply(lifted.matrix);
  
  // Extract using trace and skew-entry (from paper)
  const trace = transformed.trace();
  const det = transformed.determinant();
  
  // Use invariants to determine output
  const action = trace > 0 ? 'positive_action' : 'negative_action';
  
  return {
    action,
    parameters: { trace, determinant: det },
    ppuBytecode: [0x00, 0xFF],
    confidence: 0.7,
  };
}
