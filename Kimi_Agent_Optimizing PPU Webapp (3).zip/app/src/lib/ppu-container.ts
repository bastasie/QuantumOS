/**
 * PPU-in-JPEG/GIF Container Format
 * Based on "PPU-in-JPEG: A Secure, Deterministic Execution Environment"
 * Implements marker-based payload storage and gradient levels
 */

import type { 
  PPUContainer, 
  PPUHeader, 
  GradientLevel, 
  TruthTable,
  PPUVMState
} from '@/types';

// ============================================
// Constants
// ============================================

export const MAGIC_PPUJ = new Uint8Array([0x50, 0x50, 0x55, 0x4A]); // "PPUJ"
export const MAGIC_PPUG = new Uint8Array([0x50, 0x50, 0x55, 0x47]); // "PPUG"

export const BLOCK_TYPES = {
  HEADER: 0x01,
  PPU_BYTECODE: 0x02,
  TRUTH_TABLE: 0x03,
  LUT_PALETTE: 0x04,
  STRING_TABLE: 0x05,
  SIGNATURE: 0x06,
} as const;

export const FLAGS = {
  CRC32: 0x01,
  COMPRESSED: 0x02,
  ENCRYPTED: 0x04, // Not used - fail-closed
} as const;

// ============================================
// CRC32 Calculation
// ============================================

const CRC32_TABLE = new Uint32Array(256);

// Initialize CRC32 table
(function initCrc32() {
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    CRC32_TABLE[i] = c;
  }
})();

export function calculateCRC32(data: Uint8Array): number {
  let crc = 0xFFFFFFFF;
  for (const byte of data) {
    crc = CRC32_TABLE[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  }
  return crc ^ 0xFFFFFFFF;
}

// ============================================
// Container Encoding
// ============================================

export function encodePPUContainer(container: PPUContainer): Uint8Array {
  const blocks: Uint8Array[] = [];
  
  // Encode header block
  blocks.push(encodeHeaderBlock(container.header));
  
  // Encode bytecode block
  blocks.push(encodeBytecodeBlock(container.bytecode));
  
  // Encode truth table if present
  if (container.truthTable) {
    blocks.push(encodeTruthTableBlock(container.truthTable));
  }
  
  // Encode palette if present
  if (container.palette) {
    blocks.push(encodePaletteBlock(container.palette));
  }
  
  // Encode signature if present
  if (container.signature) {
    blocks.push(encodeSignatureBlock(container.signature));
  }
  
  // Combine all blocks
  const totalLength = blocks.reduce((sum, b) => sum + b.length, 0);
  const result = new Uint8Array(totalLength);
  let offset = 0;
  
  for (const block of blocks) {
    result.set(block, offset);
    offset += block.length;
  }
  
  return result;
}

function encodeHeaderBlock(header: PPUHeader): Uint8Array {
  const payload = new ArrayBuffer(28);
  const view = new DataView(payload);
  
  view.setUint32(0, header.entryPoint, true);
  view.setUint16(4, header.fbWidth, true);
  view.setUint16(6, header.fbHeight, true);
  view.setUint16(8, header.targetFPS, true);
  view.setUint16(10, header.ioGridX, true);
  view.setUint16(12, header.ioGridY, true);
  view.setUint32(14, header.featureFlags, true);
  view.setUint32(18, 0, true); // reserved
  view.setUint8(22, gradientLevelToByte(header.gradientLevel));
  view.setUint8(23, 0); // reserved
  view.setUint16(24, 0, true); // reserved
  
  return encodeBlock(BLOCK_TYPES.HEADER, new Uint8Array(payload), true);
}

function encodeBytecodeBlock(bytecode: Uint8Array): Uint8Array {
  return encodeBlock(BLOCK_TYPES.PPU_BYTECODE, bytecode, true);
}

function encodeTruthTableBlock(truthTable: TruthTable): Uint8Array {
  // Serialize truth table records
  const entries: Array<[string, number]> = [];
  for (const [key, cmd] of truthTable.records) {
    entries.push([key, cmd]);
  }
  
  // Calculate size: 4 bytes for count + entries
  const entrySize = 8; // 6 bytes key + 2 bytes cmd
  const payload = new Uint8Array(4 + entries.length * entrySize);
  const view = new DataView(payload.buffer);
  
  view.setUint32(0, entries.length, true);
  
  let offset = 4;
  for (const [key, cmd] of entries) {
    const keyBytes = new TextEncoder().encode(key);
    payload.set(keyBytes.slice(0, 6), offset);
    view.setUint16(offset + 6, cmd, true);
    offset += entrySize;
  }
  
  return encodeBlock(BLOCK_TYPES.TRUTH_TABLE, payload, true);
}

function encodePaletteBlock(palette: number[]): Uint8Array {
  const payload = new Uint8Array(palette.length * 4);
  const view = new DataView(payload.buffer);
  
  for (let i = 0; i < palette.length; i++) {
    view.setUint32(i * 4, palette[i], true);
  }
  
  return encodeBlock(BLOCK_TYPES.LUT_PALETTE, payload, true);
}

function encodeSignatureBlock(signature: Uint8Array): Uint8Array {
  return encodeBlock(BLOCK_TYPES.SIGNATURE, signature, true);
}

function encodeBlock(blockType: number, payload: Uint8Array, useCRC: boolean): Uint8Array {
  const headerSize = 12; // Magic(4) + Version(1) + BlockType(1) + Flags(1) + Reserved(1) + Length(4)
  const crcSize = useCRC ? 4 : 0;
  const totalSize = headerSize + payload.length + crcSize;
  
  const block = new Uint8Array(totalSize);
  const view = new DataView(block.buffer);
  
  // Magic
  block.set(MAGIC_PPUJ, 0);
  
  // Version
  block[4] = 0x01;
  
  // Block type
  block[5] = blockType;
  
  // Flags
  block[6] = useCRC ? FLAGS.CRC32 : 0;
  
  // Reserved
  block[7] = 0;
  
  // Payload length
  view.setUint32(8, payload.length, true);
  
  // Payload
  block.set(payload, 12);
  
  // CRC32
  if (useCRC) {
    const crc = calculateCRC32(block.slice(0, headerSize + payload.length));
    view.setUint32(headerSize + payload.length, crc, true);
  }
  
  return block;
}

// ============================================
// Container Decoding
// ============================================

export function decodePPUContainer(data: Uint8Array): PPUContainer | null {
  const blocks = parseBlocks(data);
  if (!blocks) return null;
  
  let header: PPUHeader | null = null;
  let bytecode: Uint8Array | null = null;
  let truthTable: TruthTable | undefined;
  let palette: number[] | undefined;
  let signature: Uint8Array | undefined;
  
  for (const block of blocks) {
    switch (block.type) {
      case BLOCK_TYPES.HEADER:
        header = decodeHeaderBlock(block.payload);
        break;
      case BLOCK_TYPES.PPU_BYTECODE:
        bytecode = block.payload;
        break;
      case BLOCK_TYPES.TRUTH_TABLE:
        truthTable = decodeTruthTableBlock(block.payload);
        break;
      case BLOCK_TYPES.LUT_PALETTE:
        palette = decodePaletteBlock(block.payload);
        break;
      case BLOCK_TYPES.SIGNATURE:
        signature = block.payload;
        break;
    }
  }
  
  if (!header || !bytecode) return null;
  
  return {
    magic: 'PPUJ',
    version: 1,
    header,
    bytecode,
    truthTable,
    palette,
    signature,
  };
}

interface ParsedBlock {
  type: number;
  payload: Uint8Array;
  crcValid: boolean;
}

function parseBlocks(data: Uint8Array): ParsedBlock[] | null {
  const blocks: ParsedBlock[] = [];
  let offset = 0;
  
  while (offset < data.length) {
    // Check minimum block size
    if (offset + 12 > data.length) break;
    
    const view = new DataView(data.buffer, data.byteOffset + offset);
    
    // Check magic
    const magic = data.slice(offset, offset + 4);
    if (!arraysEqual(magic, MAGIC_PPUJ) && !arraysEqual(magic, MAGIC_PPUG)) {
      break;
    }
    
    const version = data[offset + 4];
    if (version !== 0x01) {
      console.warn(`Unknown version: ${version}`);
      break;
    }
    
    const blockType = data[offset + 5];
    const flags = data[offset + 6];
    const payloadLength = view.getUint32(8, true);
    
    const headerSize = 12;
    const useCRC = (flags & FLAGS.CRC32) !== 0;
    const crcSize = useCRC ? 4 : 0;
    const blockSize = headerSize + payloadLength + crcSize;
    
    if (offset + blockSize > data.length) {
      console.warn('Incomplete block');
      break;
    }
    
    const payload = data.slice(offset + headerSize, offset + headerSize + payloadLength);
    
    // Verify CRC
    let crcValid = true;
    if (useCRC) {
      const storedCRC = view.getUint32(headerSize + payloadLength, true);
      const computedCRC = calculateCRC32(data.slice(offset, offset + headerSize + payloadLength));
      crcValid = storedCRC === computedCRC;
    }
    
    blocks.push({ type: blockType, payload, crcValid });
    offset += blockSize;
  }
  
  return blocks;
}

function decodeHeaderBlock(payload: Uint8Array): PPUHeader {
  const view = new DataView(payload.buffer, payload.byteOffset);
  
  return {
    entryPoint: view.getUint32(0, true),
    fbWidth: view.getUint16(4, true),
    fbHeight: view.getUint16(6, true),
    targetFPS: view.getUint16(8, true),
    ioGridX: view.getUint16(10, true),
    ioGridY: view.getUint16(12, true),
    featureFlags: view.getUint32(14, true),
    gradientLevel: byteToGradientLevel(payload[22]),
  };
}

function decodeTruthTableBlock(payload: Uint8Array): TruthTable {
  const view = new DataView(payload.buffer, payload.byteOffset);
  const count = view.getUint32(0, true);
  
  const records = new Map<string, number>();
  let offset = 4;
  
  for (let i = 0; i < count; i++) {
    const keyBytes = payload.slice(offset, offset + 6);
    const key = new TextDecoder().decode(keyBytes).replace(/\0/g, '');
    const cmd = view.getUint16(offset + 6, true);
    records.set(key, cmd);
    offset += 8;
  }
  
  return { records };
}

function decodePaletteBlock(payload: Uint8Array): number[] {
  const palette: number[] = [];
  const view = new DataView(payload.buffer, payload.byteOffset);
  
  for (let i = 0; i < payload.length; i += 4) {
    palette.push(view.getUint32(i, true));
  }
  
  return palette;
}

// ============================================
// Gradient Level Conversion
// ============================================

function gradientLevelToByte(level: GradientLevel): number {
  switch (level) {
    case 'G0_LOSSLESS': return 0;
    case 'G1_CORE_LOSSLESS': return 1;
    case 'G2_RECONSTRUCTIBLE': return 2;
    case 'G3_VISUAL_ONLY': return 3;
    default: return 3;
  }
}

function byteToGradientLevel(byte: number): GradientLevel {
  switch (byte) {
    case 0: return 'G0_LOSSLESS';
    case 1: return 'G1_CORE_LOSSLESS';
    case 2: return 'G2_RECONSTRUCTIBLE';
    case 3: return 'G3_VISUAL_ONLY';
    default: return 'G3_VISUAL_ONLY';
  }
}

// ============================================
// JPEG/GIF Embedding
// ============================================

/**
 * Embed PPU container into JPEG APP15 marker
 */
export function embedInJPEG(imageData: Uint8Array, container: Uint8Array): Uint8Array {
  // Find SOS marker
  let sosIndex = -1;
  for (let i = 0; i < imageData.length - 1; i++) {
    if (imageData[i] === 0xFF && imageData[i + 1] === 0xDA) {
      sosIndex = i;
      break;
    }
  }
  
  if (sosIndex === -1) {
    throw new Error('Invalid JPEG: SOS marker not found');
  }
  
  // Create APP15 marker with container
  const app15Length = 2 + container.length; // 2 bytes for length field
  const app15Marker = new Uint8Array(2 + app15Length);
  app15Marker[0] = 0xFF;
  app15Marker[1] = 0xEF; // APP15
  app15Marker[2] = (app15Length >> 8) & 0xFF;
  app15Marker[3] = app15Length & 0xFF;
  app15Marker.set(container, 4);
  
  // Insert before SOS
  const result = new Uint8Array(sosIndex + app15Marker.length + (imageData.length - sosIndex));
  result.set(imageData.slice(0, sosIndex));
  result.set(app15Marker, sosIndex);
  result.set(imageData.slice(sosIndex), sosIndex + app15Marker.length);
  
  return result;
}

/**
 * Extract PPU container from JPEG
 */
export function extractFromJPEG(imageData: Uint8Array): Uint8Array | null {
  for (let i = 0; i < imageData.length - 1; i++) {
    if (imageData[i] === 0xFF && imageData[i + 1] === 0xEF) {
      // Found APP15 marker
      const length = (imageData[i + 2] << 8) | imageData[i + 3];
      return imageData.slice(i + 4, i + 2 + length);
    }
    
    // Stop at SOS
    if (imageData[i] === 0xFF && imageData[i + 1] === 0xDA) {
      break;
    }
  }
  
  return null;
}

// ============================================
// PPU Virtual Machine
// ============================================

export function createPPUVM(config: {
  fbWidth: number;
  fbHeight: number;
  maxCyclesPerFrame: number;
}): PPUVMState {
  return {
    registers: new Uint32Array(16),
    ram: new Uint8Array(64 * 1024),
    framebuffer: new Uint32Array(config.fbWidth * config.fbHeight),
    pc: 0,
    cycles: 0,
    ioRegisters: {
      cmd: 0,
      tick: 0,
      touchX: 0,
      touchY: 0,
      mode: 0,
    },
  };
}

// Opcodes
const OPCODES = {
  MOV: 0x00,
  ADD: 0x01,
  SUB: 0x02,
  XOR: 0x03,
  AND: 0x04,
  OR: 0x05,
  SHL: 0x06,
  SHR: 0x07,
  LD: 0x08,
  ST: 0x09,
  IN: 0x0A,
  OUT: 0x0B,
  FBSET: 0x0C,
  JMP: 0x0D,
  JZ: 0x0E,
  JNZ: 0x0F,
  HALT: 0xFF,
} as const;

export function executePPUVMCycle(vm: PPUVMState, bytecode: Uint8Array): boolean {
  if (vm.pc >= bytecode.length) return false;
  
  const opcode = bytecode[vm.pc++];
  
  switch (opcode) {
    case OPCODES.MOV: {
      const dst = bytecode[vm.pc++] & 0x0F;
      const src = bytecode[vm.pc++] & 0x0F;
      vm.registers[dst] = vm.registers[src];
      break;
    }
    
    case OPCODES.ADD: {
      const dst = bytecode[vm.pc++] & 0x0F;
      const src = bytecode[vm.pc++] & 0x0F;
      vm.registers[dst] = (vm.registers[dst] + vm.registers[src]) >>> 0;
      break;
    }
    
    case OPCODES.SUB: {
      const dst = bytecode[vm.pc++] & 0x0F;
      const src = bytecode[vm.pc++] & 0x0F;
      vm.registers[dst] = (vm.registers[dst] - vm.registers[src]) >>> 0;
      break;
    }
    
    case OPCODES.XOR: {
      const dst = bytecode[vm.pc++] & 0x0F;
      const src = bytecode[vm.pc++] & 0x0F;
      vm.registers[dst] ^= vm.registers[src];
      break;
    }
    
    case OPCODES.LD: {
      const reg = bytecode[vm.pc++] & 0x0F;
      const addr = (bytecode[vm.pc++] | (bytecode[vm.pc++] << 8)) & 0xFFFF;
      if (addr < vm.ram.length) {
        vm.registers[reg] = vm.ram[addr];
      }
      break;
    }
    
    case OPCODES.ST: {
      const reg = bytecode[vm.pc++] & 0x0F;
      const addr = (bytecode[vm.pc++] | (bytecode[vm.pc++] << 8)) & 0xFFFF;
      if (addr < vm.ram.length) {
        vm.ram[addr] = vm.registers[reg] & 0xFF;
      }
      break;
    }
    
    case OPCODES.IN: {
      const reg = bytecode[vm.pc++] & 0x0F;
      const port = bytecode[vm.pc++];
      switch (port) {
        case 0: vm.registers[reg] = vm.ioRegisters.cmd; break;
        case 1: vm.registers[reg] = vm.ioRegisters.tick; break;
        case 2: vm.registers[reg] = vm.ioRegisters.touchX; break;
        case 3: vm.registers[reg] = vm.ioRegisters.touchY; break;
        case 4: vm.registers[reg] = vm.ioRegisters.mode; break;
      }
      break;
    }
    
    case OPCODES.FBSET: {
      const x = vm.registers[bytecode[vm.pc++] & 0x0F] % Math.sqrt(vm.framebuffer.length);
      const y = vm.registers[bytecode[vm.pc++] & 0x0F] % Math.sqrt(vm.framebuffer.length);
      const color = vm.registers[bytecode[vm.pc++] & 0x0F];
      const idx = y * Math.sqrt(vm.framebuffer.length) + x;
      if (idx < vm.framebuffer.length) {
        vm.framebuffer[idx] = color;
      }
      break;
    }
    
    case OPCODES.JMP: {
      const addr = bytecode[vm.pc++] | (bytecode[vm.pc++] << 8);
      vm.pc = addr;
      break;
    }
    
    case OPCODES.JZ: {
      const reg = bytecode[vm.pc++] & 0x0F;
      const addr = bytecode[vm.pc++] | (bytecode[vm.pc++] << 8);
      if (vm.registers[reg] === 0) {
        vm.pc = addr;
      }
      break;
    }
    
    case OPCODES.HALT:
      return false;
      
    default:
      // Unknown opcode - skip
      break;
  }
  
  vm.cycles++;
  return true;
}

// ============================================
// Utility Functions
// ============================================

function arraysEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

export function createSampleBytecode(): Uint8Array {
  // Simple program: draw a moving dot
  return new Uint8Array([
    OPCODES.IN, 0x01, 0x01,    // IN r1, tick
    OPCODES.IN, 0x00, 0x02,    // IN r0, touchX
    OPCODES.IN, 0x02, 0x03,    // IN r2, touchY
    OPCODES.FBSET, 0x00, 0x02, 0x0F, // FBSET x=r0, y=r2, color=r15
    OPCODES.JMP, 0x00, 0x00,   // JMP 0
  ]);
}
