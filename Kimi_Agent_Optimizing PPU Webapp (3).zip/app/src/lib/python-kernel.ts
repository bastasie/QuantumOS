/**
 * Python Kernel - Pyodide Integration
 * Provides in-browser Python execution with scientific computing stack
 */

import type { PythonKernelState, CodeCell } from '@/types';

// ============================================
// Constants
// ============================================

const PYODIDE_VERSION = '0.29.0';
const PYODIDE_INDEX = `https://cdn.jsdelivr.net/pyodide/v${PYODIDE_VERSION}/full/`;

// ============================================
// Python Kernel Class
// ============================================

export class PythonKernel {
  private state: PythonKernelState;
  private pyodide: any = null;
  // Promise tracking for initialization
  private onStateChange: ((state: PythonKernelState) => void) | null = null;
  
  constructor() {
    this.state = {
      ready: false,
      loading: false,
      status: 'idle',
      lastOutput: '',
      lastError: '',
      lastFigure: null,
    };
  }
  
  setOnStateChange(callback: (state: PythonKernelState) => void): void {
    this.onStateChange = callback;
  }
  
  private updateState(updates: Partial<PythonKernelState>): void {
    this.state = { ...this.state, ...updates };
    this.onStateChange?.(this.state);
  }
  
  getState(): PythonKernelState {
    return { ...this.state };
  }
  
  // ============================================
  // Initialization
  // ============================================
  
  async initialize(): Promise<void> {
    if (this.state.ready || this.state.loading) return;
    
    this.updateState({ loading: true, status: 'loading' });
    
    try {
      // Load Pyodide script
      await this.loadPyodideScript();
      
      // Initialize Pyodide
      this.updateState({ status: 'loading' });
      // @ts-ignore - loadPyodide is loaded from CDN
      this.pyodide = await loadPyodide({ indexURL: PYODIDE_INDEX });
      
      // Load packages
      this.updateState({ status: 'loading' });
      await this.pyodide.loadPackage(['micropip', 'numpy', 'sympy', 'matplotlib', 'pandas']);
      
      // Setup execution environment
      this.updateState({ status: 'ready' });
      await this.setupEnvironment();
      
      this.updateState({ 
        ready: true, 
        loading: false, 
        status: 'ready',
        lastOutput: 'Python kernel ready. Packages: numpy, sympy, matplotlib, pandas'
      });
      
    } catch (error) {
      this.updateState({ 
        loading: false, 
        status: 'error',
        lastError: `Failed to initialize: ${error instanceof Error ? error.message : String(error)}`
      });
      throw error;
    }
  }
  
  private loadPyodideScript(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (document.querySelector('script[src*="pyodide"]')) {
        resolve();
        return;
      }
      
      const script = document.createElement('script');
      script.src = `${PYODIDE_INDEX}pyodide.js`;
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Failed to load Pyodide'));
      document.head.appendChild(script);
    });
  }
  
  private async setupEnvironment(): Promise<void> {
    if (!this.pyodide) return;
    
    await this.pyodide.runPythonAsync(`
import sys
import io
import math
import json
import numpy as np
import sympy as sp
import pandas as pd
import matplotlib
matplotlib.use('AGG')
import matplotlib.pyplot as plt

# PPU-AQC Integration Module
class PPUAQC:
    """Python interface to PPU/AQC computational substrate"""
    
    def __init__(self):
        self.coherence = 0.78
        self.entropy = 0.12
        self.temperature = 0.90
        self.poles = [0.0] * 12
        
    def set_coherence(self, value):
        self.coherence = max(0.0, min(1.0, value))
        
    def get_state(self):
        return {
            'coherence': self.coherence,
            'entropy': self.entropy,
            'temperature': self.temperature,
            'poles': self.poles
        }

# Prime Domain Computation
PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]

def factorize(n):
    """Factorize integer into primes"""
    factors = {}
    remaining = abs(int(n))
    if remaining <= 1:
        return factors
    for prime in PRIMES:
        if prime * prime > remaining:
            break
        exp = 0
        while remaining % prime == 0:
            exp += 1
            remaining //= prime
        if exp > 0:
            factors[prime] = exp
    if remaining > 1:
        factors[remaining] = 1
    return factors

def to_prime_vector(n, num_primes=16):
    """Convert number to prime-exponent vector"""
    factors = factorize(n)
    return [factors.get(p, 0) for p in PRIMES[:num_primes]]

def from_prime_vector(vec):
    """Convert prime-exponent vector to number"""
    result = 1
    for i, exp in enumerate(vec):
        if i < len(PRIMES) and exp > 0:
            result *= PRIMES[i] ** exp
    return result

def log_multiply(a, b):
    """Log-domain multiplication (simulates analog PPU)"""
    if a <= 0 or b <= 0:
        return 0
    return np.exp(np.log(a) + np.log(b))

# Trigonometric Set Theory
def trig_not(x):
    """NOT gate using trigonometric encoding"""
    return (1 + np.cos(np.pi * x)) / 2

def trig_and(x, y):
    """AND gate using trigonometric encoding"""
    return (1 - np.cos(np.pi * x) - np.cos(np.pi * y) + np.cos(np.pi * (x + y))) / 4

def trig_or(x, y):
    """OR gate using trigonometric encoding"""
    return (3 - np.cos(np.pi * x) - np.cos(np.pi * y) - np.cos(np.pi * (x + y))) / 4

def trig_xor(x, y):
    """XOR gate using trigonometric encoding"""
    return (1 - np.cos(np.pi * (x + y))) / 2

# Modular Entropy
def modular_entropy(E, T, beta=None):
    """Calculate modular entropy with feedback"""
    if beta is None:
        beta = 1.0 / (1.380649e-23 * T) if T > 0 else 0
    
    kB = 1.380649e-23
    
    # Modified energy term
    delta_E = -kB * T * np.log(np.cos(np.log(E) / (np.pi * E) * np.pi / 2))
    
    # Simplified entropy expression
    S = kB * beta * E + delta_E
    
    return S

def feedback_modulation(E0, alpha, omega, t, phi):
    """Feedback-controlled energy modulation"""
    return E0 * (1 + alpha * np.sin(omega * t + phi))

# Create global instances
ppu_aqc = PPUAQC()

# Execution helper
__calc_atom_globals = globals()

def __calc_atom_exec__(code: str):
    """Execute code cell and capture output"""
    buf_out = io.StringIO()
    buf_err = io.StringIO()
    _stdout, _stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = buf_out, buf_err
    
    try:
        exec(code, __calc_atom_globals, __calc_atom_globals)
        
        # Capture any matplotlib figure
        img_bytes = None
        if plt.get_fignums():
            import base64
            import tempfile
            import os
            
            fig = plt.gcf()
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
            tmp.close()
            fig.savefig(tmp.name, dpi=140, bbox_inches='tight', facecolor='black', edgecolor='none')
            
            with open(tmp.name, 'rb') as f:
                img_bytes = base64.b64encode(f.read()).decode('ascii')
            os.unlink(tmp.name)
            plt.close('all')
        
        return {
            'ok': True,
            'out': buf_out.getvalue(),
            'err': buf_err.getvalue(),
            'img_b64': img_bytes
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {
            'ok': False,
            'out': buf_out.getvalue(),
            'err': buf_err.getvalue() + traceback.format_exc(),
            'img_b64': None
        }
    finally:
        sys.stdout, sys.stderr = _stdout, _stderr
`);
  }
  
  // ============================================
  // Code Execution
  // ============================================
  
  async executeCode(code: string): Promise<CodeCell> {
    if (!this.state.ready) {
      await this.initialize();
    }
    
    this.updateState({ status: 'running' });
    
    const cell: CodeCell = {
      id: `cell_${Date.now()}`,
      code,
      output: '',
      error: '',
      figure: null,
      timestamp: Date.now(),
    };
    
    try {
      const result = await this.pyodide.runPythonAsync(
        `__calc_atom_exec__(${JSON.stringify(code)})`
      );
      
      cell.output = result.out || '';
      cell.error = result.err || '';
      cell.figure = result.img_b64 || null;
      
      this.updateState({
        status: 'ready',
        lastOutput: cell.output,
        lastError: cell.error,
        lastFigure: cell.figure,
      });
      
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      cell.error = errorMsg;
      
      this.updateState({
        status: 'error',
        lastError: errorMsg,
      });
    }
    
    return cell;
  }
  
  // ============================================
  // File System Operations
  // ============================================
  
  async writeFile(path: string, data: Uint8Array): Promise<void> {
    if (!this.pyodide) throw new Error('Kernel not ready');
    this.pyodide.FS.writeFile(path, data);
  }
  
  async readFile(path: string): Promise<Uint8Array> {
    if (!this.pyodide) throw new Error('Kernel not ready');
    return this.pyodide.FS.readFile(path);
  }
  
  listFiles(path: string = '/'): string[] {
    if (!this.pyodide) return [];
    try {
      return this.pyodide.FS.readdir(path).filter((x: string) => x !== '.' && x !== '..');
    } catch {
      return [];
    }
  }
  
  // ============================================
  // Package Installation
  // ============================================
  
  async installPackage(packageName: string): Promise<void> {
    if (!this.state.ready) await this.initialize();
    
    this.updateState({ status: 'running' });
    
    try {
      await this.pyodide.runPythonAsync(`
import micropip
await micropip.install(${JSON.stringify(packageName)})
`);
      this.updateState({ 
        status: 'ready',
        lastOutput: `Installed package: ${packageName}`
      });
    } catch (error) {
      this.updateState({
        status: 'error',
        lastError: `Failed to install ${packageName}: ${error instanceof Error ? error.message : String(error)}`
      });
      throw error;
    }
  }
  
  // ============================================
  // Reset
  // ============================================
  
  reset(): void {
    this.updateState({
      lastOutput: '',
      lastError: '',
      lastFigure: null,
    });
  }
  
  // ============================================
  // PPU-AQC Integration
  // ============================================
  
  async setPPUCoherence(value: number): Promise<void> {
    if (!this.pyodide) return;
    await this.pyodide.runPythonAsync(`ppu_aqc.set_coherence(${value})`);
  }
  
  async getPPUState(): Promise<Record<string, unknown>> {
    if (!this.pyodide) return {};
    const result = await this.pyodide.runPythonAsync('ppu_aqc.get_state()');
    return result.toJs ? result.toJs() : result;
  }
}

// Singleton instance
let kernelInstance: PythonKernel | null = null;

export function getPythonKernel(): PythonKernel {
  if (!kernelInstance) {
    kernelInstance = new PythonKernel();
  }
  return kernelInstance;
}
