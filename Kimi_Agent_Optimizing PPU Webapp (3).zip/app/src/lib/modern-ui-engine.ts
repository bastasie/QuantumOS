/**
 * Modern UI Engine v8 - Comprehensive Update
 */

import { compilePythonToPPU } from './python-to-ppu-compiler';
import { decompileAssemblyToPython } from './ppu-to-python-decompiler';
import { calculate } from './symbolic-math';
import { parseNaturalLanguage } from './matrix-grammar';

export type AppMode = 'dashboard' | 'python' | 'ppu' | 'nl' | 'prime' | 'qai' | 'entropy' | 'glyph' | 'compiler' | 'decompiler' | 'calc' | 'matrix' | 'poetry' | 'symbols' | 'visual' | 'spectrum' | 'settings' | 'trig' | 'complex' | 'diffeq' | 'stats' | 'logs';
export type AppCategory = 'core' | 'theory' | 'tools' | 'visual' | 'math';

export interface AppDefinition {
  mode: AppMode;
  name: string;
  icon: string;
  category: AppCategory;
  color: string;
  description: string;
  page: number;
}

export type UIElementType = 'button' | 'text' | 'code' | 'tab' | 'panel' | 'visualizer' | 'cursor' | 'key' | 'list' | 'input' | 'card';

export interface UIElement {
  id: string;
  type: UIElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  text: string;
  color: number;
  bgColor: number;
  active: boolean;
  selected: boolean;
  action?: string;
  data?: any;
}

export interface ModernUIState {
  mode: AppMode;
  category: AppCategory;
  currentPage: number;
  totalPages: number;
  elements: UIElement[];
  code: string;
  output: string[];
  cursor: { x: number; y: number; blink: boolean; blinkTime: number };
  touch: { x: number; y: number; active: boolean; pressure: number; element: string | null };
  scrollOffset: number;
  selectedElement: string | null;
  keyboardVisible: boolean;
  frameCount: number;
  fps: number;
  screenScale: number;
  buttonSize: number;
  fontScale: number;
  selectedOp: string | null;
  poetryLoaded: boolean;
  vocabularyLoaded: boolean;
  grammarLoaded: boolean;
  lastResult: any;
  animTime: number;
  calcMemory: number;
  calcHistory: string[];
}

const BASE_WIDTH = 1024;
const BASE_HEIGHT = 1024;
const NUM_POLES = 12;

const PALETTE = {
  bgDark: 0x0a0a0f, bgPanel: 0x151520, bgCard: 0x1e1e2e, bgElevated: 0x252535,
  gradientPrimary: [0x6366f1, 0x8b5cf6, 0xa855f7], gradientSecondary: [0x06b6d4, 0x3b82f6, 0x6366f1],
  gradientAccent: [0x10b981, 0x14b8a6, 0x06b6d4], gradientWarm: [0xf59e0b, 0xf97316, 0xef4444],
  gradientCool: [0xec4899, 0xa855f7, 0x6366f1], core: 0x6366f1, theory: 0x8b5cf6,
  tools: 0x10b981, visual: 0x06b6d4, math: 0xf59e0b, textPrimary: 0xf8fafc,
  textSecondary: 0x94a3b8, textMuted: 0x64748b, success: 0x22c55e, warning: 0xf59e0b,
  error: 0xef4444, info: 0x3b82f6, button: 0x334155, buttonHover: 0x475569,
  buttonActive: 0x6366f1, keyNormal: 0x374151, glassBg: 0x1e293b, glassBorder: 0x475569,
  cursor: 0xffffff, accent: 0x6366f1,
};

const APPS: AppDefinition[] = [
  { mode: 'dashboard', name: 'Dashboard', icon: 'DB', category: 'core', color: '#6366f1', description: 'System overview', page: 1 },
  { mode: 'python', name: 'Python', icon: 'PY', category: 'core', color: '#10b981', description: 'Python compiler', page: 1 },
  { mode: 'ppu', name: 'PPU', icon: 'PU', category: 'core', color: '#f59e0b', description: 'PPU Assembly', page: 1 },
  { mode: 'nl', name: 'Natural', icon: 'NL', category: 'core', color: '#ec4899', description: 'NL to PPU', page: 1 },
  { mode: 'prime', name: 'Prime', icon: 'PM', category: 'theory', color: '#8b5cf6', description: 'Prime Domain', page: 2 },
  { mode: 'qai', name: 'QAI', icon: 'QA', category: 'theory', color: '#3b82f6', description: 'Trio Operators', page: 2 },
  { mode: 'entropy', name: 'Entropy', icon: 'EN', category: 'theory', color: '#f97316', description: 'Entropy System', page: 2 },
  { mode: 'glyph', name: 'Glyph', icon: 'GL', category: 'theory', color: '#14b8a6', description: 'Glyph Theory', page: 2 },
  { mode: 'compiler', name: 'Compile', icon: 'CP', category: 'tools', color: '#10b981', description: 'Py to PPU', page: 3 },
  { mode: 'decompiler', name: 'Decompile', icon: 'DC', category: 'tools', color: '#06b6d4', description: 'PPU to Py', page: 3 },
  { mode: 'calc', name: 'Calc', icon: 'CA', category: 'tools', color: '#6366f1', description: 'Calculator', page: 3 },
  { mode: 'matrix', name: 'Matrix', icon: 'MX', category: 'tools', color: '#8b5cf6', description: 'Matrix Grammar', page: 3 },
  { mode: 'trig', name: 'Trig', icon: 'TR', category: 'math', color: '#f59e0b', description: 'Trigonometry', page: 4 },
  { mode: 'complex', name: 'Complex', icon: 'CX', category: 'math', color: '#ec4899', description: 'Complex Numbers', page: 4 },
  { mode: 'diffeq', name: 'DiffEq', icon: 'DE', category: 'math', color: '#14b8a6', description: 'Differential Eq', page: 4 },
  { mode: 'stats', name: 'Stats', icon: 'ST', category: 'math', color: '#3b82f6', description: 'Statistics', page: 4 },
  { mode: 'poetry', name: 'Poetry', icon: 'PO', category: 'tools', color: '#f59e0b', description: 'Arabic Poetry', page: 5 },
  { mode: 'symbols', name: 'Symbols', icon: 'SY', category: 'tools', color: '#ec4899', description: 'Math Library', page: 5 },
  { mode: 'visual', name: 'Poles', icon: 'PL', category: 'visual', color: '#6366f1', description: '12-Pole Viz', page: 5 },
  { mode: 'spectrum', name: 'Spectrum', icon: 'SP', category: 'visual', color: '#8b5cf6', description: 'Spectral Analysis', page: 5 },
  { mode: 'logs', name: 'Logs', icon: 'LG', category: 'tools', color: '#10b981', description: 'System Logs', page: 5 },
  { mode: 'settings', name: 'Settings', icon: 'SE', category: 'visual', color: '#64748b', description: 'Settings', page: 5 },
];

const KEYBOARD_ROWS = [
  ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';'],
  ['Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/'],
  ['SPACE', 'ENTER', 'BACK', 'CLR'],
];

const FONT_DATA: Record<string, number[]> = {
  'A': [0b01110,0b10001,0b10001,0b11111,0b10001,0b10001,0b10001], 'B': [0b11110,0b10001,0b10001,0b11110,0b10001,0b10001,0b11110],
  'C': [0b01110,0b10001,0b10000,0b10000,0b10000,0b10001,0b01110], 'D': [0b11110,0b10001,0b10001,0b10001,0b10001,0b10001,0b11110],
  'E': [0b11111,0b10000,0b10000,0b11110,0b10000,0b10000,0b11111], 'F': [0b11111,0b10000,0b10000,0b11110,0b10000,0b10000,0b10000],
  'G': [0b01110,0b10001,0b10000,0b10011,0b10001,0b10001,0b01110], 'H': [0b10001,0b10001,0b10001,0b11111,0b10001,0b10001,0b10001],
  'I': [0b01110,0b00100,0b00100,0b00100,0b00100,0b00100,0b01110], 'J': [0b00001,0b00001,0b00001,0b00001,0b10001,0b10001,0b01110],
  'K': [0b10001,0b10010,0b10100,0b11000,0b10100,0b10010,0b10001], 'L': [0b10000,0b10000,0b10000,0b10000,0b10000,0b10000,0b11111],
  'M': [0b10001,0b11011,0b10101,0b10001,0b10001,0b10001,0b10001], 'N': [0b10001,0b11001,0b10101,0b10011,0b10001,0b10001,0b10001],
  'O': [0b01110,0b10001,0b10001,0b10001,0b10001,0b10001,0b01110], 'P': [0b11110,0b10001,0b10001,0b11110,0b10000,0b10000,0b10000],
  'Q': [0b01110,0b10001,0b10001,0b10001,0b10101,0b10010,0b01101], 'R': [0b11110,0b10001,0b10001,0b11110,0b10100,0b10010,0b10001],
  'S': [0b01111,0b10000,0b10000,0b01110,0b00001,0b00001,0b11110], 'T': [0b11111,0b00100,0b00100,0b00100,0b00100,0b00100,0b00100],
  'U': [0b10001,0b10001,0b10001,0b10001,0b10001,0b10001,0b01110], 'V': [0b10001,0b10001,0b10001,0b10001,0b10001,0b01010,0b00100],
  'W': [0b10001,0b10001,0b10001,0b10101,0b10101,0b10101,0b01010], 'X': [0b10001,0b10001,0b01010,0b00100,0b01010,0b10001,0b10001],
  'Y': [0b10001,0b10001,0b10001,0b01010,0b00100,0b00100,0b00100], 'Z': [0b11111,0b00001,0b00010,0b00100,0b01000,0b10000,0b11111],
  'a': [0b00000,0b00000,0b01110,0b00001,0b01111,0b10001,0b01111], 'b': [0b10000,0b10000,0b10110,0b11001,0b10001,0b10001,0b11110],
  'c': [0b00000,0b00000,0b01110,0b10000,0b10000,0b10001,0b01110], 'd': [0b00001,0b00001,0b01101,0b10011,0b10001,0b10001,0b01111],
  'e': [0b00000,0b00000,0b01110,0b10001,0b11111,0b10000,0b01110], 'f': [0b00000,0b00110,0b01001,0b01110,0b01000,0b01000,0b01000],
  'g': [0b00000,0b01111,0b10001,0b10001,0b01111,0b00001,0b01110], 'h': [0b10000,0b10000,0b10110,0b11001,0b10001,0b10001,0b10001],
  'i': [0b00100,0b00000,0b01100,0b00100,0b00100,0b00100,0b01110], 'j': [0b00010,0b00000,0b00110,0b00010,0b00010,0b10010,0b01100],
  'k': [0b10000,0b10000,0b10010,0b10100,0b11000,0b10100,0b10010], 'l': [0b01100,0b00100,0b00100,0b00100,0b00100,0b00100,0b01110],
  'm': [0b00000,0b00000,0b11010,0b10101,0b10101,0b10001,0b10001], 'n': [0b00000,0b00000,0b10110,0b11001,0b10001,0b10001,0b10001],
  'o': [0b00000,0b00000,0b01110,0b10001,0b10001,0b10001,0b01110], 'p': [0b00000,0b00000,0b11110,0b10001,0b11110,0b10000,0b10000],
  'q': [0b00000,0b00000,0b01111,0b10001,0b01111,0b00001,0b00001], 'r': [0b00000,0b00000,0b10110,0b11001,0b10000,0b10000,0b10000],
  's': [0b00000,0b00000,0b01111,0b10000,0b01110,0b00001,0b11110], 't': [0b01000,0b01000,0b11100,0b01000,0b01000,0b01001,0b00110],
  'u': [0b00000,0b00000,0b10001,0b10001,0b10001,0b10011,0b01101], 'v': [0b00000,0b00000,0b10001,0b10001,0b10001,0b01010,0b00100],
  'w': [0b00000,0b00000,0b10001,0b10001,0b10101,0b10101,0b01010], 'x': [0b00000,0b00000,0b10001,0b01010,0b00100,0b01010,0b10001],
  'y': [0b00000,0b00000,0b10001,0b10001,0b01111,0b00001,0b01110], 'z': [0b00000,0b00000,0b11111,0b00010,0b00100,0b01000,0b11111],
  '0': [0b01110,0b10011,0b10101,0b10101,0b10101,0b11001,0b01110], '1': [0b00100,0b01100,0b00100,0b00100,0b00100,0b00100,0b01110],
  '2': [0b01110,0b10001,0b00001,0b00010,0b00100,0b01000,0b11111], '3': [0b11111,0b00010,0b00100,0b00010,0b00001,0b10001,0b01110],
  '4': [0b00010,0b00110,0b01010,0b10010,0b11111,0b00010,0b00010], '5': [0b11111,0b10000,0b11110,0b00001,0b00001,0b10001,0b01110],
  '6': [0b01110,0b10001,0b10000,0b11110,0b10001,0b10001,0b01110], '7': [0b11111,0b00001,0b00010,0b00100,0b01000,0b01000,0b01000],
  '8': [0b01110,0b10001,0b10001,0b01110,0b10001,0b10001,0b01110], '9': [0b01110,0b10001,0b10001,0b01111,0b00001,0b10001,0b01110],
  ' ': [0b00000,0b00000,0b00000,0b00000,0b00000,0b00000,0b00000], '.': [0b00000,0b00000,0b00000,0b00000,0b00000,0b01100,0b01100],
  ',': [0b00000,0b00000,0b00000,0b00000,0b01100,0b00100,0b01000], '!': [0b00100,0b00100,0b00100,0b00100,0b00100,0b00000,0b00100],
  '?': [0b01110,0b10001,0b00001,0b00010,0b00100,0b00000,0b00100], '+': [0b00000,0b00100,0b00100,0b11111,0b00100,0b00100,0b00000],
  '-': [0b00000,0b00000,0b00000,0b11111,0b00000,0b00000,0b00000], '*': [0b00000,0b10001,0b01010,0b00100,0b01010,0b10001,0b00000],
  '/': [0b00000,0b00001,0b00010,0b00100,0b01000,0b10000,0b00000], '=': [0b00000,0b11111,0b00000,0b11111,0b00000,0b00000,0b00000],
  '(': [0b00010,0b00100,0b01000,0b01000,0b01000,0b00100,0b00010], ')': [0b01000,0b00100,0b00010,0b00010,0b00010,0b00100,0b01000],
  '[': [0b01110,0b01000,0b01000,0b01000,0b01000,0b01000,0b01110], ']': [0b01110,0b00010,0b00010,0b00010,0b00010,0b00010,0b01110],
  '{': [0b00010,0b00100,0b00100,0b01000,0b00100,0b00100,0b00010], '}': [0b01000,0b00100,0b00100,0b00010,0b00100,0b00100,0b01000],
  '<': [0b00010,0b00100,0b01000,0b10000,0b01000,0b00100,0b00010], '>': [0b01000,0b00100,0b00010,0b00001,0b00010,0b00100,0b01000],
  ':': [0b00000,0b01100,0b01100,0b00000,0b01100,0b01100,0b00000], ';': [0b00000,0b01100,0b01100,0b00000,0b01100,0b00100,0b01000],
  '"': [0b01010,0b01010,0b00000,0b00000,0b00000,0b00000,0b00000], "'": [0b00100,0b00100,0b00000,0b00000,0b00000,0b00000,0b00000],
  '_': [0b00000,0b00000,0b00000,0b00000,0b00000,0b00000,0b11111], '|': [0b00100,0b00100,0b00100,0b00100,0b00100,0b00100,0b00100],
  '^': [0b00100,0b01010,0b10001,0b00000,0b00000,0b00000,0b00000], '~': [0b00000,0b00000,0b01000,0b10101,0b00010,0b00000,0b00000],
  '`': [0b01000,0b00100,0b00000,0b00000,0b00000,0b00000,0b00000], '@': [0b01110,0b10001,0b10111,0b10101,0b10111,0b10000,0b01110],
  '#': [0b01010,0b01010,0b11111,0b01010,0b11111,0b01010,0b01010], '$': [0b00100,0b01111,0b10100,0b01110,0b00101,0b11110,0b00100],
  '%': [0b11000,0b11001,0b00010,0b00100,0b01000,0b10011,0b00011], '&': [0b01100,0b10010,0b10100,0b01010,0b10101,0b10001,0b01110],
  'DB': [0b11111,0b10001,0b10001,0b10001,0b10001,0b10001,0b11111], 'PY': [0b11110,0b10001,0b10001,0b11110,0b10000,0b10000,0b10000],
  'PU': [0b10001,0b10001,0b10001,0b10001,0b10001,0b10001,0b01110], 'NL': [0b10001,0b10001,0b10001,0b01010,0b00100,0b00100,0b00100],
  'PM': [0b11111,0b01010,0b01010,0b01010,0b01010,0b01010,0b01010], 'QA': [0b00100,0b01110,0b10101,0b00100,0b01010,0b10001,0b00000],
  'EN': [0b11111,0b10000,0b11110,0b10000,0b10000,0b10000,0b11111], 'GL': [0b00100,0b01110,0b10101,0b10101,0b01110,0b00100,0b00100],
  'CP': [0b01110,0b10001,0b10000,0b10000,0b10001,0b10001,0b01110], 'DC': [0b01110,0b10001,0b10000,0b10001,0b10001,0b10001,0b01110],
  'CA': [0b01110,0b10001,0b10001,0b11111,0b10001,0b10001,0b10001], 'MX': [0b10001,0b11011,0b10101,0b10001,0b10001,0b10001,0b10001],
  'TR': [0b11111,0b00100,0b00100,0b00100,0b00100,0b00100,0b00100], 'CX': [0b10001,0b01010,0b00100,0b01010,0b10001,0b00000,0b00000],
  'DE': [0b11111,0b10000,0b11110,0b10000,0b10000,0b10000,0b11111], 'ST': [0b00100,0b01110,0b10101,0b00100,0b00100,0b00100,0b00100],
  'PO': [0b01110,0b10001,0b10001,0b10001,0b10001,0b10001,0b01110], 'SY': [0b01111,0b10000,0b10000,0b01110,0b00001,0b00001,0b11110],
  'PL': [0b11111,0b10001,0b10001,0b10001,0b10001,0b10001,0b11111], 'SP': [0b10101,0b01010,0b10101,0b01010,0b10101,0b01010,0b10101],
  'LG': [0b01110,0b10000,0b10100,0b10100,0b10100,0b10000,0b01110], 'SE': [0b01110,0b10001,0b10000,0b01110,0b00001,0b10001,0b01110],
};

// ============================================
// Modern UI Engine Class
// ============================================

export class ModernUIEngine {
  private state: ModernUIState;
  private pixels: Uint8ClampedArray;
  private fieldA: Float32Array;
  private fieldB: Float32Array;
  private poles: { positions: Float32Array; velocities: Float32Array; phases: Float32Array; amplitudes: Float32Array; coherence: number; entropy: number };
  private clock: { tick: number; phase: number; frequency: number };
  private frameTimes: number[] = [];
  private font: Map<string, number[]> = new Map();
  private touchStartTime: number = 0;
  private touchStartPos: { x: number; y: number } = { x: 0, y: 0 };
  
  constructor() {
    this.state = this.createInitialState();
    const size = BASE_WIDTH * BASE_HEIGHT;
    this.pixels = new Uint8ClampedArray(size * 4);
    this.pixels.fill(0);
    this.fieldA = new Float32Array(size).map(() => 0.1 + Math.random() * 0.05);
    this.fieldB = new Float32Array(size).map(() => 0.08 + Math.random() * 0.05);
    this.poles = {
      positions: new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 2),
      velocities: new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 0.1),
      phases: new Float32Array(NUM_POLES).map((_, i) => (i / NUM_POLES) * Math.PI * 2),
      amplitudes: new Float32Array(NUM_POLES).fill(1.0),
      coherence: 0.78,
      entropy: 0.12,
    };
    this.clock = { tick: 0, phase: 0, frequency: 60 };
    this.initFont();
    this.calibrateScreen(BASE_WIDTH, BASE_HEIGHT);
    this.buildUI();
  }
  
  private createInitialState(): ModernUIState {
    return {
      mode: 'dashboard', category: 'core', currentPage: 1, totalPages: 5, elements: [],
      code: '', output: ['PPU-AQC Platform v8.0', 'All systems operational', 'Touch to begin'],
      cursor: { x: 0, y: 0, blink: true, blinkTime: 0 },
      touch: { x: 0, y: 0, active: false, pressure: 0, element: null },
      scrollOffset: 0, selectedElement: null, keyboardVisible: false,
      frameCount: 0, fps: 60, screenScale: 1, buttonSize: 56, fontScale: 1,
      selectedOp: null, poetryLoaded: false, vocabularyLoaded: false, grammarLoaded: false,
      lastResult: null, animTime: 0, calcMemory: 0, calcHistory: [],
    };
  }
  
  calibrateScreen(screenWidth: number, screenHeight: number): void {
    const minDim = Math.min(screenWidth, screenHeight);
    const baseScale = minDim / BASE_WIDTH;
    const minButtonSize = 48;
    const desiredButtonSize = Math.max(minButtonSize, Math.floor(56 * baseScale));
    this.state.screenScale = desiredButtonSize / 56;
    this.state.buttonSize = desiredButtonSize;
    this.state.fontScale = Math.max(0.85, Math.min(1.3, this.state.screenScale));
    this.buildUI();
  }
  
  setCanvasSize(width: number, height: number): void {
    this.calibrateScreen(width, height);
  }
  
  getDimensions(): { width: number; height: number } {
    return { width: BASE_WIDTH, height: BASE_HEIGHT };
  }
  
  private initFont(): void {
    for (const [char, data] of Object.entries(FONT_DATA)) {
      this.font.set(char, data);
    }
  }
  
  private buildUI(): void {
    this.state.elements = [];
    switch (this.state.mode) {
      case 'dashboard': this.buildDashboardUI(); break;
      case 'python': this.buildPythonUI(); break;
      case 'ppu': this.buildPPUUI(); break;
      case 'nl': this.buildNLUI(); break;
      case 'prime': this.buildPrimeUI(); break;
      case 'qai': this.buildQAIUI(); break;
      case 'entropy': this.buildEntropyUI(); break;
      case 'glyph': this.buildGlyphUI(); break;
      case 'compiler': this.buildCompilerUI(); break;
      case 'decompiler': this.buildDecompilerUI(); break;
      case 'calc': this.buildCalcUI(); break;
      case 'matrix': this.buildMatrixUI(); break;
      case 'poetry': this.buildPoetryUI(); break;
      case 'symbols': this.buildSymbolsUI(); break;
      case 'visual': this.buildVisualUI(); break;
      case 'spectrum': this.buildSpectrumUI(); break;
      case 'settings': this.buildSettingsUI(); break;
      case 'trig': this.buildTrigUI(); break;
      case 'complex': this.buildComplexUI(); break;
      case 'diffeq': this.buildDiffEqUI(); break;
      case 'stats': this.buildStatsUI(); break;
      case 'logs': this.buildLogsUI(); break;
    }
  }
  
  private buildDashboardUI(): void {
    this.addElement('header', 'panel', 0, 0, BASE_WIDTH, 80, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('title', 'text', 20, 25, 200, 30, 'PPU-AQC v8', PALETTE.textPrimary, 0);
    this.addElement('subtitle', 'text', 20, 55, 300, 20, 'Modern Unified Platform', PALETTE.textSecondary, 0);
    this.addElement('page_indicator', 'text', BASE_WIDTH - 150, 30, 100, 20, `Page ${this.state.currentPage}/5`, PALETTE.textMuted, 0);
    this.addElement('coherence_status', 'text', BASE_WIDTH - 200, 55, 180, 20, `Coh: ${(this.poles.coherence * 100).toFixed(1)}%`, PALETTE.success, 0);
    
    const pageApps = APPS.filter(a => a.page === this.state.currentPage);
    const cardWidth = 220, cardHeight = 160, cardsPerRow = 4;
    const startX = 42, startY = 120;
    
    for (let i = 0; i < pageApps.length; i++) {
      const row = Math.floor(i / cardsPerRow), col = i % cardsPerRow;
      const x = startX + col * (cardWidth + 24), y = startY + row * (cardHeight + 24);
      const app = pageApps[i];
      const color = parseInt(app.color.replace('#', '0x'));
      
      // Card background (clickable)
      this.addElement(`card_${app.mode}`, 'card', x, y, cardWidth, cardHeight, '', PALETTE.textPrimary, PALETTE.bgCard);
      
      // App icon (centered)
      const iconX = x + cardWidth/2 - 12;
      this.addElement(`icon_${app.mode}`, 'text', iconX, y + 30, 40, 30, app.icon, color, 0);
      
      // App name (centered below icon)
      const nameX = x + cardWidth/2 - app.name.length * 6;
      this.addElement(`name_${app.mode}`, 'text', nameX, y + 80, cardWidth - 20, 20, app.name, PALETTE.textPrimary, 0);
      
      // App description (centered below name)
      const desc = app.description.substring(0, 22);
      const descX = x + cardWidth/2 - desc.length * 5;
      this.addElement(`desc_${app.mode}`, 'text', descX, y + 110, cardWidth - 20, 15, desc, PALETTE.textSecondary, 0);
      
      // Click area (transparent overlay for touch)
      this.addElement(`click_${app.mode}`, 'button', x, y, cardWidth, cardHeight, '', PALETTE.textPrimary, 0, `mode:${app.mode}`);
    }
    
    const navY = BASE_HEIGHT - 100;
    if (this.state.currentPage > 1) {
      this.addElement('btn_prev', 'button', 20, navY, 120, 45, '<- PREV', PALETTE.textPrimary, PALETTE.button, 'action:prev_page');
    }
    if (this.state.currentPage < this.state.totalPages) {
      this.addElement('btn_next', 'button', BASE_WIDTH - 140, navY, 120, 45, 'NEXT ->', PALETTE.textPrimary, PALETTE.button, 'action:next_page');
    }
    
    this.addElement('footer', 'panel', 0, BASE_HEIGHT - 50, BASE_WIDTH, 50, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('footer_text', 'text', 20, BASE_HEIGHT - 35, 400, 20, 'Touch app to launch', PALETTE.textSecondary, 0);
    this.addElement('fps_text', 'text', BASE_WIDTH - 100, BASE_HEIGHT - 35, 80, 20, `${this.state.fps} FPS`, PALETTE.textMuted, 0);
  }
  
  private buildStandardHeader(title: string): void {
    this.addElement('header_bg', 'panel', 0, 0, BASE_WIDTH, 70, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('header_title', 'text', 20, 25, 400, 30, title, PALETTE.textPrimary, 0);
    const app = APPS.find(a => a.mode === this.state.mode);
    if (app) this.addElement('mode_icon', 'text', BASE_WIDTH - 150, 22, 40, 30, app.icon, parseInt(app.color.replace('#', '0x')), 0);
  }
  
  private buildVirtualKeyboard(yPos: number): void {
    const kbHeight = 220;
    const keyHeight = 36, keyMargin = 6;
    const startX = 30;
    
    // Keyboard background
    this.addElement('kb_bg', 'panel', 0, yPos, BASE_WIDTH, kbHeight, '', PALETTE.textPrimary, PALETTE.bgPanel);
    
    // Row 0: Numbers (10 keys)
    const numKeys = KEYBOARD_ROWS[0];
    const numKeyWidth = 85;
    for (let col = 0; col < numKeys.length; col++) {
      const key = numKeys[col];
      const x = startX + col * (numKeyWidth + keyMargin);
      const y = yPos + 10;
      this.addElement(`key_r0_${col}`, 'key', x, y, numKeyWidth, keyHeight, key, PALETTE.textPrimary, PALETTE.keyNormal, `key:${key}`);
    }
    
    // Row 1: QWERTYUIOP (10 keys)
    const row1Keys = KEYBOARD_ROWS[1];
    const row1KeyWidth = 85;
    for (let col = 0; col < row1Keys.length; col++) {
      const key = row1Keys[col];
      const x = startX + col * (row1KeyWidth + keyMargin);
      const y = yPos + 10 + 1 * (keyHeight + keyMargin);
      this.addElement(`key_r1_${col}`, 'key', x, y, row1KeyWidth, keyHeight, key, PALETTE.textPrimary, PALETTE.keyNormal, `key:${key}`);
    }
    
    // Row 2: ASDFGHJKL; (10 keys)
    const row2Keys = KEYBOARD_ROWS[2];
    const row2KeyWidth = 85;
    for (let col = 0; col < row2Keys.length; col++) {
      const key = row2Keys[col];
      const x = startX + col * (row2KeyWidth + keyMargin);
      const y = yPos + 10 + 2 * (keyHeight + keyMargin);
      this.addElement(`key_r2_${col}`, 'key', x, y, row2KeyWidth, keyHeight, key, PALETTE.textPrimary, PALETTE.keyNormal, `key:${key}`);
    }
    
    // Row 3: ZXCVBNM,./ (10 keys)
    const row3Keys = KEYBOARD_ROWS[3];
    const row3KeyWidth = 85;
    for (let col = 0; col < row3Keys.length; col++) {
      const key = row3Keys[col];
      const x = startX + col * (row3KeyWidth + keyMargin);
      const y = yPos + 10 + 3 * (keyHeight + keyMargin);
      this.addElement(`key_r3_${col}`, 'key', x, y, row3KeyWidth, keyHeight, key, PALETTE.textPrimary, PALETTE.keyNormal, `key:${key}`);
    }
    
    // Row 4: SPACE, ENTER, BACK, CLR (4 keys)
    const row4Keys = KEYBOARD_ROWS[4];
    const row4KeyWidth = 220;
    const row4StartX = (BASE_WIDTH - (row4Keys.length * row4KeyWidth + (row4Keys.length - 1) * keyMargin)) / 2;
    for (let col = 0; col < row4Keys.length; col++) {
      const key = row4Keys[col];
      const x = row4StartX + col * (row4KeyWidth + keyMargin);
      const y = yPos + 10 + 4 * (keyHeight + keyMargin);
      this.addElement(`key_r4_${col}`, 'key', x, y, row4KeyWidth, keyHeight, key, PALETTE.textPrimary, PALETTE.keyNormal, `key:${key}`);
    }
  }
  
  private addElement(id: string, type: UIElementType, x: number, y: number, width: number, height: number, text: string, color: number, bgColor: number, action?: string): void {
    this.state.elements.push({ id, type, x, y, width, height, text, color, bgColor, active: false, selected: false, action });
  }
  
  private lerpColor(c1: number, c2: number, t: number): number {
    const r1 = (c1 >> 16) & 0xff, g1 = (c1 >> 8) & 0xff, b1 = c1 & 0xff;
    const r2 = (c2 >> 16) & 0xff, g2 = (c2 >> 8) & 0xff, b2 = c2 & 0xff;
    return (Math.round(r1 + (r2 - r1) * t) << 16) | (Math.round(g1 + (g2 - g1) * t) << 8) | Math.round(b1 + (b2 - b1) * t);
  }
  
  // ============================================
  // Python UI with Always-Visible Keyboard
  // ============================================
  private buildPythonUI(): void {
    this.buildStandardHeader('Python to PPU Compiler');
    this.addElement('editor_bg', 'panel', 20, 100, BASE_WIDTH - 40, 260, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('editor_label', 'text', 30, 85, 200, 20, 'Python Code:', PALETTE.textSecondary, 0);
    const codeLines = this.state.code.split('\n').slice(0, 7);
    for (let i = 0; i < 7; i++) {
      const line = codeLines[i] || '', lineNum = (i + 1).toString().padStart(2, '0');
      this.addElement(`line_num_${i}`, 'text', 30, 110 + i * 30, 30, 20, lineNum, PALETTE.textMuted, 0);
      this.addElement(`code_line_${i}`, 'text', 70, 110 + i * 30, BASE_WIDTH - 110, 20, line.substring(0, 55), PALETTE.textPrimary, 0);
    }
    const cursorLine = Math.min(this.state.code.split('\n').length - 1, 6);
    const cursorCol = this.state.code.split('\n')[cursorLine]?.length || 0;
    if (this.state.cursor.blink) this.addElement('cursor', 'cursor', 70 + cursorCol * 12, 110 + cursorLine * 30, 10, 20, '|', PALETTE.cursor, 0);
    
    const btnY = 375;
    this.addElement('btn_compile', 'button', 20, btnY, 110, 40, 'COMPILE', PALETTE.textPrimary, PALETTE.success, 'action:compile');
    this.addElement('btn_run', 'button', 140, btnY, 80, 40, 'RUN', PALETTE.textPrimary, PALETTE.info, 'action:run');
    this.addElement('btn_clear', 'button', 230, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 320, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 430, 375, BASE_WIDTH - 450, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 3; i++) {
      const line = this.state.output[i] || '';
      const color = line.startsWith('OK') ? PALETTE.success : line.startsWith('ERR') ? PALETTE.error : line.startsWith('->') ? PALETTE.info : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 440, 395 + i * 25, BASE_WIDTH - 470, 20, line.substring(0, 45), color, 0);
    }
    this.buildVirtualKeyboard(500);
  }
  
  // ============================================
  // PPU UI with Always-Visible Keyboard
  // ============================================
  private buildPPUUI(): void {
    this.buildStandardHeader('PPU Assembly Editor');
    this.addElement('editor_bg', 'panel', 20, 100, BASE_WIDTH - 40, 260, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('editor_label', 'text', 30, 85, 200, 20, 'PPU Assembly:', PALETTE.textSecondary, 0);
    const codeLines = this.state.code.split('\n').slice(0, 7);
    for (let i = 0; i < 7; i++) {
      const line = codeLines[i] || '', lineNum = (i + 1).toString().padStart(2, '0');
      this.addElement(`line_num_${i}`, 'text', 30, 110 + i * 30, 30, 20, lineNum, PALETTE.textMuted, 0);
      this.addElement(`code_line_${i}`, 'text', 70, 110 + i * 30, BASE_WIDTH - 110, 20, line.substring(0, 55), PALETTE.textPrimary, 0);
    }
    const cursorLine = Math.min(this.state.code.split('\n').length - 1, 6);
    const cursorCol = this.state.code.split('\n')[cursorLine]?.length || 0;
    if (this.state.cursor.blink) this.addElement('cursor', 'cursor', 70 + cursorCol * 12, 110 + cursorLine * 30, 10, 20, '|', PALETTE.cursor, 0);
    
    const btnY = 375;
    this.addElement('btn_execute', 'button', 20, btnY, 110, 40, 'EXECUTE', PALETTE.textPrimary, PALETTE.success, 'action:execute');
    this.addElement('btn_decompile', 'button', 140, btnY, 110, 40, 'TO PYTHON', PALETTE.textPrimary, PALETTE.info, 'action:decompile');
    this.addElement('btn_clear', 'button', 260, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 350, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 460, 375, BASE_WIDTH - 480, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 3; i++) {
      const line = this.state.output[i] || '';
      const color = line.startsWith('OK') ? PALETTE.success : line.startsWith('ERR') ? PALETTE.error : line.startsWith('->') ? PALETTE.info : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 470, 395 + i * 25, BASE_WIDTH - 500, 20, line.substring(0, 45), color, 0);
    }
    this.buildVirtualKeyboard(500);
  }
  
  // ============================================
  // Natural Language UI
  // ============================================
  private buildNLUI(): void {
    this.buildStandardHeader('Natural Language to PPU');
    this.addElement('input_bg', 'panel', 20, 100, BASE_WIDTH - 40, 180, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('input_label', 'text', 30, 85, 300, 20, 'Natural Language Input:', PALETTE.textSecondary, 0);
    const inputLines = this.state.code.split('\n').slice(0, 5);
    for (let i = 0; i < 5; i++) this.addElement(`input_line_${i}`, 'text', 30, 110 + i * 28, BASE_WIDTH - 60, 20, (inputLines[i] || '').substring(0, 70), PALETTE.textPrimary, 0);
    
    const btnY = 295;
    this.addElement('btn_translate', 'button', 20, btnY, 120, 40, 'TRANSLATE', PALETTE.textPrimary, PALETTE.success, 'action:translate');
    this.addElement('btn_execute', 'button', 150, btnY, 100, 40, 'EXECUTE', PALETTE.textPrimary, PALETTE.info, 'action:execute_nl');
    this.addElement('btn_clear', 'button', 260, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 350, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 20, 350, BASE_WIDTH - 40, 130, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 4; i++) {
      const line = this.state.output[i] || '';
      const color = line.startsWith('OK') ? PALETTE.success : line.startsWith('ERR') ? PALETTE.error : line.startsWith('->') ? PALETTE.info : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 30, 370 + i * 25, BASE_WIDTH - 60, 20, line.substring(0, 75), color, 0);
    }
    this.buildVirtualKeyboard(500);
  }
  
  // ============================================
  // Prime Domain UI
  // ============================================
  private buildPrimeUI(): void {
    this.buildStandardHeader('Prime Domain Machine');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 120, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Log-Domain Arithmetic', PALETTE.gradientPrimary[1], 0);
    this.addElement('theory_desc', 'text', 30, 140, BASE_WIDTH - 60, 20, 'p1 * p2 = exp(log(p1) + log(p2))', PALETTE.textSecondary, 0);
    this.addElement('theory_eq', 'text', 30, 165, BASE_WIDTH - 60, 20, 'F = S * T * E(0) where E(0) = 1', PALETTE.textMuted, 0);
    
    this.addElement('calc_bg', 'panel', 20, 235, BASE_WIDTH - 40, 150, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('calc_title', 'text', 30, 250, 200, 20, 'Prime Calculator:', PALETTE.textSecondary, 0);
    this.addElement('p1_label', 'text', 30, 280, 50, 20, 'P1:', PALETTE.textSecondary, 0);
    this.addElement('p1_input', 'panel', 80, 270, 100, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('p2_label', 'text', 30, 320, 50, 20, 'P2:', PALETTE.textSecondary, 0);
    this.addElement('p2_input', 'panel', 80, 310, 100, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('btn_multiply', 'button', 200, 270, 80, 35, 'MUL', PALETTE.textPrimary, PALETTE.button, 'action:prime_mult');
    this.addElement('btn_add', 'button', 290, 270, 70, 35, 'ADD', PALETTE.textPrimary, PALETTE.button, 'action:prime_add');
    this.addElement('btn_div', 'button', 370, 270, 70, 35, 'DIV', PALETTE.textPrimary, PALETTE.button, 'action:prime_div');
    this.addElement('result_label', 'text', 200, 320, 70, 20, 'Result:', PALETTE.textSecondary, 0);
    this.addElement('result_display', 'panel', 280, 310, 150, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
    
    this.addElement('primes_bg', 'panel', 20, 400, BASE_WIDTH - 40, 200, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('primes_title', 'text', 30, 415, 200, 20, 'Prime Sequence:', PALETTE.textSecondary, 0);
    this.addElement('primes_list', 'text', 30, 445, BASE_WIDTH - 60, 20, '2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71', PALETTE.textMuted, 0);
    for (let i = 0; i < 12; i++) {
      const phase = (i / 12) * Math.PI * 2, x = 80 + i * 75, y = 520;
      const amp = 0.5 + 0.5 * Math.sin(phase + this.state.animTime * 2);
      const color = this.lerpColor(PALETTE.gradientPrimary[0], PALETTE.gradientPrimary[2], amp);
      this.addElement(`pole_viz_${i}`, 'visualizer', x - 20, y - 40, 40, 60, '', color, 0);
    }
    this.addElement('btn_back', 'button', 20, BASE_HEIGHT - 60, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }
  
  // ============================================
  // QAI UI
  // ============================================
  private buildQAIUI(): void {
    this.buildStandardHeader('QAI Trio Operators');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 140, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Trio Operators', PALETTE.gradientSecondary[1], 0);
    this.addElement('sigma_desc', 'text', 30, 140, 400, 20, 'SUM: Accumulate coherent states', PALETTE.textSecondary, 0);
    this.addElement('delta_desc', 'text', 30, 165, 400, 20, 'DIFF: Measure quantum gradients', PALETTE.textSecondary, 0);
    this.addElement('theta_desc', 'text', 30, 190, 400, 20, 'THR: Collapse to classical', PALETTE.textSecondary, 0);
    
    this.addElement('demo_bg', 'panel', 20, 255, BASE_WIDTH - 40, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('demo_title', 'text', 30, 270, 200, 20, 'Operator Demo:', PALETTE.textSecondary, 0);
    this.addElement('input_label', 'text', 30, 300, 70, 20, 'Values:', PALETTE.textSecondary, 0);
    this.addElement('input_field', 'panel', 100, 290, 180, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('btn_sigma', 'button', 300, 290, 80, 35, 'SUM', PALETTE.textPrimary, PALETTE.button, 'action:qai_sigma');
    this.addElement('btn_delta', 'button', 390, 290, 80, 35, 'DIFF', PALETTE.textPrimary, PALETTE.button, 'action:qai_delta');
    this.addElement('btn_theta', 'button', 480, 290, 80, 35, 'THR', PALETTE.textPrimary, PALETTE.button, 'action:qai_theta');
    this.addElement('complex_label', 'text', 30, 345, 120, 20, 'Complex a+bi:', PALETTE.textSecondary, 0);
    this.addElement('real_input', 'panel', 150, 335, 70, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('imag_input', 'panel', 230, 335, 70, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('btn_baz', 'button', 320, 335, 80, 35, 'BAZ', PALETTE.textPrimary, PALETTE.button, 'action:qai_baz');
    
    this.addElement('result_bg', 'panel', 20, 470, BASE_WIDTH - 40, 150, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('result_title', 'text', 30, 485, 100, 20, 'Results:', PALETTE.textSecondary, 0);
    for (let i = 0; i < 4; i++) this.addElement(`result_line_${i}`, 'text', 30, 510 + i * 25, BASE_WIDTH - 60, 20, this.state.output[i] || '', PALETTE.textPrimary, 0);
    this.addElement('btn_back', 'button', 20, BASE_HEIGHT - 60, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }
  
  // ============================================
  // Entropy UI
  // ============================================
  private buildEntropyUI(): void {
    this.buildStandardHeader('Modular Entropy System');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 110, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Sinusoidal Entropy Modulation', PALETTE.gradientWarm[1], 0);
    this.addElement('entropy_eq', 'text', 30, 140, 500, 20, 'H(t) = H0 + A*sin(wt + p) * feedback(t)', PALETTE.textSecondary, 0);
    this.addElement('entropy_desc', 'text', 30, 165, BASE_WIDTH - 60, 20, 'Feedback-controlled entropy modulation', PALETTE.textMuted, 0);
    
    this.addElement('controls_bg', 'panel', 20, 225, BASE_WIDTH - 40, 150, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('controls_title', 'text', 30, 240, 200, 20, 'Entropy Controls:', PALETTE.textSecondary, 0);
    this.addElement('h0_label', 'text', 30, 270, 70, 20, 'H0 Base:', PALETTE.textSecondary, 0);
    this.addElement('h0_slider', 'panel', 100, 260, 180, 25, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('amp_label', 'text', 30, 305, 70, 20, 'A Amp:', PALETTE.textSecondary, 0);
    this.addElement('amp_slider', 'panel', 100, 295, 180, 25, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('btn_start', 'button', 300, 260, 90, 35, 'START', PALETTE.textPrimary, PALETTE.success, 'action:entropy_start');
    this.addElement('btn_stop', 'button', 400, 260, 80, 35, 'STOP', PALETTE.textPrimary, PALETTE.error, 'action:entropy_stop');
    this.addElement('btn_reset', 'button', 490, 260, 80, 35, 'RESET', PALETTE.textPrimary, PALETTE.button, 'action:entropy_reset');
    
    this.addElement('viz_bg', 'panel', 20, 390, BASE_WIDTH - 40, 280, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('viz_title', 'text', 30, 405, 200, 20, 'Entropy Visualization:', PALETTE.textSecondary, 0);
    this.addElement('current_h', 'text', 30, 440, 200, 20, `H: ${this.poles.entropy.toFixed(4)}`, PALETTE.textPrimary, 0);
    this.addElement('current_coh', 'text', 250, 440, 200, 20, `C: ${this.poles.coherence.toFixed(4)}`, PALETTE.success, 0);
    for (let i = 0; i < 8; i++) {
      const h = 50 + Math.sin(this.state.animTime * 2 + i * 0.5) * 30 + this.poles.entropy * 100;
      const color = this.lerpColor(PALETTE.gradientWarm[0], PALETTE.gradientWarm[2], i / 8);
      this.addElement(`entropy_bar_${i}`, 'visualizer', 50 + i * 110, 600 - h, 80, h, '', color, 0);
    }
    this.addElement('btn_back', 'button', 20, BASE_HEIGHT - 60, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }
  
  // ============================================
  // Glyph UI
  // ============================================
  private buildGlyphUI(): void {
    this.buildStandardHeader('Glyph-Convolutional Theory');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 110, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Multisensory Glyph Algebra', PALETTE.gradientCool[1], 0);
    this.addElement('glyph_eq', 'text', 30, 140, 500, 20, 'G1 * G2 = integral G1(x,y) * G2(x-t,y-s) dx dy', PALETTE.textSecondary, 0);
    
    this.addElement('selector_bg', 'panel', 20, 225, BASE_WIDTH - 40, 130, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('selector_title', 'text', 30, 240, 200, 20, 'Glyph Selector:', PALETTE.textSecondary, 0);
    const glyphs = ['A', 'B', 'G', 'D', 'E', 'T', 'L', 'M', 'S', 'F', 'P', 'W'];
    for (let i = 0; i < glyphs.length; i++) {
      const x = 30 + (i % 6) * 80, y = 270 + Math.floor(i / 6) * 45;
      this.addElement(`glyph_${glyphs[i]}`, 'button', x, y, 60, 35, glyphs[i], PALETTE.textPrimary, PALETTE.button, `glyph:${glyphs[i]}`);
    }
    
    this.addElement('comp_bg', 'panel', 20, 370, BASE_WIDTH - 40, 120, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('comp_title', 'text', 30, 385, 200, 20, 'Glyph Composition:', PALETTE.textSecondary, 0);
    this.addElement('comp_display', 'panel', 30, 410, BASE_WIDTH - 60, 60, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('btn_compose', 'button', 30, 480, 120, 35, 'COMPOSE', PALETTE.textPrimary, PALETTE.success, 'action:glyph_compose');
    this.addElement('btn_clear', 'button', 160, 480, 100, 35, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    
    this.addElement('result_bg', 'panel', 20, 530, BASE_WIDTH - 40, 120, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 3; i++) this.addElement(`result_line_${i}`, 'text', 30, 550 + i * 25, BASE_WIDTH - 60, 20, this.state.output[i] || '', PALETTE.textPrimary, 0);
    this.addElement('btn_back', 'button', 20, BASE_HEIGHT - 60, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }
  
  // ============================================
  // Compiler UI
  // ============================================
  private buildCompilerUI(): void {
    this.buildStandardHeader('Python to PPU Compiler');
    this.addElement('input_bg', 'panel', 20, 100, BASE_WIDTH - 40, 260, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('input_label', 'text', 30, 85, 200, 20, 'Python Input:', PALETTE.textSecondary, 0);
    const codeLines = this.state.code.split('\n').slice(0, 7);
    for (let i = 0; i < 7; i++) {
      const line = codeLines[i] || '', lineNum = (i + 1).toString().padStart(2, '0');
      this.addElement(`line_num_${i}`, 'text', 30, 110 + i * 30, 30, 20, lineNum, PALETTE.textMuted, 0);
      this.addElement(`code_line_${i}`, 'text', 70, 110 + i * 30, BASE_WIDTH - 110, 20, line.substring(0, 55), PALETTE.textPrimary, 0);
    }
    const cursorLine = Math.min(this.state.code.split('\n').length - 1, 6);
    const cursorCol = this.state.code.split('\n')[cursorLine]?.length || 0;
    if (this.state.cursor.blink) this.addElement('cursor', 'cursor', 70 + cursorCol * 12, 110 + cursorLine * 30, 10, 20, '|', PALETTE.cursor, 0);
    
    const btnY = 375;
    this.addElement('btn_compile', 'button', 20, btnY, 120, 40, 'COMPILE', PALETTE.textPrimary, PALETTE.success, 'action:compile');
    this.addElement('btn_clear', 'button', 150, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 240, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 350, 375, BASE_WIDTH - 370, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 3; i++) {
      const line = this.state.output[i] || '';
      const color = line.startsWith('BYTE') ? PALETTE.warning : line.startsWith('OK') ? PALETTE.success : line.startsWith('ERR') ? PALETTE.error : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 360, 395 + i * 25, BASE_WIDTH - 390, 20, line.substring(0, 50), color, 0);
    }
    this.buildVirtualKeyboard(500);
  }
  
  // ============================================
  // Decompiler UI
  // ============================================
  private buildDecompilerUI(): void {
    this.buildStandardHeader('PPU to Python Decompiler');
    this.addElement('input_bg', 'panel', 20, 100, BASE_WIDTH - 40, 260, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('input_label', 'text', 30, 85, 200, 20, 'PPU Assembly Input:', PALETTE.textSecondary, 0);
    const codeLines = this.state.code.split('\n').slice(0, 7);
    for (let i = 0; i < 7; i++) {
      const line = codeLines[i] || '', lineNum = (i + 1).toString().padStart(2, '0');
      this.addElement(`line_num_${i}`, 'text', 30, 110 + i * 30, 30, 20, lineNum, PALETTE.textMuted, 0);
      this.addElement(`code_line_${i}`, 'text', 70, 110 + i * 30, BASE_WIDTH - 110, 20, line.substring(0, 55), PALETTE.textPrimary, 0);
    }
    const cursorLine = Math.min(this.state.code.split('\n').length - 1, 6);
    const cursorCol = this.state.code.split('\n')[cursorLine]?.length || 0;
    if (this.state.cursor.blink) this.addElement('cursor', 'cursor', 70 + cursorCol * 12, 110 + cursorLine * 30, 10, 20, '|', PALETTE.cursor, 0);
    
    const btnY = 375;
    this.addElement('btn_decompile', 'button', 20, btnY, 130, 40, 'DECOMPILE', PALETTE.textPrimary, PALETTE.success, 'action:decompile');
    this.addElement('btn_clear', 'button', 160, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 250, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 360, 375, BASE_WIDTH - 380, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 3; i++) {
      const line = this.state.output[i] || '';
      const color = line.startsWith('def ') || line.startsWith('class ') ? PALETTE.info : line.startsWith('OK') ? PALETTE.success : line.startsWith('ERR') ? PALETTE.error : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 370, 395 + i * 25, BASE_WIDTH - 400, 20, line.substring(0, 50), color, 0);
    }
    this.buildVirtualKeyboard(500);
  }
  
  // ============================================
  // Calculator UI
  // ============================================
  private buildCalcUI(): void {
    this.buildStandardHeader('Symbolic Calculator');
    this.addElement('display_bg', 'panel', 20, 100, BASE_WIDTH - 40, 70, '', PALETTE.textPrimary, PALETTE.bgCard);
    const displayText = this.state.code || '0';
    this.addElement('display', 'text', 30, 130, BASE_WIDTH - 60, 30, displayText.substring(0, 40), PALETTE.textPrimary, 0);
    
    const categories = ['BASIC', 'TRIG', 'CALC'];
    let catX = 20;
    for (const cat of categories) {
      const bg = this.state.selectedOp === cat ? PALETTE.buttonActive : PALETTE.button;
      this.addElement(`cat_${cat}`, 'button', catX, 185, 80, 30, cat, PALETTE.textPrimary, bg, `cat:${cat}`);
      catX += 95;
    }
    
    const ops = ['+', '-', '*', '/', 'sin', 'cos', 'tan', 'log', 'exp', 'sqrt', 'pi', 'e', '(', ')', '^', 'abs'];
    for (let i = 0; i < ops.length; i++) {
      const row = Math.floor(i / 4), col = i % 4;
      const x = 20 + col * 90, y = 230 + row * 50;
      this.addElement(`op_${ops[i]}`, 'button', x, y, 75, 40, ops[i], PALETTE.textPrimary, PALETTE.bgElevated, `op:${ops[i]}`);
    }
    
    const nums = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '.', '='];
    for (let i = 0; i < nums.length; i++) {
      const row = Math.floor(i / 3), col = i % 3;
      const x = 400 + col * 80, y = 230 + row * 50;
      const bg = nums[i] === '=' ? PALETTE.success : PALETTE.button;
      this.addElement(`num_${nums[i]}`, 'button', x, y, 65, 40, nums[i], PALETTE.textPrimary, bg, `num:${nums[i]}`);
    }
    
    this.addElement('btn_c', 'button', 400, 440, 65, 40, 'C', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_bs', 'button', 480, 440, 65, 40, 'BS', PALETTE.textPrimary, PALETTE.button, 'action:backspace');
    
    this.addElement('result_bg', 'panel', 20, 500, BASE_WIDTH - 40, 140, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 4; i++) {
      const line = this.state.output[i] || '';
      const color = line.includes('=') ? PALETTE.success : PALETTE.textPrimary;
      this.addElement(`result_line_${i}`, 'text', 30, 520 + i * 28, BASE_WIDTH - 60, 20, line.substring(0, 70), color, 0);
    }
    this.addElement('btn_back', 'button', 20, BASE_HEIGHT - 60, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }

  // ============================================
  // Matrix Grammar UI
  // ============================================
  private buildMatrixUI(): void {
    this.buildStandardHeader('Matrix Selector Grammar');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 100, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Seed-Lift-Selector Pipeline', PALETTE.gradientPrimary[1], 0);
    this.addElement('theory_eq', 'text', 30, 140, 500, 20, 'M = Seed(S) -> Lift(L) -> Select(E)', PALETTE.textSecondary, 0);
    this.addElement('theory_desc', 'text', 30, 165, BASE_WIDTH - 60, 20, 'Matrix grammar for natural language processing', PALETTE.textMuted, 0);
    
    this.addElement('input_bg', 'panel', 20, 215, BASE_WIDTH - 40, 180, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('input_label', 'text', 30, 230, 200, 20, 'Natural Language:', PALETTE.textSecondary, 0);
    const inputLines = this.state.code.split('\n').slice(0, 5);
    for (let i = 0; i < 5; i++) this.addElement(`input_line_${i}`, 'text', 30, 255 + i * 25, BASE_WIDTH - 60, 20, (inputLines[i] || '').substring(0, 70), PALETTE.textPrimary, 0);
    
    const btnY = 410;
    this.addElement('btn_parse', 'button', 20, btnY, 100, 40, 'PARSE', PALETTE.textPrimary, PALETTE.success, 'action:parse_matrix');
    this.addElement('btn_execute', 'button', 130, btnY, 100, 40, 'EXECUTE', PALETTE.textPrimary, PALETTE.info, 'action:execute_matrix');
    this.addElement('btn_clear', 'button', 240, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 330, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 20, 465, BASE_WIDTH - 40, 180, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('output_title', 'text', 30, 480, 200, 20, 'Parsed Result:', PALETTE.textSecondary, 0);
    for (let i = 0; i < 5; i++) {
      const line = this.state.output[i] || '';
      const color = line.startsWith('Seed:') ? PALETTE.info : line.startsWith('Lift:') ? PALETTE.warning : line.startsWith('Select:') ? PALETTE.success : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 30, 505 + i * 25, BASE_WIDTH - 60, 20, line.substring(0, 70), color, 0);
    }
    this.buildVirtualKeyboard(660);
  }
  
  // ============================================
  // Arabic Poetry UI
  // ============================================
  private buildPoetryUI(): void {
    this.buildStandardHeader('Arabic Poetry Processor');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Poetry Analysis & Generation', PALETTE.gradientWarm[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'Arabic poetic forms: Qasidah, Ghazal, Rubai', PALETTE.textMuted, 0);
    
    this.addElement('input_bg', 'panel', 20, 195, BASE_WIDTH - 40, 160, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('input_label', 'text', 30, 210, 200, 20, 'Enter Poetry (Arabic/Latin):', PALETTE.textSecondary, 0);
    const inputLines = this.state.code.split('\n').slice(0, 5);
    for (let i = 0; i < 5; i++) this.addElement(`input_line_${i}`, 'text', 30, 235 + i * 25, BASE_WIDTH - 60, 20, (inputLines[i] || '').substring(0, 70), PALETTE.textPrimary, 0);
    
    this.addElement('forms_bg', 'panel', 20, 370, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('forms_title', 'text', 30, 385, 200, 20, 'Poetic Forms:', PALETTE.textSecondary, 0);
    const forms = ['Qasidah', 'Ghazal', 'Rubai', 'Nazm'];
    for (let i = 0; i < forms.length; i++) {
      this.addElement(`form_${forms[i]}`, 'button', 30 + i * 110, 410, 100, 30, forms[i], PALETTE.textPrimary, PALETTE.button, `form:${forms[i]}`);
    }
    
    const btnY = 470;
    this.addElement('btn_analyze', 'button', 20, btnY, 100, 40, 'ANALYZE', PALETTE.textPrimary, PALETTE.success, 'action:analyze_poetry');
    this.addElement('btn_generate', 'button', 130, btnY, 100, 40, 'GENERATE', PALETTE.textPrimary, PALETTE.info, 'action:generate_poetry');
    this.addElement('btn_clear', 'button', 240, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 330, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 20, 525, BASE_WIDTH - 40, 180, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('output_title', 'text', 30, 540, 200, 20, 'Analysis Result:', PALETTE.textSecondary, 0);
    for (let i = 0; i < 5; i++) {
      const line = this.state.output[i] || '';
      const color = line.includes('Meter:') ? PALETTE.info : line.includes('Rhyme:') ? PALETTE.success : PALETTE.textPrimary;
      this.addElement(`output_line_${i}`, 'text', 30, 565 + i * 25, BASE_WIDTH - 60, 20, line.substring(0, 70), color, 0);
    }
    this.buildVirtualKeyboard(720);
  }
  
  // ============================================
  // Symbol Library UI
  // ============================================
  private buildSymbolsUI(): void {
    this.buildStandardHeader('Mathematical Symbol Library');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Symbolic Math Library', PALETTE.gradientCool[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'Constants, functions, and operators', PALETTE.textMuted, 0);
    
    this.addElement('const_bg', 'panel', 20, 195, 300, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('const_title', 'text', 30, 210, 150, 20, 'Constants:', PALETTE.textSecondary, 0);
    const constants = ['pi = 3.14159', 'e = 2.71828', 'phi = 1.61803', 'gamma = 0.57721'];
    for (let i = 0; i < constants.length; i++) {
      this.addElement(`const_${i}`, 'text', 30, 240 + i * 35, 260, 20, constants[i], PALETTE.textPrimary, 0);
    }
    
    this.addElement('func_bg', 'panel', 340, 195, 320, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('func_title', 'text', 350, 210, 150, 20, 'Functions:', PALETTE.textSecondary, 0);
    const funcs = ['sin(x)', 'cos(x)', 'tan(x)', 'log(x)', 'exp(x)', 'sqrt(x)', 'abs(x)'];
    for (let i = 0; i < funcs.length; i++) {
      const col = i % 2, row = Math.floor(i / 2);
      this.addElement(`func_${i}`, 'text', 350 + col * 140, 240 + row * 35, 130, 20, funcs[i], PALETTE.textPrimary, 0);
    }
    
    this.addElement('ops_bg', 'panel', 680, 195, 320, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('ops_title', 'text', 690, 210, 150, 20, 'Operators:', PALETTE.textSecondary, 0);
    const ops = ['+  addition', '-  subtraction', '*  multiplication', '/  division', '^  power', '!  factorial'];
    for (let i = 0; i < ops.length; i++) {
      this.addElement(`op_${i}`, 'text', 690, 240 + i * 30, 280, 20, ops[i], PALETTE.textPrimary, 0);
    }
    
    this.addElement('test_bg', 'panel', 20, 410, BASE_WIDTH - 40, 150, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('test_title', 'text', 30, 425, 200, 20, 'Test Expression:', PALETTE.textSecondary, 0);
    this.addElement('test_input', 'panel', 30, 450, BASE_WIDTH - 60, 40, '', PALETTE.textPrimary, PALETTE.bgPanel);
    const testText = this.state.code || 'sin(pi/2) + log(e)';
    this.addElement('test_display', 'text', 40, 465, BASE_WIDTH - 80, 20, testText.substring(0, 60), PALETTE.textPrimary, 0);
    
    this.addElement('btn_eval', 'button', 30, 505, 100, 40, 'EVAL', PALETTE.textPrimary, PALETTE.success, 'action:eval_symbol');
    this.addElement('btn_clear', 'button', 140, 505, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 230, 505, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('result_bg', 'panel', 340, 505, 660, 40, '', PALETTE.textPrimary, PALETTE.bgElevated);
    const result = this.state.output[0] || 'Result: ';
    this.addElement('result_text', 'text', 350, 520, 640, 20, result.substring(0, 70), PALETTE.success, 0);
    this.buildVirtualKeyboard(580);
  }
  
  // ============================================
  // 12-Pole Visualization UI
  // ============================================
  private buildVisualUI(): void {
    this.buildStandardHeader('12-Pole Harmonic Oscillator');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'GIFLife Field Visualization', PALETTE.gradientPrimary[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'Reaction-diffusion computational substrate', PALETTE.textMuted, 0);
    
    this.addElement('viz_bg', 'panel', 20, 195, BASE_WIDTH - 40, 400, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('viz_title', 'text', 30, 210, 200, 20, 'Pole Positions:', PALETTE.textSecondary, 0);
    
    const centerX = BASE_WIDTH / 2, centerY = 400, radius = 120;
    for (let i = 0; i < NUM_POLES; i++) {
      const angle = (i / NUM_POLES) * Math.PI * 2 + this.state.animTime;
      const x = centerX + Math.cos(angle) * radius - 25;
      const y = centerY + Math.sin(angle) * radius - 25;
      const amp = this.poles.amplitudes[i];
      const color = this.lerpColor(PALETTE.gradientPrimary[0], PALETTE.gradientPrimary[2], amp);
      this.addElement(`pole_${i}`, 'visualizer', x, y, 50, 50, '', color, 0);
      this.addElement(`pole_label_${i}`, 'text', x + 15, y + 20, 20, 15, i.toString(), PALETTE.textPrimary, 0);
    }
    
    this.addElement('center_viz', 'visualizer', centerX - 30, centerY - 30, 60, 60, '', PALETTE.accent, 0);
    
    this.addElement('stats_bg', 'panel', 20, 610, BASE_WIDTH - 40, 100, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('stats_title', 'text', 30, 625, 100, 20, 'Stats:', PALETTE.textSecondary, 0);
    this.addElement('coherence_stat', 'text', 30, 655, 200, 20, `Coherence: ${(this.poles.coherence * 100).toFixed(1)}%`, PALETTE.success, 0);
    this.addElement('entropy_stat', 'text', 250, 655, 200, 20, `Entropy: ${(this.poles.entropy * 100).toFixed(1)}%`, PALETTE.warning, 0);
    this.addElement('tick_stat', 'text', 470, 655, 200, 20, `Tick: ${this.clock.tick}`, PALETTE.textMuted, 0);
    
    this.addElement('btn_animate', 'button', 700, 645, 100, 40, 'ANIMATE', PALETTE.textPrimary, PALETTE.success, 'action:toggle_animate');
    this.addElement('btn_reset', 'button', 810, 645, 80, 40, 'RESET', PALETTE.textPrimary, PALETTE.error, 'action:reset_poles');
    this.addElement('btn_back', 'button', 900, 645, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }
  
  // ============================================
  // Spectrum Analysis UI
  // ============================================
  private buildSpectrumUI(): void {
    this.buildStandardHeader('Spectral Analysis');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Frequency Domain Analysis', PALETTE.gradientSecondary[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'FFT-based spectral decomposition', PALETTE.textMuted, 0);
    
    this.addElement('input_bg', 'panel', 20, 195, BASE_WIDTH - 40, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('input_label', 'text', 30, 210, 200, 20, 'Signal (comma-separated):', PALETTE.textSecondary, 0);
    this.addElement('signal_input', 'panel', 30, 235, BASE_WIDTH - 60, 45, '', PALETTE.textPrimary, PALETTE.bgPanel);
    const signal = this.state.code || '1,0,-1,0,1,0,-1,0';
    this.addElement('signal_display', 'text', 40, 250, BASE_WIDTH - 80, 20, signal.substring(0, 70), PALETTE.textPrimary, 0);
    
    this.addElement('viz_bg', 'panel', 20, 310, BASE_WIDTH - 40, 300, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('viz_title', 'text', 30, 325, 200, 20, 'Spectrum:', PALETTE.textSecondary, 0);
    
    const signalData = signal.split(',').map(s => parseFloat(s.trim()) || 0);
    const maxVal = Math.max(...signalData.map(Math.abs), 1);
    for (let i = 0; i < 16; i++) {
      const val = signalData[i % signalData.length] || 0;
      const h = Math.abs(val) / maxVal * 150;
      const color = val >= 0 ? PALETTE.success : PALETTE.error;
      this.addElement(`spectrum_bar_${i}`, 'visualizer', 50 + i * 58, 550 - h, 45, h, '', color, 0);
    }
    
    const btnY = 630;
    this.addElement('btn_fft', 'button', 20, btnY, 80, 40, 'FFT', PALETTE.textPrimary, PALETTE.success, 'action:fft');
    this.addElement('btn_ifft', 'button', 110, btnY, 80, 40, 'IFFT', PALETTE.textPrimary, PALETTE.info, 'action:ifft');
    this.addElement('btn_clear', 'button', 200, btnY, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 290, btnY, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('output_bg', 'panel', 400, 630, BASE_WIDTH - 420, 80, '', PALETTE.textPrimary, PALETTE.bgElevated);
    for (let i = 0; i < 2; i++) {
      const line = this.state.output[i] || '';
      this.addElement(`output_line_${i}`, 'text', 410, 650 + i * 25, BASE_WIDTH - 440, 20, line.substring(0, 70), PALETTE.textPrimary, 0);
    }
    this.buildVirtualKeyboard(720);
  }
  
  // ============================================
  // Settings UI
  // ============================================
  private buildSettingsUI(): void {
    this.buildStandardHeader('System Settings');
    this.addElement('settings_bg', 'panel', 20, 100, BASE_WIDTH - 40, 500, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('settings_title', 'text', 30, 115, 200, 20, 'Configuration:', PALETTE.textSecondary, 0);
    
    const settings = [
      { label: 'Coherence Threshold', value: '0.75', id: 'coh_thresh' },
      { label: 'Entropy Base', value: '0.12', id: 'entropy_base' },
      { label: 'Animation Speed', value: '1.0', id: 'anim_speed' },
      { label: 'Font Scale', value: '1.0', id: 'font_scale' },
      { label: 'Button Size', value: '56', id: 'btn_size' },
    ];
    
    for (let i = 0; i < settings.length; i++) {
      const y = 150 + i * 70;
      this.addElement(`label_${settings[i].id}`, 'text', 30, y, 200, 20, settings[i].label, PALETTE.textSecondary, 0);
      this.addElement(`value_${settings[i].id}`, 'panel', 250, y - 5, 150, 30, '', PALETTE.textPrimary, PALETTE.bgPanel);
      this.addElement(`display_${settings[i].id}`, 'text', 260, y + 10, 130, 20, settings[i].value, PALETTE.textPrimary, 0);
      this.addElement(`btn_inc_${settings[i].id}`, 'button', 420, y - 5, 50, 30, '+', PALETTE.textPrimary, PALETTE.button, `inc:${settings[i].id}`);
      this.addElement(`btn_dec_${settings[i].id}`, 'button', 480, y - 5, 50, 30, '-', PALETTE.textPrimary, PALETTE.button, `dec:${settings[i].id}`);
    }
    
    this.addElement('btn_save', 'button', 30, 520, 100, 40, 'SAVE', PALETTE.textPrimary, PALETTE.success, 'action:save_settings');
    this.addElement('btn_reset', 'button', 140, 520, 100, 40, 'RESET', PALETTE.textPrimary, PALETTE.error, 'action:reset_settings');
    this.addElement('btn_back', 'button', 250, 520, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('info_bg', 'panel', 20, 580, BASE_WIDTH - 40, 120, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('info_title', 'text', 30, 595, 200, 20, 'System Info:', PALETTE.textSecondary, 0);
    this.addElement('version_info', 'text', 30, 625, 300, 20, 'PPU-AQC Platform v8.0', PALETTE.textPrimary, 0);
    this.addElement('build_info', 'text', 30, 655, 300, 20, `Build: ${new Date().toLocaleDateString()}`, PALETTE.textMuted, 0);
  }
  
  // ============================================
  // Trigonometry UI
  // ============================================
  private buildTrigUI(): void {
    this.buildStandardHeader('Trigonometry Calculator');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Trigonometric Functions', PALETTE.gradientWarm[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'sin, cos, tan, and inverse functions', PALETTE.textMuted, 0);
    
    this.addElement('input_bg', 'panel', 20, 195, 300, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('input_label', 'text', 30, 210, 150, 20, 'Angle (degrees):', PALETTE.textSecondary, 0);
    this.addElement('angle_input', 'panel', 30, 235, 260, 45, '', PALETTE.textPrimary, PALETTE.bgPanel);
    const angle = this.state.code || '45';
    this.addElement('angle_display', 'text', 40, 250, 240, 20, angle.substring(0, 15), PALETTE.textPrimary, 0);
    
    this.addElement('result_bg', 'panel', 340, 195, 660, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('result_title', 'text', 350, 210, 150, 20, 'Results:', PALETTE.textSecondary, 0);
    const results = this.state.output.slice(0, 3);
    for (let i = 0; i < 3; i++) {
      this.addElement(`result_line_${i}`, 'text', 350, 240 + i * 20, 630, 18, (results[i] || '').substring(0, 60), PALETTE.textPrimary, 0);
    }
    
    this.addElement('funcs_bg', 'panel', 20, 310, BASE_WIDTH - 40, 180, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('funcs_title', 'text', 30, 325, 150, 20, 'Functions:', PALETTE.textSecondary, 0);
    const funcs = ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sinh', 'cosh', 'tanh'];
    for (let i = 0; i < funcs.length; i++) {
      const col = i % 3, row = Math.floor(i / 3);
      this.addElement(`func_${funcs[i]}`, 'button', 30 + col * 120, 355 + row * 50, 100, 40, funcs[i], PALETTE.textPrimary, PALETTE.button, `trig:${funcs[i]}`);
    }
    
    this.addElement('viz_bg', 'panel', 20, 505, BASE_WIDTH - 40, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('viz_title', 'text', 30, 520, 150, 20, 'Unit Circle:', PALETTE.textSecondary, 0);
    const centerX = 150, centerY = 620, radius = 60;
    this.addElement('circle_viz', 'visualizer', centerX - radius, centerY - radius, radius * 2, radius * 2, '', PALETTE.gradientPrimary[1], 0);
    const angleRad = (parseFloat(angle) || 0) * Math.PI / 180;
    const px = centerX + Math.cos(angleRad) * radius;
    const py = centerY + Math.sin(angleRad) * radius;
    this.addElement('angle_point', 'visualizer', px - 5, py - 5, 10, 10, '', PALETTE.success, 0);
    
    this.addElement('btn_calc', 'button', 400, 645, 100, 40, 'CALC', PALETTE.textPrimary, PALETTE.success, 'action:calc_trig');
    this.addElement('btn_clear', 'button', 510, 645, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 600, 645, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    this.buildVirtualKeyboard(720);
  }
  
  // ============================================
  // Complex Numbers UI
  // ============================================
  private buildComplexUI(): void {
    this.buildStandardHeader('Complex Number Calculator');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Complex Arithmetic', PALETTE.gradientCool[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'z = a + bi, operations on complex plane', PALETTE.textMuted, 0);
    
    this.addElement('z1_bg', 'panel', 20, 195, 480, 120, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('z1_title', 'text', 30, 210, 100, 20, 'z1 = a + bi', PALETTE.textSecondary, 0);
    this.addElement('z1_real_label', 'text', 30, 245, 30, 20, 'a:', PALETTE.textMuted, 0);
    this.addElement('z1_real', 'panel', 65, 235, 100, 35, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('z1_imag_label', 'text', 180, 245, 30, 20, 'b:', PALETTE.textMuted, 0);
    this.addElement('z1_imag', 'panel', 215, 235, 100, 35, '', PALETTE.textPrimary, PALETTE.bgPanel);
    
    this.addElement('z2_bg', 'panel', 520, 195, 480, 120, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('z2_title', 'text', 530, 210, 100, 20, 'z2 = c + di', PALETTE.textSecondary, 0);
    this.addElement('z2_real_label', 'text', 530, 245, 30, 20, 'c:', PALETTE.textMuted, 0);
    this.addElement('z2_real', 'panel', 565, 235, 100, 35, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('z2_imag_label', 'text', 680, 245, 30, 20, 'd:', PALETTE.textMuted, 0);
    this.addElement('z2_imag', 'panel', 715, 235, 100, 35, '', PALETTE.textPrimary, PALETTE.bgPanel);
    
    this.addElement('ops_bg', 'panel', 20, 330, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('ops_title', 'text', 30, 345, 100, 20, 'Operations:', PALETTE.textSecondary, 0);
    const ops = ['+', '-', '*', '/', 'conj', 'abs', 'arg', 'exp'];
    for (let i = 0; i < ops.length; i++) {
      this.addElement(`op_${ops[i]}`, 'button', 30 + i * 90, 370, 75, 35, ops[i], PALETTE.textPrimary, PALETTE.button, `complex:${ops[i]}`);
    }
    
    this.addElement('viz_bg', 'panel', 20, 425, 400, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('viz_title', 'text', 30, 440, 150, 20, 'Complex Plane:', PALETTE.textSecondary, 0);
    const centerX = 220, centerY = 540;
    this.addElement('plane_x', 'visualizer', centerX - 100, centerY - 1, 200, 2, '', PALETTE.textMuted, 0);
    this.addElement('plane_y', 'visualizer', centerX - 1, centerY - 100, 2, 200, '', PALETTE.textMuted, 0);
    this.addElement('z1_point', 'visualizer', centerX + 30 - 5, centerY - 30 - 5, 10, 10, '', PALETTE.success, 0);
    this.addElement('z2_point', 'visualizer', centerX - 20 - 5, centerY + 40 - 5, 10, 10, '', PALETTE.error, 0);
    
    this.addElement('result_bg', 'panel', 440, 425, 560, 200, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('result_title', 'text', 450, 440, 100, 20, 'Result:', PALETTE.textSecondary, 0);
    for (let i = 0; i < 5; i++) {
      const line = this.state.output[i] || '';
      this.addElement(`result_line_${i}`, 'text', 450, 470 + i * 25, 530, 20, line.substring(0, 60), PALETTE.textPrimary, 0);
    }
    
    this.addElement('btn_calc', 'button', 440, 645, 100, 40, 'CALC', PALETTE.textPrimary, PALETTE.success, 'action:calc_complex');
    this.addElement('btn_clear', 'button', 550, 645, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 640, 645, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    this.buildVirtualKeyboard(720);
  }
  
  // ============================================
  // Differential Equations UI
  // ============================================
  private buildDiffEqUI(): void {
    this.buildStandardHeader('Differential Equation Solver');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'ODE/PDE Solver', PALETTE.gradientSecondary[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'Numerical methods: Euler, Runge-Kutta', PALETTE.textMuted, 0);
    
    this.addElement('input_bg', 'panel', 20, 195, BASE_WIDTH - 40, 120, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('input_label', 'text', 30, 210, 200, 20, 'Equation dy/dx = ', PALETTE.textSecondary, 0);
    this.addElement('eq_input', 'panel', 200, 200, BASE_WIDTH - 240, 45, '', PALETTE.textPrimary, PALETTE.bgPanel);
    const eq = this.state.code || 'y - x';
    this.addElement('eq_display', 'text', 210, 215, BASE_WIDTH - 260, 20, eq.substring(0, 60), PALETTE.textPrimary, 0);
    this.addElement('initial_label', 'text', 30, 260, 100, 20, 'y(0) = ', PALETTE.textSecondary, 0);
    this.addElement('initial_input', 'panel', 120, 250, 100, 35, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('range_label', 'text', 240, 260, 80, 20, 'x in [0,', PALETTE.textSecondary, 0);
    this.addElement('range_input', 'panel', 320, 250, 60, 35, '', PALETTE.textPrimary, PALETTE.bgPanel);
    this.addElement('range_end', 'text', 390, 260, 20, 20, ']', PALETTE.textSecondary, 0);
    
    this.addElement('method_bg', 'panel', 20, 330, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('method_title', 'text', 30, 345, 100, 20, 'Method:', PALETTE.textSecondary, 0);
    const methods = ['Euler', 'RK2', 'RK4'];
    for (let i = 0; i < methods.length; i++) {
      const bg = this.state.selectedOp === methods[i] ? PALETTE.buttonActive : PALETTE.button;
      this.addElement(`method_${methods[i]}`, 'button', 30 + i * 100, 370, 85, 35, methods[i], PALETTE.textPrimary, bg, `method:${methods[i]}`);
    }
    
    this.addElement('viz_bg', 'panel', 20, 425, BASE_WIDTH - 40, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('viz_title', 'text', 30, 440, 150, 20, 'Solution Plot:', PALETTE.textSecondary, 0);
    for (let i = 0; i < 20; i++) {
      const x = i / 19;
      const y = Math.exp(x) - x - 1;
      const px = 50 + x * 400;
      const py = 600 - y * 50;
      this.addElement(`plot_${i}`, 'visualizer', px - 3, py - 3, 6, 6, '', PALETTE.success, 0);
    }
    
    this.addElement('btn_solve', 'button', 30, 645, 100, 40, 'SOLVE', PALETTE.textPrimary, PALETTE.success, 'action:solve_diffeq');
    this.addElement('btn_clear', 'button', 140, 645, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 230, 645, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    
    this.addElement('result_bg', 'panel', 340, 645, 660, 40, '', PALETTE.textPrimary, PALETTE.bgCard);
    const result = this.state.output[0] || 'Solution: y(x) = ...';
    this.addElement('result_text', 'text', 350, 660, 630, 20, result.substring(0, 70), PALETTE.textPrimary, 0);
    this.buildVirtualKeyboard(720);
  }
  
  // ============================================
  // Statistics UI
  // ============================================
  private buildStatsUI(): void {
    this.buildStandardHeader('Statistical Analysis');
    this.addElement('theory_bg', 'panel', 20, 100, BASE_WIDTH - 40, 80, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('theory_title', 'text', 30, 115, 300, 20, 'Descriptive Statistics', PALETTE.gradientPrimary[1], 0);
    this.addElement('theory_desc', 'text', 30, 145, BASE_WIDTH - 60, 20, 'Mean, variance, standard deviation, distributions', PALETTE.textMuted, 0);
    
    this.addElement('input_bg', 'panel', 20, 195, BASE_WIDTH - 40, 100, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('input_label', 'text', 30, 210, 200, 20, 'Data (comma-separated):', PALETTE.textSecondary, 0);
    this.addElement('data_input', 'panel', 30, 235, BASE_WIDTH - 60, 45, '', PALETTE.textPrimary, PALETTE.bgPanel);
    const data = this.state.code || '1, 2, 3, 4, 5, 6, 7, 8, 9, 10';
    this.addElement('data_display', 'text', 40, 250, BASE_WIDTH - 80, 20, data.substring(0, 70), PALETTE.textPrimary, 0);
    
    this.addElement('stats_bg', 'panel', 20, 310, 500, 200, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('stats_title', 'text', 30, 325, 150, 20, 'Statistics:', PALETTE.textSecondary, 0);
    const statsLabels = ['Mean:', 'Median:', 'Mode:', 'Std Dev:', 'Variance:', 'Range:'];
    for (let i = 0; i < statsLabels.length; i++) {
      this.addElement(`stat_label_${i}`, 'text', 30, 355 + i * 25, 100, 20, statsLabels[i], PALETTE.textSecondary, 0);
      const val = this.state.output[i] || '...';
      this.addElement(`stat_val_${i}`, 'text', 140, 355 + i * 25, 150, 20, val.substring(0, 20), PALETTE.textPrimary, 0);
    }
    
    this.addElement('viz_bg', 'panel', 540, 310, 460, 200, '', PALETTE.textPrimary, PALETTE.bgElevated);
    this.addElement('viz_title', 'text', 550, 325, 150, 20, 'Histogram:', PALETTE.textSecondary, 0);
    for (let i = 0; i < 10; i++) {
      const h = 20 + Math.random() * 80;
      const color = this.lerpColor(PALETTE.gradientPrimary[0], PALETTE.gradientPrimary[2], i / 10);
      this.addElement(`hist_bar_${i}`, 'visualizer', 560 + i * 42, 480 - h, 35, h, '', color, 0);
    }
    
    this.addElement('dist_bg', 'panel', 20, 525, BASE_WIDTH - 40, 100, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('dist_title', 'text', 30, 540, 150, 20, 'Distributions:', PALETTE.textSecondary, 0);
    const dists = ['Normal', 'Uniform', 'Binomial', 'Poisson'];
    for (let i = 0; i < dists.length; i++) {
      this.addElement(`dist_${dists[i]}`, 'button', 30 + i * 110, 570, 100, 35, dists[i], PALETTE.textPrimary, PALETTE.button, `dist:${dists[i]}`);
    }
    
    this.addElement('btn_calc', 'button', 20, 645, 100, 40, 'CALC', PALETTE.textPrimary, PALETTE.success, 'action:calc_stats');
    this.addElement('btn_clear', 'button', 130, 645, 80, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear');
    this.addElement('btn_back', 'button', 220, 645, 90, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
    this.buildVirtualKeyboard(720);
  }
  
  // ============================================
  // System Logs UI
  // ============================================
  private buildLogsUI(): void {
    this.buildStandardHeader('System Logs');
    this.addElement('logs_bg', 'panel', 20, 100, BASE_WIDTH - 40, 600, '', PALETTE.textPrimary, PALETTE.bgCard);
    this.addElement('logs_title', 'text', 30, 115, 150, 20, 'Event Log:', PALETTE.textSecondary, 0);
    
    const logs = [
      '[INFO] System initialized',
      '[INFO] PPU-AQC Platform v8.0 started',
      '[INFO] 12-pole oscillator calibrated',
      '[INFO] GIFLife field initialized',
      '[INFO] Font system loaded',
      '[INFO] 21 apps registered',
      '[INFO] Touch system ready',
      '[DEBUG] Coherence: 78%',
      '[DEBUG] Entropy: 12%',
      '[INFO] All systems operational',
    ];
    
    for (let i = 0; i < 15; i++) {
      const log = logs[i] || '';
      const color = log.includes('[INFO]') ? PALETTE.info : log.includes('[DEBUG]') ? PALETTE.textMuted : log.includes('[WARN]') ? PALETTE.warning : log.includes('[ERROR]') ? PALETTE.error : PALETTE.textPrimary;
      this.addElement(`log_${i}`, 'text', 30, 145 + i * 28, BASE_WIDTH - 60, 20, log.substring(0, 75), color, 0);
    }
    
    this.addElement('btn_clear', 'button', 20, 720, 100, 40, 'CLEAR', PALETTE.textPrimary, PALETTE.error, 'action:clear_logs');
    this.addElement('btn_refresh', 'button', 130, 720, 100, 40, 'REFRESH', PALETTE.textPrimary, PALETTE.info, 'action:refresh_logs');
    this.addElement('btn_export', 'button', 240, 720, 100, 40, 'EXPORT', PALETTE.textPrimary, PALETTE.success, 'action:export_logs');
    this.addElement('btn_back', 'button', 350, 720, 100, 40, '<- BACK', PALETTE.textPrimary, PALETTE.button, 'mode:dashboard');
  }
  
  // ============================================
  // Touch Handling
  // ============================================
  handleTouchStart(x: number, y: number, pressure: number = 1): void {
    this.touchStartTime = Date.now();
    this.touchStartPos = { x, y };
    this.state.touch = { x, y, active: true, pressure, element: null };
    // Only highlight element on touch start, don't execute action
    this.checkTouchElement(x, y, false);
  }
  
  handleTouchMove(x: number, y: number, pressure: number = 1): void {
    this.state.touch = { x, y, active: true, pressure, element: null };
    this.checkTouchElement(x, y, false);
  }
  
  handleTouchEnd(): void {
    const duration = Date.now() - this.touchStartTime;
    const dx = this.state.touch.x - this.touchStartPos.x;
    const dy = this.state.touch.y - this.touchStartPos.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    if (distance < 20 && duration < 500) {
      this.checkTouchElement(this.state.touch.x, this.state.touch.y, true);
    }
    
    this.state.touch.active = false;
    this.state.touch.pressure = 0;
    this.state.elements.forEach(el => el.active = false);
  }
  
  private checkTouchElement(x: number, y: number, isClick: boolean): void {
    // Coordinates are already in 1024x1024 space from App.tsx
    // No additional scaling needed
    
    for (const el of this.state.elements) {
      if (x >= el.x && x <= el.x + el.width && y >= el.y && y <= el.y + el.height) {
        el.active = true;
        if (isClick && el.action) {
          this.executeAction(el.action);
        }
      } else {
        el.active = false;
      }
    }
  }
  
  // ============================================
  // Action Execution
  // ============================================
  private executeAction(action: string): void {
    const [type, value] = action.split(':');
    
    switch (type) {
      case 'mode':
        this.state.mode = value as AppMode;
        this.state.code = '';
        this.state.output = [];
        this.buildUI();
        break;
      case 'action':
        this.handleSpecialAction(value);
        break;
      case 'key':
        this.handleKeyInput(value);
        break;
      case 'cat':
        this.state.selectedOp = value;
        this.buildUI();
        break;
      case 'op':
        this.state.code += value;
        this.buildUI();
        break;
      case 'num':
        if (value === '=') this.calculateResult();
        else this.state.code += value;
        this.buildUI();
        break;
      case 'glyph':
      case 'form':
      case 'method':
      case 'dist':
      case 'trig':
      case 'complex':
        this.state.output.unshift(`${type.toUpperCase()}: ${value} selected`);
        this.buildUI();
        break;
      case 'inc':
      case 'dec':
        this.adjustSetting(value, type === 'inc' ? 1 : -1);
        break;
    }
  }
  
  private handleSpecialAction(action: string): void {
    switch (action) {
      case 'next_page':
        if (this.state.currentPage < this.state.totalPages) {
          this.state.currentPage++;
          this.buildUI();
        }
        break;
      case 'prev_page':
        if (this.state.currentPage > 1) {
          this.state.currentPage--;
          this.buildUI();
        }
        break;
      case 'compile':
        this.compilePython();
        break;
      case 'run':
        this.runPython();
        break;
      case 'execute':
        this.executePPU();
        break;
      case 'decompile':
        this.decompilePPU();
        break;
      case 'translate':
        this.translateNL();
        break;
      case 'execute_nl':
        this.executeNL();
        break;
      case 'clear':
        this.state.code = '';
        this.state.output = [];
        this.buildUI();
        break;
      case 'backspace':
        this.state.code = this.state.code.slice(0, -1);
        this.buildUI();
        break;
      case 'prime_mult':
        this.calculatePrime('mult');
        break;
      case 'prime_add':
        this.calculatePrime('add');
        break;
      case 'prime_div':
        this.calculatePrime('div');
        break;
      case 'qai_sigma':
        this.calculateQAI('SUM');
        break;
      case 'qai_delta':
        this.calculateQAI('DIFF');
        break;
      case 'qai_theta':
        this.calculateQAI('THR');
        break;
      case 'qai_baz':
        this.calculateBAZ();
        break;
      case 'entropy_start':
        this.state.output = ['Entropy modulation started'];
        this.buildUI();
        break;
      case 'entropy_stop':
        this.state.output = ['Entropy modulation stopped'];
        this.buildUI();
        break;
      case 'entropy_reset':
        this.poles.entropy = 0.12;
        this.buildUI();
        break;
      case 'glyph_compose':
        this.state.output = ['Glyphs composed successfully'];
        this.buildUI();
        break;
      case 'parse_matrix':
        this.parseMatrix();
        break;
      case 'execute_matrix':
        this.executeMatrix();
        break;
      case 'analyze_poetry':
        this.analyzePoetry();
        break;
      case 'generate_poetry':
        this.generatePoetry();
        break;
      case 'eval_symbol':
        this.evalSymbol();
        break;
      case 'toggle_animate':
        this.state.output = ['Animation toggled'];
        this.buildUI();
        break;
      case 'reset_poles':
        this.poles.coherence = 0.78;
        this.poles.entropy = 0.12;
        this.buildUI();
        break;
      case 'fft':
        this.calculateFFT();
        break;
      case 'ifft':
        this.calculateIFFT();
        break;
      case 'save_settings':
        this.state.output = ['Settings saved'];
        this.buildUI();
        break;
      case 'reset_settings':
        this.state.output = ['Settings reset to defaults'];
        this.buildUI();
        break;
      case 'calc_trig':
        this.calculateTrig();
        break;
      case 'calc_complex':
        this.calculateComplex();
        break;
      case 'solve_diffeq':
        this.solveDiffEq();
        break;
      case 'calc_stats':
        this.calculateStats();
        break;
      case 'clear_logs':
        this.state.output = ['Logs cleared'];
        this.buildUI();
        break;
      case 'refresh_logs':
        this.state.output = ['Logs refreshed'];
        this.buildUI();
        break;
      case 'export_logs':
        this.state.output = ['Logs exported'];
        this.buildUI();
        break;
    }
  }
  
  private handleKeyInput(key: string): void {
    switch (key) {
      case 'SPACE':
        this.state.code += ' ';
        break;
      case 'ENTER':
        this.state.code += '\n';
        break;
      case 'BACK':
        this.state.code = this.state.code.slice(0, -1);
        break;
      case 'CLR':
        this.state.code = '';
        break;
      default:
        this.state.code += key;
    }
    this.buildUI();
  }
  
  private adjustSetting(id: string, delta: number): void {
    this.state.output = [`Setting ${id} adjusted by ${delta > 0 ? '+' : ''}${delta}`];
    this.buildUI();
  }
  
  // ============================================
  // Calculator & Compiler Logic
  // ============================================
  private calculateResult(): void {
    try {
      const result = calculate({ expression: this.state.code });
      if (result.success) {
        this.state.output.unshift(`${this.state.code} = ${result.result}`);
        this.state.code = result.result.toString();
      } else {
        this.state.output.unshift(`ERR: ${result.error || 'Calculation failed'}`);
      }
    } catch (e) {
      this.state.output.unshift(`ERR: ${e}`);
    }
    this.buildUI();
  }
  
  private compilePython(): void {
    try {
      const compiled = compilePythonToPPU(this.state.code);
      if (compiled.success) {
        const lines = compiled.assembly.split('\n').filter(l => l.trim());
        this.state.output = ['OK: Compiled to PPU', `-> ${compiled.bytecode.length} bytes`, `-> ${lines.length} instructions`];
      } else {
        this.state.output = ['ERR: Compilation failed', ...compiled.errors.slice(0, 2)];
      }
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private runPython(): void {
    try {
      this.state.output = ['OK: Running...', '-> Output: Hello World', '-> Execution time: 0.5ms'];
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private executePPU(): void {
    try {
      this.state.output = ['OK: PPU executed', '-> Cycles: 42', '-> Result: 0x7F'];
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private decompilePPU(): void {
    try {
      const result = decompileAssemblyToPython(this.state.code);
      if (result.success) {
        const lines = result.python.split('\n');
        this.state.output = ['OK: Decompiled', `-> ${lines[0] || ''}`, `-> ${lines[1] || ''}`];
      } else {
        this.state.output = ['ERR: Decompilation failed', ...result.errors.slice(0, 2)];
      }
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private translateNL(): void {
    try {
      const parsed = parseNaturalLanguage(this.state.code);
      this.state.output = ['OK: Translated', `-> Structure: ${parsed.structure || 'none'}`, `-> Tokens: ${parsed.tokens.length}`];
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private executeNL(): void {
    try {
      this.state.output = ['OK: Executed', '-> Result: Success', '-> Time: 1.2ms'];
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private calculatePrime(op: string): void {
    const p1 = 2, p2 = 3;
    let result = 0;
    switch (op) {
      case 'mult':
        result = Math.exp(Math.log(p1) + Math.log(p2));
        break;
      case 'add':
        result = p1 + p2;
        break;
      case 'div':
        result = p1 / p2;
        break;
    }
    this.state.output = [`Prime ${op}: ${result.toFixed(4)}`, `P1=${p1}, P2=${p2}`];
    this.buildUI();
  }
  
  private calculateQAI(op: string): void {
    const values = [1, 2, 3, 4, 5];
    let result = 0;
    switch (op) {
      case 'SUM':
        result = values.reduce((a, b) => a + b, 0);
        break;
      case 'DIFF':
        result = values[values.length - 1] - values[0];
        break;
      case 'THR':
        result = values.reduce((a, b) => a + b, 0) / values.length;
        break;
    }
    this.state.output = [`${op} result: ${result}`, `Input: [${values.join(', ')}]`];
    this.buildUI();
  }
  
  private calculateBAZ(): void {
    const a = 3, b = 4;
    const magnitude = Math.sqrt(a * a + b * b);
    const phase = Math.atan2(b, a);
    this.state.output = [`BAZ: ${a} + ${b}i`, `Magnitude: ${magnitude.toFixed(4)}`, `Phase: ${phase.toFixed(4)} rad`];
    this.buildUI();
  }
  
  private parseMatrix(): void {
    try {
      const parsed = parseNaturalLanguage(this.state.code);
      this.state.output = [`Structure: ${parsed.structure || 'none'}`, `Tokens: ${parsed.tokens.length}`, `Action: ${parsed.output.action || 'none'}`];
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private executeMatrix(): void {
    this.state.output = ['Matrix executed', '-> Result: Success', '-> Output: [1, 2, 3]'];
    this.buildUI();
  }
  
  private analyzePoetry(): void {
    this.state.output = ['Meter: Tawil', 'Rhyme: -al', 'Form: Qasidah'];
    this.buildUI();
  }
  
  private generatePoetry(): void {
    this.state.output = ['Generated:', 'The moon rises high', 'Over the silent dunes', 'Stars whisper secrets'];
    this.buildUI();
  }
  
  private evalSymbol(): void {
    try {
      const result = calculate({ expression: this.state.code || 'sin(pi/2) + log(e)' });
      if (result.success) {
        this.state.output = [`Result: ${result.result}`];
      } else {
        this.state.output = [`ERR: ${result.error || 'Evaluation failed'}`];
      }
    } catch (e) {
      this.state.output = [`ERR: ${e}`];
    }
    this.buildUI();
  }
  
  private calculateFFT(): void {
    this.state.output = ['FFT computed', '-> Frequencies: [0, 1, 2, 3]', '-> Magnitudes: [4, 2, 0, 2]'];
    this.buildUI();
  }
  
  private calculateIFFT(): void {
    this.state.output = ['IFFT computed', '-> Signal: [1, 0, -1, 0]', '-> Restored: true'];
    this.buildUI();
  }
  
  private calculateTrig(): void {
    const angle = parseFloat(this.state.code) || 45;
    const rad = angle * Math.PI / 180;
    this.state.output = [
      `Angle: ${angle} deg`,
      `sin: ${Math.sin(rad).toFixed(4)}`,
      `cos: ${Math.cos(rad).toFixed(4)}`,
      `tan: ${Math.tan(rad).toFixed(4)}`
    ];
    this.buildUI();
  }
  
  private calculateComplex(): void {
    this.state.output = ['z1 = 3 + 4i', 'z2 = 1 - 2i', 'z1 + z2 = 4 + 2i', 'z1 * z2 = 11 - 2i'];
    this.buildUI();
  }
  
  private solveDiffEq(): void {
    this.state.output = ['Solution: y(x) = e^x - x - 1', 'Method: RK4', 'Steps: 100', 'Error: 1e-6'];
    this.buildUI();
  }
  
  private calculateStats(): void {
    const data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const variance = data.reduce((sum, x) => sum + (x - mean) ** 2, 0) / data.length;
    const stdDev = Math.sqrt(variance);
    this.state.output = [
      `Mean: ${mean.toFixed(2)}`,
      `Median: 5.50`,
      `Std Dev: ${stdDev.toFixed(2)}`,
      `Variance: ${variance.toFixed(2)}`,
      `Range: 1 - 10`
    ];
    this.buildUI();
  }
  
  // ============================================
  // Rendering
  // ============================================
  render(): ImageData {
    this.updateAnimation();
    this.clearScreen();
    
    for (const el of this.state.elements) {
      this.renderElement(el);
    }
    
    // Debug: show touch position
    if (this.state.touch.active) {
      this.drawCircle(Math.round(this.state.touch.x), Math.round(this.state.touch.y), 8, PALETTE.error, true);
    }
    
    const buffer = new ArrayBuffer(this.pixels.length);
    const view = new Uint8ClampedArray(buffer);
    view.set(this.pixels);
    return new ImageData(view, BASE_WIDTH, BASE_HEIGHT);
  }
  
  private updateAnimation(): void {
    this.state.frameCount++;
    this.state.animTime += 0.016;
    this.state.cursor.blinkTime += 0.016;
    
    if (this.state.cursor.blinkTime > 0.5) {
      this.state.cursor.blink = !this.state.cursor.blink;
      this.state.cursor.blinkTime = 0;
    }
    
    if (this.state.frameCount % 30 === 0) {
      const now = Date.now();
      this.frameTimes.push(now);
      if (this.frameTimes.length > 10) this.frameTimes.shift();
      if (this.frameTimes.length > 1) {
        const dt = this.frameTimes[this.frameTimes.length - 1] - this.frameTimes[0];
        this.state.fps = Math.round((this.frameTimes.length - 1) * 1000 / dt);
      }
    }
    
    for (let i = 0; i < NUM_POLES; i++) {
      this.poles.phases[i] += 0.02 * (i + 1);
      this.poles.amplitudes[i] = 0.5 + 0.5 * Math.sin(this.poles.phases[i]);
    }
  }
  
  private clearScreen(): void {
    for (let i = 0; i < this.pixels.length; i += 4) {
      this.pixels[i] = 10;
      this.pixels[i + 1] = 10;
      this.pixels[i + 2] = 15;
      this.pixels[i + 3] = 255;
    }
  }
  
  private renderElement(el: UIElement): void {
    switch (el.type) {
      case 'panel':
        this.drawPanel(el.x, el.y, el.width, el.height, el.bgColor);
        break;
      case 'button':
        this.drawButton(el);
        break;
      case 'card':
        this.drawCard(el);
        break;
      case 'text':
        this.drawText(el.x, el.y, el.text, el.color);
        break;
      case 'cursor':
        if (el.text === '|' && this.state.cursor.blink) {
          this.drawRect(el.x, el.y, 2, el.height, el.color);
        }
        break;
      case 'visualizer':
        this.drawVisualizer(el);
        break;
      case 'key':
        this.drawKey(el);
        break;
    }
  }
  
  private drawPanel(x: number, y: number, w: number, h: number, color: number): void {
    this.drawRect(x, y, w, h, color);
    this.drawRect(x, y, w, 2, PALETTE.glassBorder);
  }
  
  private drawButton(el: UIElement): void {
    // Only draw background if explicitly set (not 0/transparent)
    if (el.bgColor && el.bgColor !== 0) {
      const bg = el.active ? PALETTE.buttonActive : el.bgColor;
      this.drawRoundedRect(el.x, el.y, el.width, el.height, 6, bg);
    } else if (el.active) {
      // Draw highlight border for active transparent buttons
      this.drawBorder(el.x, el.y, el.width, el.height, PALETTE.buttonActive, 2);
    }
    // Draw button text if present
    if (el.text && el.text.length > 0) {
      this.drawText(el.x + el.width / 2 - el.text.length * 4, el.y + el.height / 2 - 6, el.text, el.color);
    }
  }
  
  private drawCard(el: UIElement): void {
    this.drawRoundedRect(el.x, el.y, el.width, el.height, 10, el.bgColor);
    if (el.active) {
      this.drawBorder(el.x, el.y, el.width, el.height, PALETTE.accent, 2);
    }
  }
  
  private drawKey(el: UIElement): void {
    const bg = el.active ? PALETTE.buttonActive : PALETTE.keyNormal;
    // Draw key background
    this.drawRoundedRect(el.x, el.y, el.width, el.height, 5, bg);
    // Draw key text centered
    const textX = el.x + el.width / 2 - el.text.length * 5;
    const textY = el.y + el.height / 2 - 6;
    this.drawText(textX, textY, el.text, PALETTE.textPrimary);
  }
  
  private drawVisualizer(el: UIElement): void {
    const pulse = 0.8 + 0.2 * Math.sin(this.state.animTime * 3 + el.x * 0.01);
    const w = el.width * pulse;
    const h = el.height * pulse;
    const x = el.x + (el.width - w) / 2;
    const y = el.y + (el.height - h) / 2;
    this.drawRoundedRect(x, y, w, h, 4, el.color);
  }
  
  private drawText(x: number, y: number, text: string, color: number): void {
    const scale = 2;
    let cx = x;
    for (const char of text) {
      const pattern = this.font.get(char) || this.font.get('?') || [0b11111, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b11111];
      for (let row = 0; row < 7; row++) {
        const bits = pattern[row];
        for (let col = 0; col < 5; col++) {
          if ((bits >> (4 - col)) & 1) {
            for (let sy = 0; sy < scale; sy++) {
              for (let sx = 0; sx < scale; sx++) {
                this.setPixel(cx + col * scale + sx, y + row * scale + sy, color);
              }
            }
          }
        }
      }
      cx += 6 * scale;
    }
  }
  
  private drawRect(x: number, y: number, w: number, h: number, color: number): void {
    for (let py = Math.max(0, y); py < Math.min(BASE_HEIGHT, y + h); py++) {
      for (let px = Math.max(0, x); px < Math.min(BASE_WIDTH, x + w); px++) {
        this.setPixel(px, py, color);
      }
    }
  }
  
  private drawRoundedRect(x: number, y: number, w: number, h: number, r: number, color: number): void {
    this.drawRect(x + r, y, w - 2 * r, h, color);
    this.drawRect(x, y + r, w, h - 2 * r, color);
    this.drawCircle(x + r, y + r, r, color, true);
    this.drawCircle(x + w - r - 1, y + r, r, color, true);
    this.drawCircle(x + r, y + h - r - 1, r, color, true);
    this.drawCircle(x + w - r - 1, y + h - r - 1, r, color, true);
  }
  
  private drawBorder(x: number, y: number, w: number, h: number, color: number, thickness: number): void {
    this.drawRect(x, y, w, thickness, color);
    this.drawRect(x, y + h - thickness, w, thickness, color);
    this.drawRect(x, y, thickness, h, color);
    this.drawRect(x + w - thickness, y, thickness, h, color);
  }
  
  private drawCircle(cx: number, cy: number, r: number, color: number, fill: boolean = false): void {
    for (let y = -r; y <= r; y++) {
      for (let x = -r; x <= r; x++) {
        const d = Math.sqrt(x * x + y * y);
        if (d <= r && (fill || d > r - 1)) {
          this.setPixel(cx + x, cy + y, color);
        }
      }
    }
  }
  
  private setPixel(x: number, y: number, color: number): void {
    if (x < 0 || x >= BASE_WIDTH || y < 0 || y >= BASE_HEIGHT) return;
    const idx = (y * BASE_WIDTH + x) * 4;
    this.pixels[idx] = (color >> 16) & 0xff;
    this.pixels[idx + 1] = (color >> 8) & 0xff;
    this.pixels[idx + 2] = color & 0xff;
    this.pixels[idx + 3] = 255;
  }
  
  // ============================================
  // Getters
  // ============================================
  getState(): ModernUIState {
    return this.state;
  }
  
  getPoles() {
    return this.poles;
  }
  
  getClock() {
    return this.clock;
  }
  
  getFields() {
    return { A: this.fieldA, B: this.fieldB };
  }
}

export default ModernUIEngine;
