/**
 * Symbolic Mathematics Library
 * Extends prime domain with symbolic computation
 * 100+ mathematical symbols and operations
 */

import { toPrimeVector } from './ppu-core';

// ============================================
// Symbol Library (100+ symbols)
// ============================================

export interface MathSymbol {
  name: string;
  latex: string;
  unicode: string;
  description: string;
  category: 'constant' | 'variable' | 'operator' | 'function' | 'relation' | 'set' | 'logic';
  value?: number;
}

export const MATH_SYMBOLS: MathSymbol[] = [
  // Constants (20)
  { name: 'pi', latex: '\\pi', unicode: 'π', description: 'Ratio of circumference to diameter', category: 'constant', value: Math.PI },
  { name: 'e', latex: 'e', unicode: 'e', description: 'Euler\'s number', category: 'constant', value: Math.E },
  { name: 'phi', latex: '\\phi', unicode: 'φ', description: 'Golden ratio', category: 'constant', value: 1.618033988749895 },
  { name: 'gamma', latex: '\\gamma', unicode: 'γ', description: 'Euler-Mascheroni constant', category: 'constant', value: 0.5772156649015329 },
  { name: 'sqrt2', latex: '\\sqrt{2}', unicode: '√2', description: 'Square root of 2', category: 'constant', value: Math.SQRT2 },
  { name: 'sqrt1_2', latex: '\\frac{1}{\\sqrt{2}}', unicode: '1/√2', description: '1 over square root of 2', category: 'constant', value: Math.SQRT1_2 },
  { name: 'ln2', latex: '\\ln 2', unicode: 'ln 2', description: 'Natural log of 2', category: 'constant', value: 0.6931471805599453 },
  { name: 'ln10', latex: '\\ln 10', unicode: 'ln 10', description: 'Natural log of 10', category: 'constant', value: 2.302585092994046 },
  { name: 'log2e', latex: '\\log_2 e', unicode: 'log₂e', description: 'Log base 2 of e', category: 'constant', value: 1.4426950408889634 },
  { name: 'log10e', latex: '\\log_{10} e', unicode: 'log₁₀e', description: 'Log base 10 of e', category: 'constant', value: 0.4342944819032518 },
  { name: 'infinity', latex: '\\infty', unicode: '∞', description: 'Infinity', category: 'constant', value: Infinity },
  { name: 'nan', latex: '\\text{NaN}', unicode: 'NaN', description: 'Not a Number', category: 'constant', value: NaN },
  { name: 'c', latex: 'c', unicode: 'c', description: 'Speed of light (m/s)', category: 'constant', value: 299792458 },
  { name: 'G', latex: 'G', unicode: 'G', description: 'Gravitational constant', category: 'constant', value: 6.67430e-11 },
  { name: 'h', latex: 'h', unicode: 'h', description: 'Planck constant (J⋅s)', category: 'constant', value: 6.62607015e-34 },
  { name: 'hbar', latex: '\\hbar', unicode: 'ℏ', description: 'Reduced Planck constant', category: 'constant', value: 1.054571817e-34 },
  { name: 'k', latex: 'k', unicode: 'k', description: 'Boltzmann constant (J/K)', category: 'constant', value: 1.380649e-23 },
  { name: 'N_A', latex: 'N_A', unicode: 'Nₐ', description: 'Avogadro constant', category: 'constant', value: 6.02214076e23 },
  { name: 'R', latex: 'R', unicode: 'R', description: 'Gas constant (J/mol⋅K)', category: 'constant', value: 8.314462618 },
  { name: 'epsilon0', latex: '\\varepsilon_0', unicode: 'ε₀', description: 'Vacuum permittivity', category: 'constant', value: 8.8541878128e-12 },
  
  // Variables (20)
  { name: 'x', latex: 'x', unicode: 'x', description: 'Variable x', category: 'variable' },
  { name: 'y', latex: 'y', unicode: 'y', description: 'Variable y', category: 'variable' },
  { name: 'z', latex: 'z', unicode: 'z', description: 'Variable z', category: 'variable' },
  { name: 't', latex: 't', unicode: 't', description: 'Time variable', category: 'variable' },
  { name: 'n', latex: 'n', unicode: 'n', description: 'Integer variable', category: 'variable' },
  { name: 'i', latex: 'i', unicode: 'i', description: 'Index variable', category: 'variable' },
  { name: 'j', latex: 'j', unicode: 'j', description: 'Index variable', category: 'variable' },
  { name: 'k', latex: 'k', unicode: 'k', description: 'Wave number', category: 'variable' },
  { name: 'm', latex: 'm', unicode: 'm', description: 'Mass variable', category: 'variable' },
  { name: 'v', latex: 'v', unicode: 'v', description: 'Velocity variable', category: 'variable' },
  { name: 'a', latex: 'a', unicode: 'a', description: 'Acceleration variable', category: 'variable' },
  { name: 'r', latex: 'r', unicode: 'r', description: 'Radius variable', category: 'variable' },
  { name: 'theta', latex: '\\theta', unicode: 'θ', description: 'Angle variable', category: 'variable' },
  { name: 'alpha', latex: '\\alpha', unicode: 'α', description: 'Alpha variable', category: 'variable' },
  { name: 'beta', latex: '\\beta', unicode: 'β', description: 'Beta variable', category: 'variable' },
  { name: 'gamma_var', latex: '\\gamma', unicode: 'γ', description: 'Gamma variable', category: 'variable' },
  { name: 'delta', latex: '\\delta', unicode: 'δ', description: 'Delta variable', category: 'variable' },
  { name: 'lambda', latex: '\\lambda', unicode: 'λ', description: 'Lambda variable', category: 'variable' },
  { name: 'mu', latex: '\\mu', unicode: 'μ', description: 'Mu variable', category: 'variable' },
  { name: 'sigma', latex: '\\sigma', unicode: 'σ', description: 'Sigma variable', category: 'variable' },
  
  // Operators (25)
  { name: 'plus', latex: '+', unicode: '+', description: 'Addition', category: 'operator' },
  { name: 'minus', latex: '-', unicode: '−', description: 'Subtraction', category: 'operator' },
  { name: 'times', latex: '\\times', unicode: '×', description: 'Multiplication', category: 'operator' },
  { name: 'div', latex: '\\div', unicode: '÷', description: 'Division', category: 'operator' },
  { name: 'pm', latex: '\\pm', unicode: '±', description: 'Plus-minus', category: 'operator' },
  { name: 'mp', latex: '\\mp', unicode: '∓', description: 'Minus-plus', category: 'operator' },
  { name: 'cdot', latex: '\\cdot', unicode: '⋅', description: 'Dot product', category: 'operator' },
  { name: 'star', latex: '\\star', unicode: '⋆', description: 'Star operator', category: 'operator' },
  { name: 'circ', latex: '\\circ', unicode: '∘', description: 'Function composition', category: 'operator' },
  { name: 'oplus', latex: '\\oplus', unicode: '⊕', description: 'Direct sum', category: 'operator' },
  { name: 'ominus', latex: '\\ominus', unicode: '⊖', description: 'Direct minus', category: 'operator' },
  { name: 'otimes', latex: '\\otimes', unicode: '⊗', description: 'Tensor product', category: 'operator' },
  { name: 'oslash', latex: '\\oslash', unicode: '⊘', description: 'Division operator', category: 'operator' },
  { name: 'odot', latex: '\\odot', unicode: '⊙', description: 'Hadamard product', category: 'operator' },
  { name: 'wedge', latex: '\\wedge', unicode: '∧', description: 'Wedge product', category: 'operator' },
  { name: 'vee', latex: '\\vee', unicode: '∨', description: 'Vee product', category: 'operator' },
  { name: 'cap', latex: '\\cap', unicode: '∩', description: 'Intersection', category: 'operator' },
  { name: 'cup', latex: '\\cup', unicode: '∪', description: 'Union', category: 'operator' },
  { name: 'uplus', latex: '\\uplus', unicode: '⊎', description: 'Multiset union', category: 'operator' },
  { name: 'sqcap', latex: '\\sqcap', unicode: '⊓', description: 'Square cap', category: 'operator' },
  { name: 'sqcup', latex: '\\sqcup', unicode: '⊔', description: 'Square cup', category: 'operator' },
  { name: 'triangleleft', latex: '\\triangleleft', unicode: '◁', description: 'Left triangle', category: 'operator' },
  { name: 'triangleright', latex: '\\triangleright', unicode: '▷', description: 'Right triangle', category: 'operator' },
  { name: 'bigtriangleup', latex: '\\bigtriangleup', unicode: '△', description: 'Big triangle up', category: 'operator' },
  { name: 'bigtriangledown', latex: '\\bigtriangledown', unicode: '▽', description: 'Big triangle down', category: 'operator' },
  
  // Functions (20)
  { name: 'sin', latex: '\\sin', unicode: 'sin', description: 'Sine function', category: 'function' },
  { name: 'cos', latex: '\\cos', unicode: 'cos', description: 'Cosine function', category: 'function' },
  { name: 'tan', latex: '\\tan', unicode: 'tan', description: 'Tangent function', category: 'function' },
  { name: 'asin', latex: '\\arcsin', unicode: 'arcsin', description: 'Arcsine function', category: 'function' },
  { name: 'acos', latex: '\\arccos', unicode: 'arccos', description: 'Arccosine function', category: 'function' },
  { name: 'atan', latex: '\\arctan', unicode: 'arctan', description: 'Arctangent function', category: 'function' },
  { name: 'sinh', latex: '\\sinh', unicode: 'sinh', description: 'Hyperbolic sine', category: 'function' },
  { name: 'cosh', latex: '\\cosh', unicode: 'cosh', description: 'Hyperbolic cosine', category: 'function' },
  { name: 'tanh', latex: '\\tanh', unicode: 'tanh', description: 'Hyperbolic tangent', category: 'function' },
  { name: 'exp', latex: '\\exp', unicode: 'exp', description: 'Exponential function', category: 'function' },
  { name: 'ln', latex: '\\ln', unicode: 'ln', description: 'Natural logarithm', category: 'function' },
  { name: 'log', latex: '\\log', unicode: 'log', description: 'Logarithm', category: 'function' },
  { name: 'sqrt', latex: '\\sqrt', unicode: '√', description: 'Square root', category: 'function' },
  { name: 'abs', latex: '\\left|x\\right|', unicode: '|x|', description: 'Absolute value', category: 'function' },
  { name: 'floor', latex: '\\lfloor x \\rfloor', unicode: '⌊x⌋', description: 'Floor function', category: 'function' },
  { name: 'ceil', latex: '\\lceil x \\rceil', unicode: '⌈x⌉', description: 'Ceiling function', category: 'function' },
  { name: 'min', latex: '\\min', unicode: 'min', description: 'Minimum', category: 'function' },
  { name: 'max', latex: '\\max', unicode: 'max', description: 'Maximum', category: 'function' },
  { name: 'gcd', latex: '\\gcd', unicode: 'gcd', description: 'Greatest common divisor', category: 'function' },
  { name: 'lcm', latex: '\\text{lcm}', unicode: 'lcm', description: 'Least common multiple', category: 'function' },
  
  // Relations (15)
  { name: 'eq', latex: '=', unicode: '=', description: 'Equality', category: 'relation' },
  { name: 'neq', latex: '\\neq', unicode: '≠', description: 'Not equal', category: 'relation' },
  { name: 'lt', latex: '<', unicode: '<', description: 'Less than', category: 'relation' },
  { name: 'gt', latex: '>', unicode: '>', description: 'Greater than', category: 'relation' },
  { name: 'leq', latex: '\\leq', unicode: '≤', description: 'Less than or equal', category: 'relation' },
  { name: 'geq', latex: '\\geq', unicode: '≥', description: 'Greater than or equal', category: 'relation' },
  { name: 'll', latex: '\\ll', unicode: '≪', description: 'Much less than', category: 'relation' },
  { name: 'gg', latex: '\\gg', unicode: '≫', description: 'Much greater than', category: 'relation' },
  { name: 'equiv', latex: '\\equiv', unicode: '≡', description: 'Equivalence', category: 'relation' },
  { name: 'sim', latex: '\\sim', unicode: '∼', description: 'Similar to', category: 'relation' },
  { name: 'simeq', latex: '\\simeq', unicode: '≃', description: 'Asymptotically equal', category: 'relation' },
  { name: 'approx', latex: '\\approx', unicode: '≈', description: 'Approximately equal', category: 'relation' },
  { name: 'propto', latex: '\\propto', unicode: '∝', description: 'Proportional to', category: 'relation' },
  { name: 'in', latex: '\\in', unicode: '∈', description: 'Element of', category: 'relation' },
  { name: 'notin', latex: '\\notin', unicode: '∉', description: 'Not element of', category: 'relation' },
  
  // Set notation (10)
  { name: 'emptyset', latex: '\\emptyset', unicode: '∅', description: 'Empty set', category: 'set' },
  { name: 'subset', latex: '\\subset', unicode: '⊂', description: 'Subset', category: 'set' },
  { name: 'supset', latex: '\\supset', unicode: '⊃', description: 'Superset', category: 'set' },
  { name: 'subseteq', latex: '\\subseteq', unicode: '⊆', description: 'Subset or equal', category: 'set' },
  { name: 'supseteq', latex: '\\supseteq', unicode: '⊇', description: 'Superset or equal', category: 'set' },
  { name: 'nsubseteq', latex: '\\nsubseteq', unicode: '⊈', description: 'Not subset', category: 'set' },
  { name: 'nsupseteq', latex: '\\nsupseteq', unicode: '⊉', description: 'Not superset', category: 'set' },
  { name: 'setminus', latex: '\\setminus', unicode: '∖', description: 'Set difference', category: 'set' },
  { name: 'forall', latex: '\\forall', unicode: '∀', description: 'For all', category: 'set' },
  { name: 'exists', latex: '\\exists', unicode: '∃', description: 'There exists', category: 'set' },
  
  // Logic (10)
  { name: 'land', latex: '\\land', unicode: '∧', description: 'Logical AND', category: 'logic' },
  { name: 'lor', latex: '\\lor', unicode: '∨', description: 'Logical OR', category: 'logic' },
  { name: 'lnot', latex: '\\lnot', unicode: '¬', description: 'Logical NOT', category: 'logic' },
  { name: 'Rightarrow', latex: '\\Rightarrow', unicode: '⇒', description: 'Implies', category: 'logic' },
  { name: 'Leftarrow', latex: '\\Leftarrow', unicode: '⇐', description: 'Implied by', category: 'logic' },
  { name: 'Leftrightarrow', latex: '\\Leftrightarrow', unicode: '⇔', description: 'If and only if', category: 'logic' },
  { name: 'top', latex: '\\top', unicode: '⊤', description: 'True', category: 'logic' },
  { name: 'bot', latex: '\\bot', unicode: '⊥', description: 'False', category: 'logic' },
  { name: 'models', latex: '\\models', unicode: '⊨', description: 'Models', category: 'logic' },
  { name: 'vdash', latex: '\\vdash', unicode: '⊢', description: 'Proves', category: 'logic' },
  
  // Differential Operators (15)
  { name: 'partial', latex: '\\partial', unicode: '∂', description: 'Partial derivative', category: 'operator' },
  { name: 'nabla', latex: '\\nabla', unicode: '∇', description: 'Nabla/del operator', category: 'operator' },
  { name: 'Delta', latex: '\\Delta', unicode: 'Δ', description: 'Laplacian/difference', category: 'operator' },
  { name: 'delta', latex: '\\delta', unicode: 'δ', description: 'Dirac delta', category: 'operator' },
  { name: 'prime', latex: "'", unicode: '′', description: 'Derivative prime', category: 'operator' },
  { name: 'dprime', latex: "''", unicode: '″', description: 'Second derivative', category: 'operator' },
  { name: 'dot', latex: '\\dot', unicode: '˙', description: 'Time derivative (dot)', category: 'operator' },
  { name: 'ddot', latex: '\\ddot', unicode: '¨', description: 'Second time derivative', category: 'operator' },
  { name: 'grad', latex: '\\nabla', unicode: '∇', description: 'Gradient', category: 'operator' },
  { name: 'div', latex: '\\nabla \\cdot', unicode: '∇⋅', description: 'Divergence', category: 'operator' },
  { name: 'curl', latex: '\\nabla \\times', unicode: '∇×', description: 'Curl', category: 'operator' },
  { name: 'laplacian', latex: '\\nabla^2', unicode: '∇²', description: 'Laplacian', category: 'operator' },
  { name: 'integral', latex: '\\int', unicode: '∫', description: 'Integral', category: 'operator' },
  { name: 'oint', latex: '\\oint', unicode: '∮', description: 'Contour integral', category: 'operator' },
  { name: 'iint', latex: '\\iint', unicode: '∬', description: 'Double integral', category: 'operator' },
  
  // Advanced Functions (15)
  { name: 'Gamma', latex: '\\Gamma', unicode: 'Γ', description: 'Gamma function', category: 'function' },
  { name: 'zeta', latex: '\\zeta', unicode: 'ζ', description: 'Riemann zeta', category: 'function' },
  { name: 'erf', latex: '\\text{erf}', unicode: 'erf', description: 'Error function', category: 'function' },
  { name: 'BesselJ', latex: 'J_n', unicode: 'Jₙ', description: 'Bessel function J', category: 'function' },
  { name: 'BesselY', latex: 'Y_n', unicode: 'Yₙ', description: 'Bessel function Y', category: 'function' },
  { name: 'Hermite', latex: 'H_n', unicode: 'Hₙ', description: 'Hermite polynomial', category: 'function' },
  { name: 'Legendre', latex: 'P_n', unicode: 'Pₙ', description: 'Legendre polynomial', category: 'function' },
  { name: 'Laguerre', latex: 'L_n', unicode: 'Lₙ', description: 'Laguerre polynomial', category: 'function' },
  { name: 'Chebyshev', latex: 'T_n', unicode: 'Tₙ', description: 'Chebyshev polynomial', category: 'function' },
  { name: 'hypergeom', latex: '{}_2F_1', unicode: '₂F₁', description: 'Hypergeometric', category: 'function' },
  { name: 'Ai', latex: '\\text{Ai}', unicode: 'Ai', description: 'Airy function Ai', category: 'function' },
  { name: 'Bi', latex: '\\text{Bi}', unicode: 'Bi', description: 'Airy function Bi', category: 'function' },
  { name: 'theta', latex: '\\vartheta', unicode: 'ϑ', description: 'Jacobi theta', category: 'function' },
  { name: 'Weierstrass', latex: '\\wp', unicode: '℘', description: 'Weierstrass p', category: 'function' },
  { name: 'sigma', latex: '\\sigma', unicode: 'σ', description: 'Weierstrass sigma', category: 'function' },
  
  // Quantum Mechanics (10)
  { name: 'hbar', latex: '\\hbar', unicode: 'ℏ', description: 'Reduced Planck', category: 'constant', value: 1.054571817e-34 },
  { name: 'bra', latex: '\\langle', unicode: '⟨', description: 'Bra', category: 'operator' },
  { name: 'ket', latex: '\\rangle', unicode: '⟩', description: 'Ket', category: 'operator' },
  { name: 'braket', latex: '\\langle | \\rangle', unicode: '⟨|⟩', description: 'Braket', category: 'operator' },
  { name: 'otimes', latex: '\\otimes', unicode: '⊗', description: 'Tensor product', category: 'operator' },
  { name: 'oplus', latex: '\\oplus', unicode: '⊕', description: 'Direct sum', category: 'operator' },
  { name: 'dagger', latex: '\\dagger', unicode: '†', description: 'Hermitian conjugate', category: 'operator' },
  { name: 'tr', latex: '\\text{tr}', unicode: 'tr', description: 'Trace', category: 'function' },
  { name: 'det', latex: '\\det', unicode: 'det', description: 'Determinant', category: 'function' },
  { name: 'dim', latex: '\\dim', unicode: 'dim', description: 'Dimension', category: 'function' },
  
  // Topology/Geometry (10)
  { name: 'homeo', latex: '\\cong', unicode: '≅', description: 'Homeomorphic', category: 'relation' },
  { name: 'homotopy', latex: '\\simeq', unicode: '≃', description: 'Homotopy equivalent', category: 'relation' },
  { name: 'pi1', latex: '\\pi_1', unicode: 'π₁', description: 'Fundamental group', category: 'function' },
  { name: 'Hn', latex: 'H_n', unicode: 'Hₙ', description: 'Homology group', category: 'function' },
  { name: 'chi', latex: '\\chi', unicode: 'χ', description: 'Euler characteristic', category: 'function' },
  { name: 'torus', latex: '\\mathbb{T}', unicode: '𝕋', description: 'Torus', category: 'constant' },
  { name: 'sphere', latex: '\\mathbb{S}', unicode: '𝕊', description: 'Sphere', category: 'constant' },
  { name: 'RPn', latex: '\\mathbb{RP}^n', unicode: 'ℝPⁿ', description: 'Real projective', category: 'constant' },
  { name: 'CPn', latex: '\\mathbb{CP}^n', unicode: 'ℂPⁿ', description: 'Complex projective', category: 'constant' },
  { name: 'bundle', latex: '\\to', unicode: '→', description: 'Bundle map', category: 'operator' },
  
  // Category Theory (10)
  { name: 'hom', latex: '\\text{Hom}', unicode: 'Hom', description: 'Hom-set', category: 'function' },
  { name: 'ob', latex: '\\text{Ob}', unicode: 'Ob', description: 'Objects', category: 'function' },
  { name: 'mor', latex: '\\text{Mor}', unicode: 'Mor', description: 'Morphisms', category: 'function' },
  { name: 'id', latex: '\\text{id}', unicode: 'id', description: 'Identity', category: 'function' },
  { name: 'functor', latex: 'F', unicode: 'F', description: 'Functor', category: 'variable' },
  { name: 'natural', latex: '\\Rightarrow', unicode: '⇒', description: 'Natural transformation', category: 'operator' },
  { name: 'limit', latex: '\\varprojlim', unicode: 'lim', description: 'Limit', category: 'function' },
  { name: 'colimit', latex: '\\varinjlim', unicode: 'colim', description: 'Colimit', category: 'function' },
  { name: 'adjunction', latex: '\\dashv', unicode: '⊣', description: 'Adjunction', category: 'relation' },
  { name: 'unit', latex: '\\eta', unicode: 'η', description: 'Unit', category: 'variable' },
  
  // Analysis (10)
  { name: 'sup', latex: '\\sup', unicode: 'sup', description: 'Supremum', category: 'function' },
  { name: 'inf', latex: '\\inf', unicode: 'inf', description: 'Infimum', category: 'function' },
  { name: 'limsup', latex: '\\limsup', unicode: 'lim sup', description: 'Limit superior', category: 'function' },
  { name: 'liminf', latex: '\\liminf', unicode: 'lim inf', description: 'Limit inferior', category: 'function' },
  { name: 'ess sup', latex: '\\text{ess sup}', unicode: 'ess sup', description: 'Essential supremum', category: 'function' },
  { name: 'L2', latex: 'L^2', unicode: 'L²', description: 'L2 space', category: 'constant' },
  { name: 'Lp', latex: 'L^p', unicode: 'Lᵖ', description: 'Lp space', category: 'constant' },
  { name: 'C0', latex: 'C_0', unicode: 'C₀', description: 'Continuous vanishing', category: 'constant' },
  { name: 'Sobolev', latex: 'W^{k,p}', unicode: 'Wᵏᵖ', description: 'Sobolev space', category: 'constant' },
  { name: 'dist', latex: '\\text{dist}', unicode: 'dist', description: 'Distance', category: 'function' },
  
  // Algebra (10)
  { name: 'ker', latex: '\\ker', unicode: 'ker', description: 'Kernel', category: 'function' },
  { name: 'im', latex: '\\text{im}', unicode: 'im', description: 'Image', category: 'function' },
  { name: 'coker', latex: '\\text{coker}', unicode: 'coker', description: 'Cokernel', category: 'function' },
  { name: 'coim', latex: '\\text{coim}', unicode: 'coim', description: 'Coimage', category: 'function' },
  { name: 'Ann', latex: '\\text{Ann}', unicode: 'Ann', description: 'Annihilator', category: 'function' },
  { name: 'Rad', latex: '\\text{Rad}', unicode: 'Rad', description: 'Jacobson radical', category: 'function' },
  { name: 'Spec', latex: '\\text{Spec}', unicode: 'Spec', description: 'Spectrum', category: 'function' },
  { name: 'Max', latex: '\\text{Max}', unicode: 'Max', description: 'Max spectrum', category: 'function' },
  { name: 'Proj', latex: '\\text{Proj}', unicode: 'Proj', description: 'Proj construction', category: 'function' },
  { name: 'Tor', latex: '\\text{Tor}', unicode: 'Tor', description: 'Tor functor', category: 'function' },
  { name: 'Ext', latex: '\\text{Ext}', unicode: 'Ext', description: 'Ext functor', category: 'function' },
];

// Create lookup maps
export const SYMBOLS_BY_NAME = new Map<string, MathSymbol>();
export const SYMBOLS_BY_CATEGORY = new Map<string, MathSymbol[]>();

for (const sym of MATH_SYMBOLS) {
  SYMBOLS_BY_NAME.set(sym.name, sym);
  const cat = SYMBOLS_BY_CATEGORY.get(sym.category) || [];
  cat.push(sym);
  SYMBOLS_BY_CATEGORY.set(sym.category, cat);
}

// ============================================
// Symbolic Expression Types
// ============================================

export type ExprType = 
  | 'number' | 'symbol' | 'variable' | 'constant'
  | 'add' | 'sub' | 'mul' | 'div' | 'pow'
  | 'sin' | 'cos' | 'tan' | 'exp' | 'ln' | 'sqrt'
  | 'derivative' | 'integral' | 'limit' | 'sum'
  | 'gradient' | 'divergence' | 'curl' | 'laplacian';

export interface SymbolicExpr {
  type: ExprType;
  value?: number;
  name?: string;
  symbol?: MathSymbol;
  left?: SymbolicExpr;
  right?: SymbolicExpr;
  args?: SymbolicExpr[];
  latex?: string;
  primeVector?: number[];
}

// ============================================
// Symbolic Expression Builder
// ============================================

export function num(n: number): SymbolicExpr {
  return {
    type: 'number',
    value: n,
    latex: n.toString(),
    primeVector: toPrimeVector(Math.abs(Math.floor(n))),
  };
}

export function sym(name: string): SymbolicExpr {
  const symbol = SYMBOLS_BY_NAME.get(name);
  return {
    type: symbol?.category === 'constant' ? 'constant' : 'symbol',
    name,
    symbol,
    latex: symbol?.latex || name,
    value: symbol?.value,
  };
}

export function add(a: SymbolicExpr, b: SymbolicExpr): SymbolicExpr {
  return {
    type: 'add',
    left: a,
    right: b,
    latex: `${a.latex} + ${b.latex}`,
  };
}

export function sub(a: SymbolicExpr, b: SymbolicExpr): SymbolicExpr {
  return {
    type: 'sub',
    left: a,
    right: b,
    latex: `${a.latex} - ${b.latex}`,
  };
}

export function mul(a: SymbolicExpr, b: SymbolicExpr): SymbolicExpr {
  return {
    type: 'mul',
    left: a,
    right: b,
    latex: `${a.latex} \\cdot ${b.latex}`,
  };
}

export function div(a: SymbolicExpr, b: SymbolicExpr): SymbolicExpr {
  return {
    type: 'div',
    left: a,
    right: b,
    latex: `\\frac{${a.latex}}{${b.latex}}`,
  };
}

export function pow(base: SymbolicExpr, exp: SymbolicExpr): SymbolicExpr {
  return {
    type: 'pow',
    left: base,
    right: exp,
    latex: `{${base.latex}}^{${exp.latex}}`,
  };
}

export function sin(x: SymbolicExpr): SymbolicExpr {
  return {
    type: 'sin',
    left: x,
    latex: `\\sin(${x.latex})`,
  };
}

export function cos(x: SymbolicExpr): SymbolicExpr {
  return {
    type: 'cos',
    left: x,
    latex: `\\cos(${x.latex})`,
  };
}

export function exp(x: SymbolicExpr): SymbolicExpr {
  return {
    type: 'exp',
    left: x,
    latex: `\\exp(${x.latex})`,
  };
}

export function ln(x: SymbolicExpr): SymbolicExpr {
  return {
    type: 'ln',
    left: x,
    latex: `\\ln(${x.latex})`,
  };
}

export function sqrt(x: SymbolicExpr): SymbolicExpr {
  return {
    type: 'sqrt',
    left: x,
    latex: `\\sqrt{${x.latex}}`,
  };
}

// Differential operators
export function derivative(f: SymbolicExpr, varName: string): SymbolicExpr {
  return {
    type: 'derivative',
    left: f,
    name: varName,
    latex: `\\frac{\\partial ${f.latex}}{\\partial ${varName}}`,
  };
}

export function gradient(f: SymbolicExpr): SymbolicExpr {
  return {
    type: 'derivative',
    left: f,
    latex: `\\nabla ${f.latex}`,
  };
}

export function divergence(f: SymbolicExpr): SymbolicExpr {
  return {
    type: 'derivative',
    left: f,
    latex: `\\nabla \\cdot ${f.latex}`,
  };
}

export function curl(f: SymbolicExpr): SymbolicExpr {
  return {
    type: 'derivative',
    left: f,
    latex: `\\nabla \\times ${f.latex}`,
  };
}

export function laplacian(f: SymbolicExpr): SymbolicExpr {
  return {
    type: 'derivative',
    left: f,
    latex: `\\nabla^2 ${f.latex}`,
  };
}

export function integral(f: SymbolicExpr, varName: string, lower?: number, upper?: number): SymbolicExpr {
  const bounds = lower !== undefined && upper !== undefined 
    ? `_{${lower}}^{${upper}}` 
    : '';
  return {
    type: 'integral',
    left: f,
    name: varName,
    latex: `\\int${bounds} ${f.latex} \\, d${varName}`,
  };
}

// ============================================
// Expression Evaluation
// ============================================

export function evaluate(expr: SymbolicExpr, context: Record<string, number> = {}): number {
  switch (expr.type) {
    case 'number':
      return expr.value || 0;
    case 'constant':
      return expr.value || 0;
    case 'symbol':
    case 'variable':
      return context[expr.name || ''] ?? expr.value ?? 0;
    case 'add':
      return evaluate(expr.left!, context) + evaluate(expr.right!, context);
    case 'sub':
      return evaluate(expr.left!, context) - evaluate(expr.right!, context);
    case 'mul':
      return evaluate(expr.left!, context) * evaluate(expr.right!, context);
    case 'div':
      return evaluate(expr.left!, context) / evaluate(expr.right!, context);
    case 'pow':
      return Math.pow(evaluate(expr.left!, context), evaluate(expr.right!, context));
    case 'sin':
      return Math.sin(evaluate(expr.left!, context));
    case 'cos':
      return Math.cos(evaluate(expr.left!, context));
    case 'tan':
      return Math.tan(evaluate(expr.left!, context));
    case 'exp':
      return Math.exp(evaluate(expr.left!, context));
    case 'ln':
      return Math.log(evaluate(expr.left!, context));
    case 'sqrt':
      return Math.sqrt(evaluate(expr.left!, context));
    default:
      return 0;
  }
}

// ============================================
// Expression Simplification
// ============================================

export function simplify(expr: SymbolicExpr): SymbolicExpr {
  // Simplify children first
  if (expr.left) expr = { ...expr, left: simplify(expr.left) };
  if (expr.right) expr = { ...expr, right: simplify(expr.right) };
  
  // Number + Number = Number
  if (expr.type === 'add' && expr.left?.type === 'number' && expr.right?.type === 'number') {
    return num((expr.left.value || 0) + (expr.right.value || 0));
  }
  
  // Number * 1 = Number
  if (expr.type === 'mul' && expr.right?.type === 'number' && expr.right.value === 1) {
    return expr.left!;
  }
  
  // Number * 0 = 0
  if (expr.type === 'mul' && (expr.left?.value === 0 || expr.right?.value === 0)) {
    return num(0);
  }
  
  // x - x = 0
  if (expr.type === 'sub' && expr.left?.name === expr.right?.name) {
    return num(0);
  }
  
  // x / x = 1 (for x != 0)
  if (expr.type === 'div' && expr.left?.name === expr.right?.name) {
    return num(1);
  }
  
  // x^0 = 1
  if (expr.type === 'pow' && expr.right?.value === 0) {
    return num(1);
  }
  
  // x^1 = x
  if (expr.type === 'pow' && expr.right?.value === 1) {
    return expr.left!;
  }
  
  return expr;
}

// ============================================
// Prime Domain Symbolic Link
// ============================================

export interface PrimeSymbolicLink {
  expr: SymbolicExpr;
  primeVector: number[];
  logDomainValue: number;
  analogVoltage: number;
}

export function linkToPrimeDomain(expr: SymbolicExpr): PrimeSymbolicLink {
  const value = evaluate(expr);
  const primeVec = toPrimeVector(Math.abs(Math.floor(value)));
  const logValue = Math.log(Math.abs(value) || 1);
  const voltage = value * 0.5; // Vunit = 0.5
  
  return {
    expr,
    primeVector: primeVec,
    logDomainValue: logValue,
    analogVoltage: voltage,
  };
}

// ============================================
// Expression Parser
// ============================================

export function parseExpression(input: string): SymbolicExpr | null {
  input = input.trim().toLowerCase();
  
  // Try to parse as number
  const numMatch = input.match(/^-?\d+(\.\d+)?$/);
  if (numMatch) {
    return num(parseFloat(input));
  }
  
  // Try to parse as symbol
  if (SYMBOLS_BY_NAME.has(input)) {
    return sym(input);
  }
  
  // Simple binary operations
  const addMatch = input.match(/^(.+)\s*\+\s*(.+)$/);
  if (addMatch) {
    const left = parseExpression(addMatch[1]);
    const right = parseExpression(addMatch[2]);
    if (left && right) return add(left, right);
  }
  
  const mulMatch = input.match(/^(.+)\s*\*\s*(.+)$/);
  if (mulMatch) {
    const left = parseExpression(mulMatch[1]);
    const right = parseExpression(mulMatch[2]);
    if (left && right) return mul(left, right);
  }
  
  // Functions
  const funcMatch = input.match(/^(sin|cos|tan|exp|ln|sqrt|derivative|gradient|div|curl|laplacian|integral)\s*\(\s*(.+)\s*\)$/);
  if (funcMatch) {
    const arg = parseExpression(funcMatch[2]);
    if (arg) {
      switch (funcMatch[1]) {
        case 'sin': return sin(arg);
        case 'cos': return cos(arg);
        case 'exp': return exp(arg);
        case 'ln': return ln(arg);
        case 'sqrt': return sqrt(arg);
        case 'derivative': return derivative(arg, 'x');
        case 'gradient': return gradient(arg);
        case 'div': return divergence(arg);
        case 'curl': return curl(arg);
        case 'laplacian': return laplacian(arg);
        case 'integral': return integral(arg, 'x');
      }
    }
  }
  
  return null;
}

// ============================================
// USABLE OPERATOR SYSTEM
// Makes operators actually executable
// ============================================

export interface OperatorResult {
  symbol: string;
  inputs: number[];
  output: number;
  latex: string;
  description: string;
  poleUsed: number;
}

// Executable operator functions
export const USABLE_OPERATORS: Record<string, (inputs: number[]) => number> = {
  // Basic arithmetic
  '+': (inputs) => inputs[0] + inputs[1],
  '-': (inputs) => inputs[0] - inputs[1],
  '*': (inputs) => inputs[0] * inputs[1],
  '/': (inputs) => inputs[0] / inputs[1],
  '%': (inputs) => inputs[0] % inputs[1],
  '^': (inputs) => Math.pow(inputs[0], inputs[1]),
  
  // Trigonometric
  'sin': (inputs) => Math.sin(inputs[0]),
  'cos': (inputs) => Math.cos(inputs[0]),
  'tan': (inputs) => Math.tan(inputs[0]),
  'asin': (inputs) => Math.asin(inputs[0]),
  'acos': (inputs) => Math.acos(inputs[0]),
  'atan': (inputs) => Math.atan(inputs[0]),
  'sinh': (inputs) => Math.sinh(inputs[0]),
  'cosh': (inputs) => Math.cosh(inputs[0]),
  'tanh': (inputs) => Math.tanh(inputs[0]),
  
  // Exponential/Logarithmic
  'exp': (inputs) => Math.exp(inputs[0]),
  'ln': (inputs) => Math.log(inputs[0]),
  'log': (inputs) => Math.log10(inputs[0]),
  'log2': (inputs) => Math.log2(inputs[0]),
  'sqrt': (inputs) => Math.sqrt(inputs[0]),
  'cbrt': (inputs) => Math.cbrt(inputs[0]),
  
  // Differential operators (numerical approximations)
  'derivative': (inputs) => {
    // f'(x) ≈ (f(x+h) - f(x-h)) / 2h
    const h = 0.001;
    const x = inputs[0];
    const f = (t: number) => t * t; // Default: derivative of x²
    return (f(x + h) - f(x - h)) / (2 * h);
  },
  'gradient': (inputs) => {
    // Gradient magnitude for 2D
    const dx = inputs[0] || 0;
    const dy = inputs[1] || 0;
    return Math.sqrt(dx * dx + dy * dy);
  },
  'divergence': (inputs) => {
    // div F = ∂Fx/∂x + ∂Fy/∂y
    return (inputs[0] || 0) + (inputs[1] || 0);
  },
  'curl': (inputs) => {
    // curl F = ∂Fy/∂x - ∂Fx/∂y (2D scalar)
    return (inputs[1] || 0) - (inputs[0] || 0);
  },
  'laplacian': (inputs) => {
    // ∇²f ≈ f(x+h) + f(x-h) - 2f(x) for 1D
    return (inputs[0] || 0) + (inputs[1] || 0) - 2 * (inputs[2] || 0);
  },
  
  // Special functions
  'Gamma': (inputs) => {
    // Lanczos approximation for Gamma function
    const x = inputs[0];
    if (x < 0.5) return Math.PI / (Math.sin(Math.PI * x) * USABLE_OPERATORS['Gamma']([1 - x]));
    const g = 7;
    const p = [0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313, -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7];
    let a = p[0];
    for (let i = 1; i < g + 2; i++) a += p[i] / (x + i);
    const t = x + g + 0.5;
    return Math.sqrt(2 * Math.PI) * Math.pow(t, x + 0.5) * Math.exp(-t) * a;
  },
  'erf': (inputs) => {
    // Error function approximation
    const x = inputs[0];
    const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
    const a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
    const sign = x < 0 ? -1 : 1;
    const t = 1 / (1 + p * Math.abs(x));
    return sign * (1 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x));
  },
  'BesselJ': (inputs) => {
    // Bessel J0 approximation
    const x = inputs[0];
    if (x < 3) {
      return 1 - x * x / 4 + x * x * x * x / 64 - x * x * x * x * x * x / 2304;
    }
    return Math.sqrt(2 / (Math.PI * x)) * Math.cos(x - Math.PI / 4);
  },
  
  // Advanced functions
  'floor': (inputs) => Math.floor(inputs[0]),
  'ceil': (inputs) => Math.ceil(inputs[0]),
  'abs': (inputs) => Math.abs(inputs[0]),
  'min': (inputs) => Math.min(...inputs),
  'max': (inputs) => Math.max(...inputs),
  'gcd': (inputs) => {
    const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
    return gcd(Math.abs(inputs[0]), Math.abs(inputs[1]));
  },
  
  // PPU-specific
  'prime': (inputs) => {
    // Convert to nearest prime
    const n = Math.floor(Math.abs(inputs[0]));
    const isPrime = (x: number) => {
      if (x < 2) return false;
      for (let i = 2; i <= Math.sqrt(x); i++) if (x % i === 0) return false;
      return true;
    };
    let p = n;
    while (!isPrime(p)) p++;
    return p;
  },
  'logmul': (inputs) => {
    // Log-domain multiplication: log(a) + log(b) = log(a*b)
    return Math.exp(Math.log(Math.abs(inputs[0]) || 1) + Math.log(Math.abs(inputs[1]) || 1));
  },
  'baz': (inputs) => {
    // BAZ normalization: z / |z| for complex-like normalization
    const x = inputs[0];
    return x / (Math.abs(x) || 1);
  },
};

// Operator pole assignments (which PPU pole handles which operator)
export const OPERATOR_POLES: Record<string, number> = {
  '+': 1, '-': 2, '*': 3, '/': 4, '%': 5,
  'sin': 0, 'cos': 1, 'tan': 2,
  'exp': 3, 'ln': 4, 'sqrt': 5,
  'derivative': 6, 'gradient': 7, 'divergence': 8, 'curl': 9, 'laplacian': 10,
  'Gamma': 0, 'erf': 1, 'BesselJ': 2,
  'prime': 7, 'logmul': 8, 'baz': 9,
};

/**
 * Execute an operator with given inputs
 */
export function executeOperator(symbol: string, inputs: number[]): OperatorResult {
  const fn = USABLE_OPERATORS[symbol];
  const output = fn ? fn(inputs) : NaN;
  const mathSym = SYMBOLS_BY_NAME.get(symbol);
  
  return {
    symbol,
    inputs,
    output,
    latex: mathSym?.latex || symbol,
    description: mathSym?.description || `Operator ${symbol}`,
    poleUsed: OPERATOR_POLES[symbol] ?? 0,
  };
}

/**
 * Parse and execute a mathematical expression
 */
export function executeExpression(expr: string): OperatorResult | null {
  expr = expr.trim();
  
  // Try binary operations
  const binOpMatch = expr.match(/^(.+?)\s*([+\-*/%^])\s*(.+)$/);
  if (binOpMatch) {
    const left = parseFloat(binOpMatch[1].trim());
    const op = binOpMatch[2];
    const right = parseFloat(binOpMatch[3].trim());
    if (!isNaN(left) && !isNaN(right)) {
      return executeOperator(op, [left, right]);
    }
  }
  
  // Try function calls
  const funcMatch = expr.match(/^(\w+)\s*\(\s*([^)]+)\s*\)$/);
  if (funcMatch) {
    const funcName = funcMatch[1];
    const args = funcMatch[2].split(',').map(s => parseFloat(s.trim()));
    if (args.every(n => !isNaN(n))) {
      return executeOperator(funcName, args);
    }
  }
  
  // Try single number
  const num = parseFloat(expr);
  if (!isNaN(num)) {
    return {
      symbol: 'identity',
      inputs: [num],
      output: num,
      latex: num.toString(),
      description: 'Identity',
      poleUsed: 0,
    };
  }
  
  return null;
}

/**
 * Get all available operators grouped by category
 */
export function getOperatorsByCategory(): Record<string, string[]> {
  return {
    'Arithmetic': ['+', '-', '*', '/', '%', '^'],
    'Trigonometric': ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'sinh', 'cosh', 'tanh'],
    'Exponential': ['exp', 'ln', 'log', 'log2', 'sqrt', 'cbrt'],
    'Differential': ['derivative', 'gradient', 'divergence', 'curl', 'laplacian'],
    'Special': ['Gamma', 'erf', 'BesselJ'],
    'Utility': ['floor', 'ceil', 'abs', 'min', 'max', 'gcd'],
    'PPU': ['prime', 'logmul', 'baz'],
  };
}

// ============================================
// Symbolic Calculator Interface
// ============================================

export interface CalculatorInput {
  expression: string;
  variables?: Record<string, number>;
}

export interface CalculatorOutput {
  input: string;
  result: number;
  steps: OperatorResult[];
  latex: string;
  polesUsed: number[];
  success: boolean;
  error?: string;
}

/**
 * Main calculator function - evaluates symbolic expressions
 */
export function calculate(input: CalculatorInput): CalculatorOutput {
  try {
    const steps: OperatorResult[] = [];
    const polesUsed: number[] = [];
    
    // Parse the expression
    const expr = parseExpression(input.expression);
    if (!expr) {
      // Try direct execution
      const direct = executeExpression(input.expression);
      if (direct) {
        return {
          input: input.expression,
          result: direct.output,
          steps: [direct],
          latex: direct.latex,
          polesUsed: [direct.poleUsed],
          success: true,
        };
      }
      throw new Error('Failed to parse expression');
    }
    
    // Evaluate with variables
    const result = evaluate(expr, input.variables || {});
    
    // Collect poles used
    collectPoles(expr, polesUsed);
    
    return {
      input: input.expression,
      result,
      steps,
      latex: expr.latex || input.expression,
      polesUsed: [...new Set(polesUsed)],
      success: true,
    };
  } catch (e) {
    return {
      input: input.expression,
      result: NaN,
      steps: [],
      latex: '',
      polesUsed: [],
      success: false,
      error: e instanceof Error ? e.message : 'Unknown error',
    };
  }
}

function collectPoles(expr: SymbolicExpr, poles: number[]): void {
  if (expr.symbol) {
    const pole = OPERATOR_POLES[expr.symbol.name];
    if (pole !== undefined) poles.push(pole);
  }
  if (expr.left) collectPoles(expr.left, poles);
  if (expr.right) collectPoles(expr.right, poles);
  if (expr.args) expr.args.forEach(arg => collectPoles(arg, poles));
}
