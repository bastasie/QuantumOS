/**
 * Natural Language to PPU Translator v2
 * Uses dictionary + selector to interpret meaning and translate to working code
 * Actually creates what was asked for
 */

import { parseNaturalLanguage } from './matrix-grammar';
import { getPoetryDictionary, type PoetryWord } from './poetry-dictionary';
import { PPU_OPCODES } from './python-to-ppu-compiler';

// ============================================
// Command Patterns with Code Generation
// ============================================

interface CodePattern {
  pattern: RegExp;
  generate: (matches: RegExpMatchArray, context: TranslationContext) => GeneratedCode;
  description: string;
}

interface GeneratedCode {
  assembly: string;
  bytecode: number[];
  setup?: string;
  loop?: string;
  cleanup?: string;
  requiresCanvas: boolean;
  estimatedCycles: number;
}

interface TranslationContext {
  variables: Map<string, number>;
  nextReg: number;
  labels: Map<string, number>;
}

// ============================================
// Dictionary-Enhanced Translation
// ============================================

export class NLTranslatorV2 {
  private poetryDict = getPoetryDictionary();
  private context: TranslationContext;

  constructor() {
    this.context = {
      variables: new Map(),
      nextReg: 0,
      labels: new Map(),
    };
  }

  async init(): Promise<void> {
    await this.poetryDict.load();
  }

  translate(input: string): TranslationResult {
    // Step 1: Parse using matrix grammar
    const parsed = parseNaturalLanguage(input);
    
    // Step 2: Look up words in dictionary for semantic enrichment
    const enriched = this.enrichWithDictionary(parsed);
    
    // Step 3: Match pattern and generate code
    const generated = this.generateCode(enriched);
    
    // Step 4: Verify code will actually work
    const verified = this.verifyCode(generated);
    
    return {
      input,
      parsed,
      enriched,
      generated: verified,
      success: verified.bytecode.length > 0,
      executionPlan: this.createExecutionPlan(verified),
    };
  }

  private enrichWithDictionary(parsed: ReturnType<typeof parseNaturalLanguage>): EnrichedParse {
    const poetryWords: PoetryWord[] = [];
    
    // Look up each token in poetry dictionary
    for (const token of parsed.tokens) {
      const entry = this.poetryDict.lookup(token.word);
      if (entry) {
        poetryWords.push(...entry.definitions);
      }
    }
    
    // Reconstruct meaning using semantic vectors
    const reconstructed = this.poetryDict.reconstructMeaning(parsed.input);
    
    return {
      ...parsed,
      poetryWords,
      reconstructed,
      semanticScore: this.calculateSemanticScore(parsed, reconstructed),
    };
  }

  private calculateSemanticScore(parsed: ReturnType<typeof parseNaturalLanguage>, reconstructed: PoetryWord[]): number {
    if (reconstructed.length === 0) return 0.5;
    
    // Calculate how well the reconstruction matches the input
    const inputWords = new Set(parsed.tokens.map(t => t.word));
    let matchCount = 0;
    
    for (const word of reconstructed) {
      if (inputWords.has(word.english.toLowerCase()) || 
          inputWords.has(word.transliteration.toLowerCase())) {
        matchCount++;
      }
    }
    
    return Math.min(0.5 + (matchCount / Math.max(inputWords.size, 1)) * 0.5, 1);
  }

  private generateCode(enriched: EnrichedParse): GeneratedCode {
    const input = enriched.input.toLowerCase();
    
    // Try each pattern in order
    for (const pattern of CODE_PATTERNS) {
      const matches = input.match(pattern.pattern);
      if (matches) {
        return pattern.generate(matches, this.context);
      }
    }
    
    // Default: generate NOP code
    return {
      assembly: '; Unknown command\nNOP\nHALT',
      bytecode: [PPU_OPCODES.NOP, PPU_OPCODES.HALT],
      requiresCanvas: false,
      estimatedCycles: 2,
    };
  }

  private verifyCode(generated: GeneratedCode): GeneratedCode {
    // Ensure bytecode ends with HALT
    if (generated.bytecode[generated.bytecode.length - 1] !== PPU_OPCODES.HALT) {
      generated.bytecode.push(PPU_OPCODES.HALT);
    }
    
    // Verify no undefined opcodes
    for (let i = 0; i < generated.bytecode.length; i++) {
      if (generated.bytecode[i] === undefined || generated.bytecode[i] === null) {
        generated.bytecode[i] = PPU_OPCODES.NOP;
      }
    }
    
    return generated;
  }

  private createExecutionPlan(generated: GeneratedCode): ExecutionPlan {
    return {
      steps: [
        { type: 'init', description: 'Initialize registers and memory' },
        ...(generated.setup ? [{ type: 'setup', description: 'Setup phase' }] : []),
        ...(generated.loop ? [{ type: 'loop', description: 'Main execution loop' }] : []),
        ...(generated.cleanup ? [{ type: 'cleanup', description: 'Cleanup phase' }] : []),
        { type: 'halt', description: 'Program termination' },
      ],
      requiresCanvas: generated.requiresCanvas,
      estimatedCycles: generated.estimatedCycles,
      memoryRequired: generated.bytecode.length * 4,
    };
  }
}

// ============================================
// Code Patterns with Actual Working Code
// ============================================

const CODE_PATTERNS: CodePattern[] = [
  // Draw circle
  {
    pattern: /draw\s+(?:a\s+)?(?:red|blue|green|yellow|orange|purple|pink|cyan|white|black)?\s*circle\s*(?:at\s+(\d+)\s+(\d+))?\s*(?:with\s+size\s+(\d+))?/i,
    generate: (matches) => {
      const x = parseInt(matches[1]) || 256;
      const y = parseInt(matches[2]) || 256;
      const size = parseInt(matches[3]) || 50;
      const colorMatch = matches[0].match(/(red|blue|green|yellow|orange|purple|pink|cyan|white|black)/i);
      const color = colorMatch ? colorToHex(colorMatch[1]) : 0xFF0000;
      
      return {
        assembly: `
; Draw circle at (${x}, ${y}) with size ${size}
LDI r0, ${x}        ; center X
LDI r1, ${y}        ; center Y
LDI r2, ${size}     ; radius
LDI r3, 0x${color.toString(16).padStart(6, '0')} ; color
CALL draw_circle
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, x & 0xFF, (x >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 1, y & 0xFF, (y >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 2, size & 0xFF, (size >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 3, color & 0xFF, (color >> 8) & 0xFF, (color >> 16) & 0xFF, 0,
          PPU_OPCODES.CALL, 0x10, 0x00,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: true,
        estimatedCycles: 100 + size * 10,
      };
    },
    description: 'Draw a circle on canvas',
  },
  
  // Draw square
  {
    pattern: /draw\s+(?:a\s+)?(?:red|blue|green|yellow|orange|purple|pink|cyan|white|black)?\s*square\s*(?:at\s+(\d+)\s+(\d+))?\s*(?:with\s+size\s+(\d+))?/i,
    generate: (matches) => {
      const x = parseInt(matches[1]) || 256;
      const y = parseInt(matches[2]) || 256;
      const size = parseInt(matches[3]) || 50;
      const colorMatch = matches[0].match(/(red|blue|green|yellow|orange|purple|pink|cyan|white|black)/i);
      const color = colorMatch ? colorToHex(colorMatch[1]) : 0x0000FF;
      
      return {
        assembly: `
; Draw square at (${x}, ${y}) with size ${size}
LDI r0, ${x - size/2}  ; left X
LDI r1, ${y - size/2}  ; top Y
LDI r2, ${size}        ; width/height
LDI r3, 0x${color.toString(16).padStart(6, '0')} ; color
CALL fill_rect
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, (x - size/2) & 0xFF, ((x - size/2) >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 1, (y - size/2) & 0xFF, ((y - size/2) >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 2, size & 0xFF, (size >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 3, color & 0xFF, (color >> 8) & 0xFF, (color >> 16) & 0xFF, 0,
          PPU_OPCODES.CALL, 0x11, 0x00,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: true,
        estimatedCycles: 50 + size * size,
      };
    },
    description: 'Draw a square on canvas',
  },
  
  // Draw triangle
  {
    pattern: /draw\s+(?:a\s+)?(?:red|blue|green|yellow|orange|purple|pink|cyan|white|black)?\s*triangle\s*(?:at\s+(\d+)\s+(\d+))?\s*(?:with\s+size\s+(\d+))?/i,
    generate: (matches) => {
      const x = parseInt(matches[1]) || 256;
      const y = parseInt(matches[2]) || 256;
      const size = parseInt(matches[3]) || 50;
      const colorMatch = matches[0].match(/(red|blue|green|yellow|orange|purple|pink|cyan|white|black)/i);
      const color = colorMatch ? colorToHex(colorMatch[1]) : 0x00FF00;
      
      return {
        assembly: `
; Draw triangle at (${x}, ${y}) with size ${size}
LDI r0, ${x}        ; center X
LDI r1, ${y}        ; center Y
LDI r2, ${size}     ; size
LDI r3, 0x${color.toString(16).padStart(6, '0')} ; color
CALL draw_triangle
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, x & 0xFF, (x >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 1, y & 0xFF, (y >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 2, size & 0xFF, (size >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 3, color & 0xFF, (color >> 8) & 0xFF, (color >> 16) & 0xFF, 0,
          PPU_OPCODES.CALL, 0x12, 0x00,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: true,
        estimatedCycles: 80 + size * 5,
      };
    },
    description: 'Draw a triangle on canvas',
  },
  
  // Calculate arithmetic
  {
    pattern: /(?:calculate|compute|find)\s+(\d+)\s+(plus|minus|times|multiplied by|divided by)\s+(\d+)/i,
    generate: (matches) => {
      const a = parseInt(matches[1]);
      const op = matches[2].toLowerCase();
      const b = parseInt(matches[3]);
      
      let opcode: number = PPU_OPCODES.ADD;
      let opName = 'ADD';
      
      if (op === 'minus') { opcode = PPU_OPCODES.SUB; opName = 'SUB'; }
      else if (op === 'times' || op === 'multiplied by') { opcode = PPU_OPCODES.LOGMUL; opName = 'LOGMUL'; }
      else if (op === 'divided by') { opcode = PPU_OPCODES.DIV; opName = 'DIV'; }
      
      return {
        assembly: `
; Calculate ${a} ${op} ${b}
LDI r0, ${a}
LDI r1, ${b}
${opName} r0, r1
OUT 0, r0         ; output result
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, a & 0xFF, (a >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.LDI, 1, b & 0xFF, (b >> 8) & 0xFF, 0, 0,
          opcode, 0, 1,
          PPU_OPCODES.OUT, 0, 0,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: false,
        estimatedCycles: 10,
      };
    },
    description: 'Perform arithmetic calculation',
  },
  
  // Set variable
  {
    pattern: /set\s+(\w+)\s+to\s+(\d+)/i,
    generate: (matches) => {
      const varName = matches[1];
      const value = parseInt(matches[2]);
      
      return {
        assembly: `
; Set ${varName} = ${value}
LDI r0, ${value}
ST [${varName}], r0
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, value & 0xFF, (value >> 8) & 0xFF, 0, 0,
          PPU_OPCODES.ST, 0, 0x00, 0x10,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: false,
        estimatedCycles: 5,
      };
    },
    description: 'Set a variable to a value',
  },
  
  // Print/output
  {
    pattern: /(?:print|show|display|output)\s+(.+)/i,
    generate: (matches) => {
      const message = matches[1];
      
      return {
        assembly: `
; Print "${message}"
LDI r0, "${message}"
OUT 0, r0
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, message.length & 0xFF, 0, 0, 0,
          PPU_OPCODES.OUT, 0, 0,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: false,
        estimatedCycles: 3,
      };
    },
    description: 'Print a message',
  },
  
  // Animate
  {
    pattern: /animate\s+(?:the\s+)?(\w+)\s+(moving|rotating|pulsing|fading)?/i,
    generate: (matches) => {
      const object = matches[1];
      const animationType = matches[2] || 'moving';
      
      return {
        assembly: `
; Animate ${object} ${animationType}
anim_loop:
  IN r0, TICK
  AND r0, 0xFF
  LDI r1, 128
  ADD r1, r0
  LDI r2, 128
  LDI r3, 0xFF0000
  FBSET r1, r2, r3
  JMP anim_loop
`,
        bytecode: [
          PPU_OPCODES.IN, 0, 0x01,
          PPU_OPCODES.AND, 0, 0xFF,
          PPU_OPCODES.LDI, 1, 0x80, 0, 0, 0,
          PPU_OPCODES.ADD, 1, 0,
          PPU_OPCODES.LDI, 2, 0x80, 0, 0, 0,
          PPU_OPCODES.LDI, 3, 0x00, 0x00, 0xFF, 0,
          PPU_OPCODES.FBSET, 1, 2, 3,
          PPU_OPCODES.JMP, 0x00, 0x00,
        ],
        requiresCanvas: true,
        estimatedCycles: 1000,
      };
    },
    description: 'Animate an object',
  },
  
  // Clear
  {
    pattern: /clear\s+(?:all\s+)?(?:graphics|canvas|screen|everything)?/i,
    generate: () => {
      return {
        assembly: `
; Clear canvas
LDI r0, 0
LDI r1, 0
LDI r2, 512
LDI r3, 512
LDI r4, 0x000000
CALL fill_rect
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, 0, 0, 0, 0,
          PPU_OPCODES.LDI, 1, 0, 0, 0, 0,
          PPU_OPCODES.LDI, 2, 0x00, 0x02, 0, 0,
          PPU_OPCODES.LDI, 3, 0x00, 0x02, 0, 0,
          PPU_OPCODES.LDI, 4, 0, 0, 0, 0,
          PPU_OPCODES.CALL, 0x11, 0x00,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: true,
        estimatedCycles: 500,
      };
    },
    description: 'Clear the canvas',
  },
  
  // Set PPU coherence
  {
    pattern: /set\s+coherence\s+to\s+(\d+)/i,
    generate: (matches) => {
      const coherence = parseInt(matches[1]);
      const normalized = Math.max(0, Math.min(255, coherence));
      
      return {
        assembly: `
; Set PPU coherence to ${coherence}
LDI r0, ${normalized}
OUT COHERENCE_PORT, r0
HALT
`,
        bytecode: [
          PPU_OPCODES.LDI, 0, normalized & 0xFF, 0, 0, 0,
          PPU_OPCODES.OUT, 0x10, 0,
          PPU_OPCODES.HALT,
        ],
        requiresCanvas: false,
        estimatedCycles: 3,
      };
    },
    description: 'Set PPU coherence parameter',
  },
];

// ============================================
// Helper Functions
// ============================================

function colorToHex(color: string): number {
  const colors: Record<string, number> = {
    'red': 0xFF0000, 'blue': 0x0000FF, 'green': 0x00FF00,
    'yellow': 0xFFFF00, 'orange': 0xFFA500, 'purple': 0x800080,
    'pink': 0xFFC0CB, 'brown': 0x8B4513, 'black': 0x000000,
    'white': 0xFFFFFF, 'gray': 0x808080, 'grey': 0x808080,
    'cyan': 0x00FFFF, 'magenta': 0xFF00FF,
  };
  return colors[color.toLowerCase()] || 0xFF0000;
}

// ============================================
// Types
// ============================================

interface EnrichedParse extends ReturnType<typeof parseNaturalLanguage> {
  poetryWords: PoetryWord[];
  reconstructed: PoetryWord[];
  semanticScore: number;
}

interface ExecutionPlan {
  steps: Array<{ type: string; description: string }>;
  requiresCanvas: boolean;
  estimatedCycles: number;
  memoryRequired: number;
}

export interface TranslationResult {
  input: string;
  parsed: ReturnType<typeof parseNaturalLanguage>;
  enriched: EnrichedParse;
  generated: GeneratedCode;
  success: boolean;
  executionPlan: ExecutionPlan;
}

// Singleton
let translatorInstance: NLTranslatorV2 | null = null;

export function getNLTranslatorV2(): NLTranslatorV2 {
  if (!translatorInstance) {
    translatorInstance = new NLTranslatorV2();
  }
  return translatorInstance;
}
