/**
 * Poetry Dictionary - CDN-based Arabic-English vocabulary
 * Uses mathematical reconstruction for meaning interpretation
 * Based on "Multisensory Glyph-Convolutional Theory" and poetry circle concepts
 */

// ============================================
// Dictionary Entry Types
// ============================================

export interface PoetryWord {
  arabic: string;
  transliteration: string;
  english: string;
  meaning: string;
  root: string; // Arabic triliteral root
  meter: string; // Associated poetic meter
  tribe: string; // Associated poetry tribe
  glyphCode: number; // Encoding for glyph-convolutional processing
  semanticVector: number[]; // Mathematical representation of meaning
}

export interface DictionaryEntry {
  word: string;
  definitions: PoetryWord[];
  frequency: number;
  category: 'noun' | 'verb' | 'adjective' | 'particle' | 'meter' | 'tribe';
}

// ============================================
// CDN Dictionary Loader
// ============================================

const DICTIONARY_CDN_URL = 'https://cdn.jsdelivr.net/gh/arabic-poetry/dictionary@main/';

export class PoetryDictionary {
  private cache: Map<string, DictionaryEntry> = new Map();
  private loaded: boolean = false;
  private onLoadCallbacks: (() => void)[] = [];

  async load(): Promise<void> {
    if (this.loaded) return;
    
    try {
      // Try to load from CDN
      const response = await fetch(`${DICTIONARY_CDN_URL}poetry-dictionary.json`);
      if (response.ok) {
        const data = await response.json();
        this.populateCache(data);
      }
    } catch (e) {
      console.log('CDN load failed, using built-in dictionary');
    }
    
    // Always populate with built-in as fallback
    this.populateBuiltIn();
    this.loaded = true;
    
    // Notify callbacks
    this.onLoadCallbacks.forEach(cb => cb());
  }

  private populateCache(data: Record<string, DictionaryEntry>): void {
    for (const [key, entry] of Object.entries(data)) {
      this.cache.set(key.toLowerCase(), entry);
    }
  }

  private populateBuiltIn(): void {
    // Core Arabic poetry vocabulary
    const builtInWords: PoetryWord[] = [
      // Meters (buḥūr)
      { arabic: 'طويل', transliteration: 'ṭawīl', english: 'long', meaning: 'long meter', root: 'ṭ-w-l', meter: 'ṭawīl', tribe: 'Abs', glyphCode: 0x1001, semanticVector: [1, 0, 0, 0, 0] },
      { arabic: 'مديد', transliteration: 'madīd', english: 'extended', meaning: 'extended meter', root: 'm-d-d', meter: 'madīd', tribe: 'Dhubyān', glyphCode: 0x1002, semanticVector: [0, 1, 0, 0, 0] },
      { arabic: 'بسيط', transliteration: 'basīṭ', english: 'simple', meaning: 'simple meter', root: 'b-s-ṭ', meter: 'basīṭ', tribe: 'Bakr', glyphCode: 0x1003, semanticVector: [0, 0, 1, 0, 0] },
      { arabic: 'كامل', transliteration: 'kamil', english: 'complete', meaning: 'complete meter', root: 'k-m-l', meter: 'kamil', tribe: 'Taghlib', glyphCode: 0x1004, semanticVector: [0, 0, 0, 1, 0] },
      { arabic: 'وافر', transliteration: 'wāfir', english: 'abundant', meaning: 'abundant meter', root: 'w-f-r', meter: 'wāfir', tribe: 'Tamīm', glyphCode: 0x1005, semanticVector: [0, 0, 0, 0, 1] },
      { arabic: 'رجز', transliteration: 'rajaz', english: 'tremor', meaning: 'tremor meter', root: 'r-j-z', meter: 'rajaz', tribe: 'Qays', glyphCode: 0x1006, semanticVector: [1, 1, 0, 0, 0] },
      { arabic: 'رمل', transliteration: 'ramal', english: 'sand', meaning: 'sand meter', root: 'r-m-l', meter: 'ramal', tribe: 'Abs', glyphCode: 0x1007, semanticVector: [0, 1, 1, 0, 0] },
      { arabic: 'سريع', transliteration: 'sariʻ', english: 'fast', meaning: 'fast meter', root: 's-r-ʻ', meter: 'sariʻ', tribe: 'Dhubyān', glyphCode: 0x1008, semanticVector: [0, 0, 1, 1, 0] },
      
      // Tribes
      { arabic: 'عبس', transliteration: 'Abs', english: 'Abs', meaning: 'Abs tribe', root: 'ʻ-b-s', meter: 'ṭawīl', tribe: 'Abs', glyphCode: 0x2001, semanticVector: [1, 0, 0, 0, 0] },
      { arabic: 'ذبيان', transliteration: 'Dhubyān', english: 'Dhubyān', meaning: 'Dhubyān tribe', root: 'dh-b-y', meter: 'madīd', tribe: 'Dhubyān', glyphCode: 0x2002, semanticVector: [0, 1, 0, 0, 0] },
      { arabic: 'بكر', transliteration: 'Bakr', english: 'Bakr', meaning: 'Bakr tribe', root: 'b-k-r', meter: 'basīṭ', tribe: 'Bakr', glyphCode: 0x2003, semanticVector: [0, 0, 1, 0, 0] },
      { arabic: 'تغلب', transliteration: 'Taghlib', english: 'Taghlib', meaning: 'Taghlib tribe', root: 'ṭ-gh-l', meter: 'kamil', tribe: 'Taghlib', glyphCode: 0x2004, semanticVector: [0, 0, 0, 1, 0] },
      { arabic: 'تميم', transliteration: 'Tamīm', english: 'Tamīm', meaning: 'Tamīm tribe', root: 't-m-m', meter: 'wāfir', tribe: 'Tamīm', glyphCode: 0x2005, semanticVector: [0, 0, 0, 0, 1] },
      { arabic: 'قيس', transliteration: 'Qays', english: 'Qays', meaning: 'Qays tribe', root: 'q-y-s', meter: 'rajaz', tribe: 'Qays', glyphCode: 0x2006, semanticVector: [1, 1, 0, 0, 0] },
      
      // Poetic terms
      { arabic: 'قافية', transliteration: 'qāfiyah', english: 'rhyme', meaning: 'poetic rhyme', root: 'q-f-y', meter: 'ṭawīl', tribe: 'Abs', glyphCode: 0x3001, semanticVector: [1, 0, 1, 0, 0] },
      { arabic: 'بحر', transliteration: 'baḥr', english: 'meter', meaning: 'poetic meter/sea', root: 'b-ḥ-r', meter: 'basīṭ', tribe: 'Bakr', glyphCode: 0x3002, semanticVector: [0, 1, 0, 1, 0] },
      { arabic: 'شطر', transliteration: 'shiṭr', english: 'hemistich', meaning: 'half-line of poetry', root: 'sh-ṭ-r', meter: 'madīd', tribe: 'Dhubyān', glyphCode: 0x3003, semanticVector: [0, 0, 1, 0, 1] },
      { arabic: 'عروض', transliteration: 'ʻarūḍ', english: 'prosody', meaning: 'science of poetic meter', root: 'ʻ-r-ḍ', meter: 'kamil', tribe: 'Taghlib', glyphCode: 0x3004, semanticVector: [1, 0, 0, 1, 0] },
      { arabic: 'ضرب', transliteration: 'ḍarb', english: 'cadence', meaning: 'closing section of verse', root: 'ḍ-r-b', meter: 'wāfir', tribe: 'Tamīm', glyphCode: 0x3005, semanticVector: [0, 1, 1, 0, 0] },
      { arabic: 'تفعيلة', transliteration: 'tafʻīlah', english: 'foot', meaning: 'metrical foot', root: 'f-ʻ-l', meter: 'rajaz', tribe: 'Qays', glyphCode: 0x3006, semanticVector: [0, 0, 0, 1, 1] },
      { arabic: 'سبب', transliteration: 'sabab', english: 'reason', meaning: 'metrical unit', root: 's-b-b', meter: 'ramal', tribe: 'Abs', glyphCode: 0x3007, semanticVector: [1, 1, 1, 0, 0] },
      { arabic: 'وتد', transliteration: 'watad', english: 'peg', meaning: 'metrical peg', root: 'w-t-d', meter: 'sariʻ', tribe: 'Dhubyān', glyphCode: 0x3008, semanticVector: [0, 1, 1, 1, 0] },
      
      // Common poetic words
      { arabic: 'حب', transliteration: 'ḥubb', english: 'love', meaning: 'love/affection', root: 'ḥ-b-b', meter: 'ṭawīl', tribe: 'Abs', glyphCode: 0x4001, semanticVector: [1, 0.5, 0, 0, 0.5] },
      { arabic: 'جمال', transliteration: 'jamāl', english: 'beauty', meaning: 'beauty', root: 'j-m-l', meter: 'madīd', tribe: 'Dhubyān', glyphCode: 0x4002, semanticVector: [0.5, 1, 0.5, 0, 0] },
      { arabic: 'نور', transliteration: 'nūr', english: 'light', meaning: 'light/illumination', root: 'n-w-r', meter: 'basīṭ', tribe: 'Bakr', glyphCode: 0x4003, semanticVector: [0, 0.5, 1, 0.5, 0] },
      { arabic: 'ظلام', transliteration: 'ẓalām', english: 'darkness', meaning: 'darkness', root: 'ẓ-l-m', meter: 'kamil', tribe: 'Taghlib', glyphCode: 0x4004, semanticVector: [0, 0, 0.5, 1, 0.5] },
      { arabic: 'قلب', transliteration: 'qalb', english: 'heart', meaning: 'heart', root: 'q-l-b', meter: 'wāfir', tribe: 'Tamīm', glyphCode: 0x4005, semanticVector: [0.5, 0, 0, 0.5, 1] },
      { arabic: 'روح', transliteration: 'rūḥ', english: 'soul', meaning: 'soul/spirit', root: 'r-w-ḥ', meter: 'rajaz', tribe: 'Qays', glyphCode: 0x4006, semanticVector: [1, 0, 0.5, 0, 0.5] },
      { arabic: 'عين', transliteration: 'ʻayn', english: 'eye', meaning: 'eye/spring', root: 'ʻ-y-n', meter: 'ramal', tribe: 'Abs', glyphCode: 0x4007, semanticVector: [0.5, 1, 0, 0.5, 0] },
      { arabic: 'فم', transliteration: 'fam', english: 'mouth', meaning: 'mouth', root: 'f-m-m', meter: 'sariʻ', tribe: 'Dhubyān', glyphCode: 0x4008, semanticVector: [0, 0.5, 1, 0, 0.5] },
      { arabic: 'يد', transliteration: 'yad', english: 'hand', meaning: 'hand/power', root: 'y-d-y', meter: 'ṭawīl', tribe: 'Abs', glyphCode: 0x4009, semanticVector: [0.5, 0, 0.5, 1, 0] },
      { arabic: 'رأس', transliteration: 'raʼs', english: 'head', meaning: 'head/chief', root: 'r-ʼ-s', meter: 'madīd', tribe: 'Dhubyān', glyphCode: 0x400A, semanticVector: [0, 0.5, 0, 0.5, 1] },
    ];
    
    for (const word of builtInWords) {
      const entry: DictionaryEntry = {
        word: word.english.toLowerCase(),
        definitions: [word],
        frequency: 1,
        category: word.meter ? 'meter' : word.tribe ? 'tribe' : 'noun',
      };
      
      // Add by English word
      this.cache.set(word.english.toLowerCase(), entry);
      // Add by transliteration
      this.cache.set(word.transliteration.toLowerCase(), entry);
      // Add by Arabic (Unicode)
      this.cache.set(word.arabic, entry);
    }
  }

  // ============================================
  // Lookup Methods
  // ============================================

  lookup(word: string): DictionaryEntry | undefined {
    return this.cache.get(word.toLowerCase());
  }

  lookupByRoot(root: string): PoetryWord[] {
    const results: PoetryWord[] = [];
    for (const entry of this.cache.values()) {
      for (const def of entry.definitions) {
        if (def.root === root) {
          results.push(def);
        }
      }
    }
    return results;
  }

  lookupByMeter(meter: string): PoetryWord[] {
    const results: PoetryWord[] = [];
    for (const entry of this.cache.values()) {
      for (const def of entry.definitions) {
        if (def.meter.toLowerCase() === meter.toLowerCase()) {
          results.push(def);
        }
      }
    }
    return results;
  }

  lookupByTribe(tribe: string): PoetryWord[] {
    const results: PoetryWord[] = [];
    for (const entry of this.cache.values()) {
      for (const def of entry.definitions) {
        if (def.tribe.toLowerCase() === tribe.toLowerCase()) {
          results.push(def);
        }
      }
    }
    return results;
  }

  // ============================================
  // Mathematical Reconstruction
  // ============================================

  /**
   * Reconstruct meaning using semantic vector similarity
   * Uses cosine similarity between semantic vectors
   */
  reconstructMeaning(input: string): PoetryWord[] {
    const inputVector = this.textToSemanticVector(input);
    const scored: Array<{ word: PoetryWord; score: number }> = [];
    
    for (const entry of this.cache.values()) {
      for (const def of entry.definitions) {
        const similarity = this.cosineSimilarity(inputVector, def.semanticVector);
        if (similarity > 0.3) {
          scored.push({ word: def, score: similarity });
        }
      }
    }
    
    // Sort by similarity score
    scored.sort((a, b) => b.score - a.score);
    
    return scored.slice(0, 5).map(s => s.word);
  }

  /**
   * Convert text to semantic vector using simple encoding
   */
  private textToSemanticVector(text: string): number[] {
    const vector = new Array(5).fill(0);
    const lower = text.toLowerCase();
    
    // Simple keyword-based encoding
    if (lower.includes('love') || lower.includes('heart')) vector[0] = 1;
    if (lower.includes('beauty') || lower.includes('light')) vector[1] = 1;
    if (lower.includes('dark') || lower.includes('night')) vector[2] = 1;
    if (lower.includes('poetry') || lower.includes('verse')) vector[3] = 1;
    if (lower.includes('meter') || lower.includes('rhyme')) vector[4] = 1;
    
    return vector;
  }

  /**
   * Calculate cosine similarity between two vectors
   */
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;
    
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    
    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    
    if (normA === 0 || normB === 0) return 0;
    
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  // ============================================
  // Glyph-Convolutional Encoding
  // ============================================

  /**
   * Encode word to glyph atom for convolutional processing
   */
  encodeToGlyph(word: string): { layer: number; template: number; polarity: '+' | '-' } | null {
    const entry = this.lookup(word);
    if (!entry || entry.definitions.length === 0) return null;
    
    const def = entry.definitions[0];
    const code = def.glyphCode;
    
    return {
      layer: (code >> 8) & 0xFF,
      template: code & 0xFF,
      polarity: (code & 0x8000) ? '-' : '+',
    };
  }

  // ============================================
  // Utility
  // ============================================

  getAllMeters(): string[] {
    const meters = new Set<string>();
    for (const entry of this.cache.values()) {
      for (const def of entry.definitions) {
        meters.add(def.meter);
      }
    }
    return Array.from(meters);
  }

  getAllTribes(): string[] {
    const tribes = new Set<string>();
    for (const entry of this.cache.values()) {
      for (const def of entry.definitions) {
        tribes.add(def.tribe);
      }
    }
    return Array.from(tribes);
  }

  getSize(): number {
    return this.cache.size;
  }

  onLoad(callback: () => void): void {
    if (this.loaded) {
      callback();
    } else {
      this.onLoadCallbacks.push(callback);
    }
  }
}

// Singleton instance
let dictionaryInstance: PoetryDictionary | null = null;

export function getPoetryDictionary(): PoetryDictionary {
  if (!dictionaryInstance) {
    dictionaryInstance = new PoetryDictionary();
  }
  return dictionaryInstance;
}
