/**
 * Python-to-PPU Assembly Compiler
 * Translates Python code to PPU bytecode with error fixing
 * Uses ast module patterns for parsing and transformation
 */

// Python to PPU Compiler

// ============================================
// PPU Assembly Opcodes
// ============================================

export const PPU_OPCODES = {
  NOP: 0x00,
  MOV: 0x01,      // MOV dst, src
  ADD: 0x02,      // ADD dst, src
  SUB: 0x03,      // SUB dst, src
  MUL: 0x04,      // MUL dst, src (log-domain)
  DIV: 0x05,      // DIV dst, src
  MOD: 0x06,      // MOD dst, src
  AND: 0x07,      // AND dst, src
  OR: 0x08,       // OR dst, src
  XOR: 0x09,      // XOR dst, src
  NOT: 0x0A,      // NOT dst
  SHL: 0x0B,      // SHL dst, n
  SHR: 0x0C,      // SHR dst, n
  LD: 0x0D,       // LD reg, [addr]
  ST: 0x0E,       // ST [addr], reg
  LDI: 0x0F,      // LDI reg, imm32
  IN: 0x10,       // IN reg, port
  OUT: 0x11,      // OUT port, reg
  FBSET: 0x12,    // FBSET x, y, color
  FBLIT: 0x13,    // FBLIT x, y, w, h, addr
  JMP: 0x14,      // JMP addr
  JZ: 0x15,       // JZ reg, addr
  JNZ: 0x16,      // JNZ reg, addr
  JL: 0x17,       // JL reg1, reg2, addr
  CALL: 0x18,     // CALL addr
  RET: 0x19,      // RET
  PUSH: 0x1A,     // PUSH reg
  POP: 0x1B,      // POP reg
  CMP: 0x1C,      // CMP reg1, reg2
  PRIME: 0x1D,    // PRIME reg (convert to prime domain)
  LOGMUL: 0x1E,   // LOGMUL dst, src (log-domain multiply)
  BAZ: 0x1F,      // BAZ reg (BAZ normalization)
  HALT: 0xFF,     // HALT
} as const;

export type PPUOpcode = keyof typeof PPU_OPCODES;

// ============================================
// Compiler State
// ============================================

interface CompilerState {
  bytecode: number[];
  labels: Map<string, number>;
  unresolvedLabels: Array<{ name: string; position: number }>;
  registerMap: Map<string, number>;
  nextRegister: number;
  errors: string[];
  warnings: string[];
}

// ============================================
// Error Corrector using pattern matching
// ============================================

const PYTHON_ERROR_PATTERNS: Array<{
  pattern: RegExp;
  fix: (match: RegExpMatchArray, code: string) => string;
  description: string;
}> = [
  // Missing colon after if/for/while/def
  {
    pattern: /^(\s*)(if|for|while|def|class|elif|else|try|except|finally)\b([^:]*\n)/m,
    fix: (match) => match[1] + match[2] + match[3].replace(/\n$/, ':\n'),
    description: 'Add missing colon after control statement',
  },
  // Missing parentheses in print (Python 2 style)
  {
    pattern: /print\s+([^\(][^\n]*)/,
    fix: (match) => `print(${match[1]})`,
    description: 'Convert print statement to function call',
  },
  // Missing quotes around string
  {
    pattern: /(\w+)\s*=\s*([a-zA-Z_][a-zA-Z0-9_]*)(\s*\n)/,
    fix: (match) => {
      const varName = match[2];
      // Check if it's likely a string (lowercase, not a known function)
      if (varName === varName.toLowerCase() && !['true', 'false', 'none'].includes(varName.toLowerCase())) {
        return match[1] + ' = "' + varName + '"' + match[3];
      }
      return match[0];
    },
    description: 'Add quotes around string literal',
  },
  // Indentation error - mixed tabs and spaces
  {
    pattern: /^(\t+)( +)/m,
    fix: (match) => '    '.repeat(match[1].length),
    description: 'Convert tabs to spaces',
  },
  // Missing import for common modules
  {
    pattern: /^(?!.*import.*numpy)(.*np\.)/m,
    fix: (match) => 'import numpy as np\n' + match[0],
    description: 'Add numpy import',
  },
  // Undefined variable - likely typo
  {
    pattern: /(\w+)\s*=\s*\1\s*\+\s*1/,
    fix: (match) => match[0],
    description: 'Variable self-increment (likely correct)',
  },
];

/**
 * Attempt to fix common Python errors
 */
export function fixPythonErrors(code: string): { fixed: string; fixes: string[] } {
  let fixed = code;
  const fixes: string[] = [];
  
  for (const { pattern, fix, description } of PYTHON_ERROR_PATTERNS) {
    const match = fixed.match(pattern);
    if (match) {
      const original = fixed;
      fixed = fix(match, fixed);
      if (fixed !== original) {
        fixes.push(description);
      }
    }
  }
  
  return { fixed, fixes };
}

// ============================================
// Python AST to PPU Assembly
// ============================================

interface ASTNode {
  type: string;
  value?: unknown;
  left?: ASTNode;
  right?: ASTNode;
  body?: ASTNode[];
  args?: ASTNode[];
  name?: string;
  op?: string;
}

/**
 * Simple Python parser (subset)
 * Converts Python-like syntax to AST
 */
export function parsePython(code: string): ASTNode | null {
  const lines = code.split('\n').filter(l => l.trim());
  if (lines.length === 0) return null;
  
  const body: ASTNode[] = [];
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    // Assignment: x = expr
    const assignMatch = trimmed.match(/^(\w+)\s*=\s*(.+)$/);
    if (assignMatch) {
      const [, name, expr] = assignMatch;
      body.push({
        type: 'Assign',
        name,
        right: parseExpression(expr),
      });
      continue;
    }
    
    // Function call: func(args)
    const callMatch = trimmed.match(/^(\w+)\((.*)\)$/);
    if (callMatch) {
      const [, name, argsStr] = callMatch;
      body.push({
        type: 'Call',
        name,
        args: argsStr ? argsStr.split(',').map(a => parseExpression(a.trim())) : [],
      });
      continue;
    }
    
    // If statement
    const ifMatch = trimmed.match(/^if\s+(.+):$/);
    if (ifMatch) {
      body.push({
        type: 'If',
        left: parseExpression(ifMatch[1]),
        body: [],
      });
      continue;
    }
    
    // For loop
    const forMatch = trimmed.match(/^for\s+(\w+)\s+in\s+range\((\d+)\):$/);
    if (forMatch) {
      body.push({
        type: 'For',
        name: forMatch[1],
        right: { type: 'Constant', value: parseInt(forMatch[2]) },
        body: [],
      });
      continue;
    }
    
    // Expression statement
    body.push({
      type: 'Expr',
      right: parseExpression(trimmed),
    });
  }
  
  return { type: 'Module', body };
}

function parseExpression(expr: string): ASTNode {
  expr = expr.trim();
  
  // Binary operations
  const binOpMatch = expr.match(/^(.+?)\s*([+\-*/%])\s*(.+)$/);
  if (binOpMatch) {
    const [, left, op, right] = binOpMatch;
    return {
      type: 'BinOp',
      op,
      left: parseExpression(left),
      right: parseExpression(right),
    };
  }
  
  // Comparison
  const cmpMatch = expr.match(/^(.+?)\s*(==|!=|<|>|<=|>=)\s*(.+)$/);
  if (cmpMatch) {
    const [, left, op, right] = cmpMatch;
    return {
      type: 'Compare',
      op,
      left: parseExpression(left),
      right: parseExpression(right),
    };
  }
  
  // Number
  if (/^\d+$/.test(expr)) {
    return { type: 'Constant', value: parseInt(expr) };
  }
  
  // String
  if (/^["'].*["']$/.test(expr)) {
    return { type: 'Constant', value: expr.slice(1, -1) };
  }
  
  // Name
  return { type: 'Name', name: expr };
}

// ============================================
// AST to PPU Assembly
// ============================================

export function compileToPPU(ast: ASTNode | null): { assembly: string; bytecode: Uint8Array; errors: string[] } {
  const state: CompilerState = {
    bytecode: [],
    labels: new Map(),
    unresolvedLabels: [],
    registerMap: new Map(),
    nextRegister: 0,
    errors: [],
    warnings: [],
  };
  
  if (!ast) {
    return { assembly: '', bytecode: new Uint8Array(0), errors: ['Empty AST'] };
  }
  
  const assemblyLines: string[] = [];
  assemblyLines.push('; PPU Assembly Generated from Python');
  assemblyLines.push('; ==================================');
  assemblyLines.push('');
  
  // Generate code for each statement
  if (ast.body) {
    for (const node of ast.body) {
      compileNode(node, state, assemblyLines);
    }
  }
  
  // Add HALT
  assemblyLines.push('HALT');
  emitBytecode(state, PPU_OPCODES.HALT);
  
  // Resolve labels
  for (const { name, position } of state.unresolvedLabels) {
    const target = state.labels.get(name);
    if (target !== undefined) {
      state.bytecode[position] = target & 0xFF;
      state.bytecode[position + 1] = (target >> 8) & 0xFF;
    } else {
      state.errors.push(`Undefined label: ${name}`);
    }
  }
  
  return {
    assembly: assemblyLines.join('\n'),
    bytecode: new Uint8Array(state.bytecode),
    errors: state.errors,
  };
}

function compileNode(node: ASTNode, state: CompilerState, assembly: string[]): void {
  switch (node.type) {
    case 'Assign':
      compileAssign(node, state, assembly);
      break;
    case 'BinOp':
      compileBinOp(node, state, assembly);
      break;
    case 'Call':
      compileCall(node, state, assembly);
      break;
    case 'If':
      compileIf(node, state, assembly);
      break;
    case 'For':
      compileFor(node, state, assembly);
      break;
    case 'Expr':
      if (node.right) {
        compileNode(node.right, state, assembly);
      }
      break;
    default:
      state.warnings.push(`Unhandled node type: ${node.type}`);
  }
}

function compileAssign(node: ASTNode, state: CompilerState, assembly: string[]): void {
  if (!node.right || !node.name) return;
  
  // Get register for variable
  const reg = getRegister(state, node.name);
  
  // Compile right-hand side
  compileExpression(node.right, state, assembly, reg);
  
  assembly.push(`; ${node.name} = ...`);
}

function compileBinOp(node: ASTNode, state: CompilerState, assembly: string[]): void {
  if (!node.left || !node.right || !node.op) return;
  
  const dstReg = state.nextRegister++;
  
  // Compile left operand
  compileExpression(node.left, state, assembly, dstReg);
  
  // Compile right operand to temp register
  const srcReg = state.nextRegister++;
  compileExpression(node.right, state, assembly, srcReg);
  
  // Emit operation
  switch (node.op) {
    case '+':
      assembly.push(`ADD r${dstReg}, r${srcReg}`);
      emitBytecode(state, PPU_OPCODES.ADD, dstReg, srcReg);
      break;
    case '-':
      assembly.push(`SUB r${dstReg}, r${srcReg}`);
      emitBytecode(state, PPU_OPCODES.SUB, dstReg, srcReg);
      break;
    case '*':
      // Use log-domain multiplication for PPU
      assembly.push(`LOGMUL r${dstReg}, r${srcReg}  ; log-domain multiply`);
      emitBytecode(state, PPU_OPCODES.LOGMUL, dstReg, srcReg);
      break;
    case '/':
      assembly.push(`DIV r${dstReg}, r${srcReg}`);
      emitBytecode(state, PPU_OPCODES.DIV, dstReg, srcReg);
      break;
    case '%':
      assembly.push(`MOD r${dstReg}, r${srcReg}`);
      emitBytecode(state, PPU_OPCODES.MOD, dstReg, srcReg);
      break;
  }
}

function compileExpression(node: ASTNode, state: CompilerState, assembly: string[], targetReg: number): void {
  switch (node.type) {
    case 'Constant':
      if (typeof node.value === 'number') {
        assembly.push(`LDI r${targetReg}, ${node.value}`);
        emitBytecode(state, PPU_OPCODES.LDI, targetReg);
        // 32-bit immediate
        emitBytecode(state, node.value & 0xFF);
        emitBytecode(state, (node.value >> 8) & 0xFF);
        emitBytecode(state, (node.value >> 16) & 0xFF);
        emitBytecode(state, (node.value >> 24) & 0xFF);
      }
      break;
    case 'Name':
      if (node.name) {
        const srcReg = getRegister(state, node.name);
        if (srcReg !== targetReg) {
          assembly.push(`MOV r${targetReg}, r${srcReg}`);
          emitBytecode(state, PPU_OPCODES.MOV, targetReg, srcReg);
        }
      }
      break;
    case 'BinOp':
      compileBinOp(node, state, assembly);
      break;
    default:
      state.warnings.push(`Unhandled expression type: ${node.type}`);
  }
}

function compileCall(node: ASTNode, state: CompilerState, assembly: string[]): void {
  if (!node.name) return;
  
  switch (node.name) {
    case 'print':
      // Print arguments to output port
      if (node.args && node.args.length > 0) {
        compileExpression(node.args[0], state, assembly, 0);
        assembly.push('OUT 0, r0  ; print');
        emitBytecode(state, PPU_OPCODES.OUT, 0, 0);
      }
      break;
    case 'fbset':
      // Set framebuffer pixel
      if (node.args && node.args.length >= 3) {
        compileExpression(node.args[0], state, assembly, 0); // x
        compileExpression(node.args[1], state, assembly, 1); // y
        compileExpression(node.args[2], state, assembly, 2); // color
        assembly.push('FBSET r0, r1, r2');
        emitBytecode(state, PPU_OPCODES.FBSET, 0, 1, 2);
      }
      break;
    case 'prime':
      // Convert to prime domain
      if (node.args && node.args.length > 0) {
        compileExpression(node.args[0], state, assembly, 0);
        assembly.push('PRIME r0');
        emitBytecode(state, PPU_OPCODES.PRIME, 0);
      }
      break;
    case 'baz':
      // BAZ normalization
      if (node.args && node.args.length > 0) {
        compileExpression(node.args[0], state, assembly, 0);
        assembly.push('BAZ r0');
        emitBytecode(state, PPU_OPCODES.BAZ, 0);
      }
      break;
    default:
      assembly.push(`; call ${node.name}()`);
      state.warnings.push(`Unknown function: ${node.name}`);
  }
}

function compileIf(node: ASTNode, state: CompilerState, assembly: string[]): void {
  if (!node.left) return;
  
  const elseLabel = `else_${state.bytecode.length}`;
  const endLabel = `endif_${state.bytecode.length}`;
  
  // Compile condition
  compileExpression(node.left, state, assembly, 0);
  
  assembly.push(`JZ r0, ${elseLabel}`);
  emitBytecode(state, PPU_OPCODES.JZ, 0);
  state.unresolvedLabels.push({ name: elseLabel, position: state.bytecode.length });
  emitBytecode(state, 0, 0); // Placeholder
  
  // Compile if body
  if (node.body) {
    for (const stmt of node.body) {
      compileNode(stmt, state, assembly);
    }
  }
  
  assembly.push(`JMP ${endLabel}`);
  emitBytecode(state, PPU_OPCODES.JMP);
  state.unresolvedLabels.push({ name: endLabel, position: state.bytecode.length });
  emitBytecode(state, 0, 0); // Placeholder
  
  // Else label
  state.labels.set(elseLabel, state.bytecode.length);
  assembly.push(`${elseLabel}:`);
  
  // End label
  state.labels.set(endLabel, state.bytecode.length);
  assembly.push(`${endLabel}:`);
}

function compileFor(node: ASTNode, state: CompilerState, assembly: string[]): void {
  if (!node.name || !node.right) return;
  
  const loopLabel = `loop_${state.bytecode.length}`;
  const endLabel = `endfor_${state.bytecode.length}`;
  const counterReg = getRegister(state, node.name);
  
  // Initialize counter
  assembly.push(`LDI r${counterReg}, 0`);
  emitBytecode(state, PPU_OPCODES.LDI, counterReg, 0, 0, 0, 0);
  
  // Loop label
  state.labels.set(loopLabel, state.bytecode.length);
  assembly.push(`${loopLabel}:`);
  
  // Get loop bound
  const boundReg = state.nextRegister++;
  if (node.right.type === 'Constant' && typeof node.right.value === 'number') {
    assembly.push(`LDI r${boundReg}, ${node.right.value}`);
    emitBytecode(state, PPU_OPCODES.LDI, boundReg);
    emitBytecode(state, node.right.value & 0xFF);
    emitBytecode(state, (node.right.value >> 8) & 0xFF);
    emitBytecode(state, (node.right.value >> 16) & 0xFF);
    emitBytecode(state, (node.right.value >> 24) & 0xFF);
  }
  
  // Compare and exit if done
  assembly.push(`CMP r${counterReg}, r${boundReg}`);
  emitBytecode(state, PPU_OPCODES.CMP, counterReg, boundReg);
  assembly.push(`JL r${counterReg}, r${boundReg}, ${endLabel}`);
  emitBytecode(state, PPU_OPCODES.JL, counterReg, boundReg);
  state.unresolvedLabels.push({ name: endLabel, position: state.bytecode.length });
  emitBytecode(state, 0, 0);
  
  // Compile loop body
  if (node.body) {
    for (const stmt of node.body) {
      compileNode(stmt, state, assembly);
    }
  }
  
  // Increment counter
  assembly.push(`ADD r${counterReg}, 1`);
  emitBytecode(state, PPU_OPCODES.ADD, counterReg, 1);
  
  // Jump back
  assembly.push(`JMP ${loopLabel}`);
  emitBytecode(state, PPU_OPCODES.JMP);
  const loopPos = state.labels.get(loopLabel);
  if (loopPos !== undefined) {
    emitBytecode(state, loopPos & 0xFF, (loopPos >> 8) & 0xFF);
  }
  
  // End label
  state.labels.set(endLabel, state.bytecode.length);
  assembly.push(`${endLabel}:`);
}

function getRegister(state: CompilerState, name: string): number {
  if (!state.registerMap.has(name)) {
    state.registerMap.set(name, state.nextRegister++);
  }
  return state.registerMap.get(name)!;
}

function emitBytecode(state: CompilerState, ...bytes: number[]): void {
  state.bytecode.push(...bytes);
}

// ============================================
// Main Compile Function
// ============================================

export interface CompileResult {
  success: boolean;
  original: string;
  fixed: string;
  fixes: string[];
  assembly: string;
  bytecode: Uint8Array;
  errors: string[];
  warnings: string[];
}

export function compilePythonToPPU(code: string): CompileResult {
  // Step 1: Fix errors
  const { fixed, fixes } = fixPythonErrors(code);
  
  // Step 2: Parse
  const ast = parsePython(fixed);
  
  // Step 3: Compile
  const { assembly, bytecode, errors } = compileToPPU(ast);
  
  return {
    success: errors.length === 0,
    original: code,
    fixed,
    fixes,
    assembly,
    bytecode,
    errors,
    warnings: [],
  };
}
