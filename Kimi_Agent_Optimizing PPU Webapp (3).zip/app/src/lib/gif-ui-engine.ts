/**
 * GIF UI Engine v6 - 4K Resolution, More Apps, Detailed Results
 */

import { compilePythonToPPU } from './python-to-ppu-compiler';
import { decompilePPUToPython } from './ppu-to-python-decompiler';
import { getNLTranslatorV2 } from './nl-to-ppu-v2';
import { calculate, getOperatorsByCategory } from './symbolic-math';
import { getPoetryDictionary } from './poetry-dictionary';

// ============================================
// Types
// ============================================

export type AppMode = 
  | 'home' | 'python' | 'ppu' | 'nl' | 'calc' | 'visual' 
  | 'matrix' | 'poetry' | 'symbols' | 'compiler' | 'decompiler' | 'settings';

export type UIElementType = 'button' | 'text' | 'code' | 'tab' | 'panel' | 'visualizer' | 'cursor' | 'key' | 'list';

export interface UIElement {
  id: string;
  type: UIElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  text: string;
  color: number;
  bgColor: number;
  active: boolean;
  selected: boolean;
}

export interface GIFUIState {
  mode: AppMode;
  elements: UIElement[];
  code: string;
  output: string[];
  cursor: { x: number; y: number };
  touch: { x: number; y: number; active: boolean; pressure: number };
  scrollOffset: number;
  selectedElement: string | null;
  keyboardVisible: boolean;
  frameCount: number;
  fps: number;
  screenScale: number;
  buttonSize: number;
  fontScale: number;
  // App-specific data
  selectedOp: string | null;
  poetryLoaded: boolean;
}

// ============================================
// Constants - 4K Resolution
// ============================================

const BASE_WIDTH = 1024;  // Internal resolution (scaled to 4K display)
const BASE_HEIGHT = 1024;
const NUM_POLES = 12;

// Colors
const COLORS = {
  bg: 0x0f172a,
  panel: 0x1e293b,
  panelBorder: 0x475569,
  text: 0xe2e8f0,
  textDim: 0x94a3b8,
  accent: 0x10b981,
  accent2: 0x3b82f6,
  accent3: 0xf59e0b,
  accent4: 0xec4899,
  button: 0x334155,
  buttonHover: 0x475569,
  buttonActive: 0x10b981,
  cursor: 0xffffff,
  keyNormal: 0x374151,
  keyPressed: 0x10b981,
  success: 0x22c55e,
  error: 0xef4444,
  warning: 0xf59e0b,
};

// Virtual keyboard layout
const KEYBOARD_ROWS = [
  ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';'],
  ['Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/'],
  ['SPACE', 'ENTER', 'BACK', 'CLR'],
];

// All app modes with icons
const ALL_MODES: { mode: AppMode; icon: string; color: number }[] = [
  { mode: 'home', icon: '●', color: COLORS.accent },
  { mode: 'python', icon: 'PY', color: COLORS.accent2 },
  { mode: 'ppu', icon: 'PPU', color: COLORS.accent3 },
  { mode: 'nl', icon: 'NL', color: COLORS.accent4 },
  { mode: 'calc', icon: '∑', color: COLORS.accent },
  { mode: 'matrix', icon: 'M', color: COLORS.accent2 },
  { mode: 'poetry', icon: '✦', color: COLORS.accent3 },
  { mode: 'symbols', icon: '∂', color: COLORS.accent4 },
  { mode: 'compiler', icon: '→', color: COLORS.accent },
  { mode: 'decompiler', icon: '←', color: COLORS.accent2 },
  { mode: 'visual', icon: '◈', color: COLORS.accent3 },
  { mode: 'settings', icon: '⚙', color: COLORS.textDim },
];

// ============================================
// GIF UI Engine
// ============================================

export class GIFUIEngine {
  private state: GIFUIState;
  private pixels: Uint8ClampedArray;
  private fieldA: Float32Array;
  private fieldB: Float32Array;
  private fieldC: Float32Array;
  private poles: { positions: Float32Array; velocities: Float32Array; phases: Float32Array; coherence: number; entropy: number };
  private clock: { tick: number; phase: number };
  private frameTimes: number[] = [];
  private font: Map<string, number[]> = new Map();
  private canvasWidth: number = BASE_WIDTH;
  private canvasHeight: number = BASE_HEIGHT;
  
  constructor() {
    this.state = this.createInitialState();
    const size = BASE_WIDTH * BASE_HEIGHT;
    this.pixels = new Uint8ClampedArray(size * 4);
    this.fieldA = new Float32Array(size).map(() => 0.1 + Math.random() * 0.05);
    this.fieldB = new Float32Array(size).map(() => 0.08 + Math.random() * 0.05);
    this.fieldC = new Float32Array(size).map(() => 0.05 + Math.random() * 0.05);
    this.poles = {
      positions: new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 2),
      velocities: new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 0.1),
      phases: new Float32Array(NUM_POLES),
      coherence: 0.78,
      entropy: 0.12,
    };
    this.clock = { tick: 0, phase: 0 };
    this.initFont();
    this.calibrateScreen(BASE_WIDTH, BASE_HEIGHT);
    this.buildUI();
  }
  
  private createInitialState(): GIFUIState {
    return {
      mode: 'home',
      elements: [],
      code: '',
      output: [],
      cursor: { x: 0, y: 0 },
      touch: { x: 0, y: 0, active: false, pressure: 0 },
      scrollOffset: 0,
      selectedElement: null,
      keyboardVisible: false,
      frameCount: 0,
      fps: 60,
      screenScale: 1,
      buttonSize: 48,
      fontScale: 1,
      selectedOp: null,
      poetryLoaded: false,
    };
  }
  
  calibrateScreen(screenWidth: number, screenHeight: number): void {
    this.canvasWidth = screenWidth;
    this.canvasHeight = screenHeight;
    const minDim = Math.min(screenWidth, screenHeight);
    const baseScale = minDim / BASE_WIDTH;
    const minButtonSize = 44;
    const desiredButtonSize = Math.max(minButtonSize, Math.floor(48 * baseScale));
    this.state.screenScale = desiredButtonSize / 48;
    this.state.buttonSize = desiredButtonSize;
    this.state.fontScale = Math.max(0.8, Math.min(1.5, this.state.screenScale));
    this.buildUI();
  }
  
  private initFont(): void {
    const fontData: Record<string, number[]> = {
      'A': [0b01110, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001],
      'B': [0b11110, 0b10001, 0b10001, 0b11110, 0b10001, 0b10001, 0b11110],
      'C': [0b01110, 0b10001, 0b10000, 0b10000, 0b10000, 0b10001, 0b01110],
      'D': [0b11110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b11110],
      'E': [0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b11111],
      'F': [0b11111, 0b10000, 0b10000, 0b11110, 0b10000, 0b10000, 0b10000],
      'G': [0b01110, 0b10001, 0b10000, 0b10011, 0b10001, 0b10001, 0b01110],
      'H': [0b10001, 0b10001, 0b10001, 0b11111, 0b10001, 0b10001, 0b10001],
      'I': [0b01110, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110],
      'J': [0b00001, 0b00001, 0b00001, 0b00001, 0b10001, 0b10001, 0b01110],
      'K': [0b10001, 0b10010, 0b10100, 0b11000, 0b10100, 0b10010, 0b10001],
      'L': [0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b10000, 0b11111],
      'M': [0b10001, 0b11011, 0b10101, 0b10001, 0b10001, 0b10001, 0b10001],
      'N': [0b10001, 0b11001, 0b10101, 0b10011, 0b10001, 0b10001, 0b10001],
      'O': [0b01110, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110],
      'P': [0b11110, 0b10001, 0b10001, 0b11110, 0b10000, 0b10000, 0b10000],
      'Q': [0b01110, 0b10001, 0b10001, 0b10001, 0b10101, 0b10010, 0b01101],
      'R': [0b11110, 0b10001, 0b10001, 0b11110, 0b10100, 0b10010, 0b10001],
      'S': [0b01111, 0b10000, 0b10000, 0b01110, 0b00001, 0b00001, 0b11110],
      'T': [0b11111, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100],
      'U': [0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01110],
      'V': [0b10001, 0b10001, 0b10001, 0b10001, 0b10001, 0b01010, 0b00100],
      'W': [0b10001, 0b10001, 0b10001, 0b10101, 0b10101, 0b10101, 0b01010],
      'X': [0b10001, 0b10001, 0b01010, 0b00100, 0b01010, 0b10001, 0b10001],
      'Y': [0b10001, 0b10001, 0b10001, 0b01010, 0b00100, 0b00100, 0b00100],
      'Z': [0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b11111],
      '0': [0b01110, 0b10001, 0b10011, 0b10101, 0b11001, 0b10001, 0b01110],
      '1': [0b00100, 0b01100, 0b00100, 0b00100, 0b00100, 0b00100, 0b01110],
      '2': [0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0b01000, 0b11111],
      '3': [0b11111, 0b00010, 0b00100, 0b00010, 0b00001, 0b10001, 0b01110],
      '4': [0b00010, 0b00110, 0b01010, 0b10010, 0b11111, 0b00010, 0b00010],
      '5': [0b11111, 0b10000, 0b11110, 0b00001, 0b00001, 0b10001, 0b01110],
      '6': [0b01110, 0b10001, 0b10000, 0b11110, 0b10001, 0b10001, 0b01110],
      '7': [0b11111, 0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b01000],
      '8': [0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001, 0b01110],
      '9': [0b01110, 0b10001, 0b10001, 0b01111, 0b00001, 0b10001, 0b01110],
      ' ': [0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b00000],
      '.': [0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b01100, 0b01100],
      ',': [0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b00110, 0b01100],
      ':': [0b00000, 0b01100, 0b01100, 0b00000, 0b01100, 0b01100, 0b00000],
      ';': [0b00000, 0b00110, 0b00110, 0b00000, 0b00110, 0b01100, 0b00000],
      '!': [0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00000, 0b00100],
      '?': [0b01110, 0b10001, 0b00001, 0b00010, 0b00100, 0b00000, 0b00100],
      '-': [0b00000, 0b00000, 0b00000, 0b11111, 0b00000, 0b00000, 0b00000],
      '_': [0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b00000, 0b11111],
      '+': [0b00000, 0b00100, 0b00100, 0b11111, 0b00100, 0b00100, 0b00000],
      '=': [0b00000, 0b00000, 0b11111, 0b00000, 0b11111, 0b00000, 0b00000],
      '*': [0b00000, 0b00100, 0b10101, 0b01110, 0b10101, 0b00100, 0b00000],
      '/': [0b00000, 0b00001, 0b00010, 0b00100, 0b01000, 0b10000, 0b00000],
      '(': [0b00100, 0b01000, 0b10000, 0b10000, 0b10000, 0b01000, 0b00100],
      ')': [0b00100, 0b00010, 0b00001, 0b00001, 0b00001, 0b00010, 0b00100],
      '[': [0b01110, 0b01000, 0b01000, 0b01000, 0b01000, 0b01000, 0b01110],
      ']': [0b01110, 0b00010, 0b00010, 0b00010, 0b00010, 0b00010, 0b01110],
      '{': [0b00110, 0b01000, 0b01000, 0b10000, 0b01000, 0b01000, 0b00110],
      '}': [0b01100, 0b00010, 0b00010, 0b00001, 0b00010, 0b00010, 0b01100],
      '<': [0b00010, 0b00100, 0b01000, 0b10000, 0b01000, 0b00100, 0b00010],
      '>': [0b01000, 0b00100, 0b00010, 0b00001, 0b00010, 0b00100, 0b01000],
      '|': [0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100, 0b00100],
      "'": [0b00100, 0b00100, 0b00000, 0b00000, 0b00000, 0b00000, 0b00000],
      '"': [0b01010, 0b01010, 0b00000, 0b00000, 0b00000, 0b00000, 0b00000],
      '#': [0b01010, 0b01010, 0b11111, 0b01010, 0b11111, 0b01010, 0b01010],
      '$': [0b00100, 0b01111, 0b10100, 0b01110, 0b00101, 0b11110, 0b00100],
      '%': [0b11000, 0b11001, 0b00010, 0b00100, 0b01000, 0b10011, 0b00011],
      '@': [0b01110, 0b10001, 0b10111, 0b10101, 0b10111, 0b10000, 0b01110],
      '&': [0b01100, 0b10010, 0b10100, 0b01010, 0b10101, 0b10001, 0b01110],
      '^': [0b00100, 0b01010, 0b10001, 0b00000, 0b00000, 0b00000, 0b00000],
      '~': [0b00000, 0b00000, 0b01000, 0b10101, 0b00010, 0b00000, 0b00000],
      '`': [0b10000, 0b01000, 0b00100, 0b00000, 0b00000, 0b00000, 0b00000],
      '→': [0b00000, 0b00100, 0b00100, 0b11111, 0b00100, 0b00100, 0b00000],
      '←': [0b00000, 0b00100, 0b00100, 0b11111, 0b00100, 0b00100, 0b00000],
      '↑': [0b00100, 0b01110, 0b10101, 0b00100, 0b00100, 0b00100, 0b00100],
      '↓': [0b00100, 0b00100, 0b00100, 0b10101, 0b01110, 0b00100, 0b00100],
      '●': [0b00000, 0b01110, 0b11111, 0b11111, 0b11111, 0b01110, 0b00000],
      '○': [0b00000, 0b01110, 0b10001, 0b10001, 0b10001, 0b01110, 0b00000],
      '■': [0b00000, 0b00000, 0b01110, 0b01110, 0b01110, 0b00000, 0b00000],
      '□': [0b00000, 0b00000, 0b01110, 0b01010, 0b01110, 0b00000, 0b00000],
      '◈': [0b00100, 0b01110, 0b11111, 0b11111, 0b11111, 0b01110, 0b00100],
      '✦': [0b00100, 0b01110, 0b00100, 0b11111, 0b00100, 0b01110, 0b00100],
      '∑': [0b01111, 0b01000, 0b01000, 0b01100, 0b01000, 0b01000, 0b11111],
      '∂': [0b00110, 0b01001, 0b01000, 0b01110, 0b01000, 0b01000, 0b01000],
      'π': [0b00000, 0b11111, 0b01010, 0b01010, 0b01010, 0b01010, 0b01010],
      '√': [0b00001, 0b00010, 0b00100, 0b01000, 0b01000, 0b10100, 0b10100],
      '∞': [0b00000, 0b01110, 0b10001, 0b10001, 0b01110, 0b10001, 0b10001],
      '⚙': [0b00100, 0b01110, 0b11111, 0b01110, 0b11111, 0b01110, 0b00100],
    };
    
    for (const [char, pattern] of Object.entries(fontData)) {
      this.font.set(char, pattern);
    }
  }
  
  // ============================================
  // UI Builder
  // ============================================
  
  private buildUI(): void {
    const elements: UIElement[] = [];
    const bs = this.state.buttonSize;
    const pad = Math.floor(bs * 0.12);
    
    // Tab bar - 2 rows of tabs for 12 modes
    const tabHeight = Math.floor(bs * 0.55);
    const tabsPerRow = 6;
    const tabWidth = Math.floor((BASE_WIDTH - pad * 2) / tabsPerRow);
    
    ALL_MODES.forEach((modeInfo, i) => {
      const row = Math.floor(i / tabsPerRow);
      const col = i % tabsPerRow;
      elements.push({
        id: `tab-${modeInfo.mode}`,
        type: 'tab',
        x: pad + col * tabWidth,
        y: pad + row * (tabHeight + pad),
        width: tabWidth - pad,
        height: tabHeight,
        text: `${modeInfo.icon}`,
        color: this.state.mode === modeInfo.mode ? 0x000000 : COLORS.text,
        bgColor: this.state.mode === modeInfo.mode ? modeInfo.color : COLORS.button,
        active: true,
        selected: this.state.mode === modeInfo.mode,
      });
    });
    
    const contentY = pad * 2 + tabHeight * 2 + pad;
    const contentHeight = this.state.keyboardVisible 
      ? BASE_HEIGHT - contentY - Math.floor(bs * 5.5) - pad
      : BASE_HEIGHT - contentY - pad;
    
    elements.push({
      id: 'content-panel',
      type: 'panel',
      x: pad,
      y: contentY,
      width: BASE_WIDTH - pad * 2,
      height: contentHeight,
      text: '',
      color: COLORS.text,
      bgColor: COLORS.panel,
      active: true,
      selected: false,
    });
    
    this.buildModeElements(elements, pad * 2, contentY + pad, BASE_WIDTH - pad * 4, contentHeight - pad * 2);
    
    if (this.state.keyboardVisible) {
      this.buildKeyboard(elements, pad, BASE_HEIGHT - Math.floor(bs * 5.5) - pad, BASE_WIDTH - pad * 2);
    }
    
    this.state.elements = elements;
  }
  
  private buildModeElements(elements: UIElement[], x: number, y: number, w: number, h: number): void {
    const bs = Math.floor(this.state.buttonSize * 0.75);
    const pad = Math.floor(bs * 0.15);
    
    switch (this.state.mode) {
      case 'home':
        elements.push({
          id: 'title', type: 'text', x, y, width: w, height: 24,
          text: 'PPU-AQC PLATFORM v6', color: COLORS.accent, bgColor: 0,
          active: true, selected: false,
        });
        elements.push({
          id: 'subtitle', type: 'text', x, y: y + 28, width: w, height: 16,
          text: '4K Resolution | Clock → Poles → GIF → Display', color: COLORS.textDim, bgColor: 0,
          active: true, selected: false,
        });
        const features = [
          '12 APPLICATIONS: Python, PPU, NL, Calc, Matrix, Poetry,',
          'Symbols, Compiler, Decompiler, Visual, Settings',
          '',
          'TOUCH: Feed energy into GIF field',
          'TABS: Switch between applications',
          'KEYBOARD: Type commands',
        ];
        features.forEach((line, i) => {
          elements.push({
            id: `feat-${i}`, type: 'text', x, y: y + 60 + i * 18, width: w, height: 16,
            text: line, color: COLORS.text, bgColor: 0, active: true, selected: false,
          });
        });
        elements.push({
          id: 'stats', type: 'text', x, y: y + 180, width: w, height: 80,
          text: `RESOLUTION: ${BASE_WIDTH}x${BASE_HEIGHT}\nFPS: ${this.state.fps.toFixed(0)}\nCOHERENCE: ${(this.poles.coherence * 100).toFixed(0)}%\nENTROPY: ${(this.poles.entropy * 100).toFixed(0)}%`,
          color: COLORS.accent, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'toggle-kb', type: 'button', x, y: y + h - bs - pad, width: bs * 4, height: bs,
          text: this.state.keyboardVisible ? '▼ HIDE KEYBOARD' : '▲ SHOW KEYBOARD',
          color: COLORS.text, bgColor: COLORS.button, active: true, selected: false,
        });
        break;
        
      case 'python':
      case 'ppu':
        if (!this.state.code) {
          this.state.code = this.state.mode === 'python' 
            ? '# Python to PPU Compiler\nx = 128\ny = 256\nresult = x + y\nprint(f"Result: {result}")'
            : '; PPU Assembly\nLDI r0, 128\nLDI r1, 256\nADD r0, r1\nOUT 0, r0\nHALT';
        }
        const codeText = this.state.code + (Math.floor(this.clock.tick / 30) % 2 === 0 ? '_' : '');
        elements.push({
          id: 'code-area', type: 'code', x, y, width: w, height: Math.floor(h * 0.55),
          text: codeText, color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'run-btn', type: 'button', x, y: y + Math.floor(h * 0.55) + pad, width: bs * 2, height: bs,
          text: '▶ RUN', color: COLORS.text, bgColor: COLORS.accent, active: true, selected: false,
        });
        elements.push({
          id: 'clear-btn', type: 'button', x: x + bs * 2 + pad * 2, y: y + Math.floor(h * 0.55) + pad, width: bs * 2, height: bs,
          text: '✕ CLEAR', color: COLORS.text, bgColor: COLORS.button, active: true, selected: false,
        });
        elements.push({
          id: 'toggle-kb', type: 'button', x: x + bs * 4 + pad * 4, y: y + Math.floor(h * 0.55) + pad, width: bs * 2, height: bs,
          text: this.state.keyboardVisible ? '▼ KB' : '▲ KB', color: COLORS.text, bgColor: COLORS.button, active: true, selected: false,
        });
        elements.push({
          id: 'output-area', type: 'code', x, y: y + Math.floor(h * 0.55) + bs + pad * 2, width: w, height: h - Math.floor(h * 0.55) - bs - pad * 3,
          text: this.state.output.join('\n') || '> Ready...', color: COLORS.success, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'nl':
        if (!this.state.code) {
          this.state.code = 'draw a red circle at 512 512 with radius 100';
        }
        const nlText = this.state.code + (Math.floor(this.clock.tick / 30) % 2 === 0 ? '_' : '');
        elements.push({
          id: 'nl-input', type: 'code', x, y, width: w, height: Math.floor(h * 0.5),
          text: nlText, color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'translate-btn', type: 'button', x, y: y + Math.floor(h * 0.5) + pad, width: bs * 3, height: bs,
          text: '✨ TRANSLATE', color: COLORS.text, bgColor: COLORS.accent, active: true, selected: false,
        });
        elements.push({
          id: 'toggle-kb', type: 'button', x: x + bs * 3 + pad * 2, y: y + Math.floor(h * 0.5) + pad, width: bs * 2, height: bs,
          text: this.state.keyboardVisible ? '▼ KB' : '▲ KB', color: COLORS.text, bgColor: COLORS.button, active: true, selected: false,
        });
        elements.push({
          id: 'nl-output', type: 'code', x, y: y + Math.floor(h * 0.5) + bs + pad * 2, width: w, height: h - Math.floor(h * 0.5) - bs - pad * 3,
          text: this.state.output.join('\n') || '> Enter natural language command...', color: COLORS.success, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'calc':
        if (!this.state.code) {
          this.state.code = 'sin(3.14159/2) + cos(0)';
        }
        const calcText = this.state.code + (Math.floor(this.clock.tick / 30) % 2 === 0 ? '_' : '');
        elements.push({
          id: 'calc-input', type: 'code', x, y, width: w, height: 40,
          text: calcText, color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'calc-btn', type: 'button', x, y: y + 45, width: bs * 2, height: bs,
          text: '= CALCULATE', color: COLORS.text, bgColor: COLORS.accent, active: true, selected: false,
        });
        elements.push({
          id: 'toggle-kb', type: 'button', x: x + bs * 2 + pad * 2, y: y + 45, width: bs * 2, height: bs,
          text: this.state.keyboardVisible ? '▼ KB' : '▲ KB', color: COLORS.text, bgColor: COLORS.button, active: true, selected: false,
        });
        elements.push({
          id: 'calc-result', type: 'code', x, y: y + 50 + bs + pad, width: w, height: h - 55 - bs - pad,
          text: this.state.output.join('\n') || '> Result will appear here...', color: COLORS.success, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'matrix':
        elements.push({
          id: 'matrix-title', type: 'text', x, y, width: w, height: 20,
          text: 'MATRIX SELECTOR GRAMMAR', color: COLORS.accent2, bgColor: 0, active: true, selected: false,
        });
        elements.push({
          id: 'matrix-formula', type: 'code', x, y: y + 25, width: w, height: 60,
          text: 'F = S · T · E(0)\n\nSeed → Lift → Selector', color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'matrix-desc', type: 'text', x, y: y + 95, width: w, height: h - 100,
          text: 'Seed: Initial semantic vector\nLift: Transform to higher space\nSelector: Choose output dimension\n\nUsed for NL → Code translation', color: COLORS.textDim, bgColor: 0, active: true, selected: false,
        });
        break;
        
      case 'poetry':
        elements.push({
          id: 'poetry-title', type: 'text', x, y, width: w, height: 20,
          text: 'POETRY DICTIONARY (CDN)', color: COLORS.accent3, bgColor: 0, active: true, selected: false,
        });
        if (!this.state.poetryLoaded) {
          elements.push({
            id: 'load-poetry', type: 'button', x, y: y + 30, width: bs * 4, height: bs,
            text: 'LOAD DICTIONARY', color: COLORS.text, bgColor: COLORS.accent, active: true, selected: false,
          });
        }
        elements.push({
          id: 'poetry-status', type: 'code', x, y: y + 35 + bs + pad, width: w, height: h - 40 - bs - pad,
          text: this.state.output.join('\n') || (this.state.poetryLoaded ? 'Dictionary loaded!\nArabic-English vocabulary\nwith semantic vectors' : 'Tap LOAD to fetch poetry dictionary'), color: COLORS.success, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'symbols':
        elements.push({
          id: 'symbols-title', type: 'text', x, y, width: w, height: 20,
          text: 'SYMBOLIC MATH LIBRARY (250+)', color: COLORS.accent4, bgColor: 0, active: true, selected: false,
        });
        const operators = getOperatorsByCategory();
        let opY = y + 30;
        Object.entries(operators).slice(0, 4).forEach(([cat, ops], i) => {
          elements.push({
            id: `op-cat-${i}`, type: 'text', x, y: opY, width: w, height: 16,
            text: `${cat}: ${ops.slice(0, 8).join(' ')}`, color: COLORS.text, bgColor: 0, active: true, selected: false,
          });
          opY += 18;
        });
        elements.push({
          id: 'symbols-more', type: 'text', x, y: opY + 10, width: w, height: 40,
          text: 'Differential: ∂ ∇ Δ δ\nQuantum: ℏ ⟨⟩ |⟩ ⊗ ⊕\nTopology: ≅ ≃ π₁ Hₙ χ', color: COLORS.textDim, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'compiler':
        if (!this.state.code) {
          this.state.code = '# Compile Python to PPU\ndef add(a, b):\n    return a + b\nprint(add(5, 3))';
        }
        const compText = this.state.code + (Math.floor(this.clock.tick / 30) % 2 === 0 ? '_' : '');
        elements.push({
          id: 'compiler-input', type: 'code', x, y, width: w, height: Math.floor(h * 0.45),
          text: compText, color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'compile-btn', type: 'button', x, y: y + Math.floor(h * 0.45) + pad, width: bs * 3, height: bs,
          text: '⚙ COMPILE', color: COLORS.text, bgColor: COLORS.accent, active: true, selected: false,
        });
        elements.push({
          id: 'compiler-output', type: 'code', x, y: y + Math.floor(h * 0.45) + bs + pad * 2, width: w, height: h - Math.floor(h * 0.45) - bs - pad * 3,
          text: this.state.output.join('\n') || '> Compiled output will appear here...', color: COLORS.success, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'decompiler':
        if (!this.state.code) {
          this.state.code = '; Decompile PPU to Python\nLDI r0, 100\nLDI r1, 200\nADD r0, r1\nOUT 0, r0\nHALT';
        }
        const decompText = this.state.code + (Math.floor(this.clock.tick / 30) % 2 === 0 ? '_' : '');
        elements.push({
          id: 'decompiler-input', type: 'code', x, y, width: w, height: Math.floor(h * 0.45),
          text: decompText, color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'decompile-btn', type: 'button', x, y: y + Math.floor(h * 0.45) + pad, width: bs * 3, height: bs,
          text: '← DECOMPILE', color: COLORS.text, bgColor: COLORS.accent2, active: true, selected: false,
        });
        elements.push({
          id: 'decompiler-output', type: 'code', x, y: y + Math.floor(h * 0.45) + bs + pad * 2, width: w, height: h - Math.floor(h * 0.45) - bs - pad * 3,
          text: this.state.output.join('\n') || '> Decompiled Python will appear here...', color: COLORS.success, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        break;
        
      case 'visual':
        elements.push({
          id: 'poles-viz', type: 'visualizer', x, y, width: w, height: Math.floor(h * 0.75),
          text: '12-POLE HARMONIC OSCILLATOR', color: COLORS.accent, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'viz-stats', type: 'text', x, y: y + Math.floor(h * 0.75) + 5, width: w, height: 40,
          text: `COHERENCE: ${(this.poles.coherence * 100).toFixed(1)}% | ENTROPY: ${(this.poles.entropy * 100).toFixed(1)}% | FPS: ${this.state.fps.toFixed(0)}`,
          color: COLORS.text, bgColor: 0, active: true, selected: false,
        });
        break;
        
      case 'settings':
        elements.push({
          id: 'settings-title', type: 'text', x, y, width: w, height: 20,
          text: 'SYSTEM SETTINGS', color: COLORS.textDim, bgColor: 0, active: true, selected: false,
        });
        elements.push({
          id: 'settings-info', type: 'code', x, y: y + 30, width: w, height: 150,
          text: `RESOLUTION: ${BASE_WIDTH}x${BASE_HEIGHT}\nPOLES: ${NUM_POLES}\nFPS: ${this.state.fps.toFixed(0)}\nCOHERENCE: ${(this.poles.coherence * 100).toFixed(1)}%\nENTROPY: ${(this.poles.entropy * 100).toFixed(1)}%`,
          color: COLORS.text, bgColor: 0x0a0a0a, active: true, selected: false,
        });
        elements.push({
          id: 'reset-btn', type: 'button', x, y: y + 190, width: bs * 3, height: bs,
          text: '↺ RESET SYSTEM', color: COLORS.text, bgColor: COLORS.error, active: true, selected: false,
        });
        break;
    }
  }
  
  private buildKeyboard(elements: UIElement[], x: number, y: number, w: number): void {
    const bs = Math.floor(this.state.buttonSize * 0.55);
    const pad = 3;
    const keyWidth = Math.floor((w - pad * 9) / 10);
    
    KEYBOARD_ROWS.forEach((row, rowIdx) => {
      const rowY = y + rowIdx * (bs + pad);
      
      row.forEach((key, keyIdx) => {
        let keyW = keyWidth;
        let keyX = x + keyIdx * (keyWidth + pad);
        
        if (key === 'SPACE') { keyW = keyWidth * 3; }
        else if (key === 'ENTER') { keyW = keyWidth * 2; keyX = x + 3 * (keyWidth + pad); }
        else if (key === 'BACK') { keyW = keyWidth * 2; keyX = x + 5 * (keyWidth + pad); }
        else if (key === 'CLR') { keyW = keyWidth * 2; keyX = x + 7 * (keyWidth + pad); }
        
        elements.push({
          id: `key-${key}`,
          type: 'key',
          x: keyX,
          y: rowY,
          width: keyW,
          height: bs,
          text: key === 'BACK' ? '←' : key === 'SPACE' ? '___' : key === 'CLR' ? 'CLR' : key,
          color: COLORS.text,
          bgColor: COLORS.keyNormal,
          active: true,
          selected: false,
        });
      });
    });
  }
  
  // ============================================
  // Main Loop
  // ============================================
  
  step(dt: number): ImageData {
    this.clock.tick++;
    this.clock.phase = (this.clock.phase + 2 * Math.PI * 0.1 * dt) % (2 * Math.PI);
    this.updatePoles(dt);
    this.updateField(dt);
    this.renderUI();
    this.fieldToPixels();
    
    const now = performance.now();
    this.frameTimes.push(now);
    while (this.frameTimes.length > 30) this.frameTimes.shift();
    if (this.frameTimes.length > 1) {
      const span = this.frameTimes[this.frameTimes.length - 1] - this.frameTimes[0];
      this.state.fps = (this.frameTimes.length - 1) / (span / 1000);
    }
    
    this.state.frameCount++;
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return new ImageData(this.pixels as any, BASE_WIDTH, BASE_HEIGHT);
  }
  
  private updatePoles(dt: number): void {
    const { positions, velocities, phases } = this.poles;
    
    for (let i = 0; i < NUM_POLES; i++) {
      const freq = 1.0 + 0.13 * i;
      const damping = 0.08 + 0.004 * i;
      const drive = 0.1 * Math.sin(this.clock.phase * freq);
      
      const acceleration = -freq * freq * positions[i] - damping * velocities[i] + drive;
      velocities[i] += acceleration * dt;
      positions[i] += velocities[i] * dt;
      phases[i] = (phases[i] + freq * dt) % (2 * Math.PI);
    }
    
    const energies = positions.map((p, i) => 0.5 * (p * p + velocities[i] * velocities[i]));
    const avgEnergy = energies.reduce((a, b) => a + b, 0) / NUM_POLES;
    const variance = energies.reduce((sum, e) => sum + (e - avgEnergy) ** 2, 0) / NUM_POLES;
    
    this.poles.entropy = Math.min(1, avgEnergy);
    this.poles.coherence = Math.max(0, 1 - Math.sqrt(variance));
  }
  
  private updateField(dt: number): void {
    const { fieldA, fieldB } = this;
    const { positions, coherence } = this.poles;
    
    const feedRate = 0.032 + 0.01 * positions[0] * coherence;
    const killRate = 0.053 + 0.01 * positions[1] * coherence;
    const diffusionA = 1.0 + 0.2 * positions[2];
    const diffusionB = 0.55 + 0.1 * positions[3];
    
    if (this.state.touch.active) {
      this.addTouchEnergy(this.state.touch.x, this.state.touch.y, this.state.touch.pressure);
    }
    
    const newA = new Float32Array(fieldA);
    const newB = new Float32Array(fieldB);
    
    for (let y = 1; y < BASE_HEIGHT - 1; y++) {
      for (let x = 1; x < BASE_WIDTH - 1; x++) {
        const idx = y * BASE_WIDTH + x;
        const a = fieldA[idx];
        const b = fieldB[idx];
        
        const la = this.laplacian(fieldA, x, y);
        const lb = this.laplacian(fieldB, x, y);
        
        const ab2 = a * b * b;
        
        newA[idx] = Math.max(0, Math.min(1, a + (diffusionA * la - ab2 + feedRate * (1 - a)) * dt));
        newB[idx] = Math.max(0, Math.min(1, b + (diffusionB * lb + ab2 - (killRate + feedRate) * b) * dt));
      }
    }
    
    this.fieldA.set(newA);
    this.fieldB.set(newB);
  }
  
  private addTouchEnergy(x: number, y: number, strength: number): void {
    const radius = 25;
    const r2 = radius * radius;
    
    for (let dy = -radius; dy <= radius; dy++) {
      const py = Math.floor(y) + dy;
      if (py < 1 || py >= BASE_HEIGHT - 1) continue;
      
      for (let dx = -radius; dx <= radius; dx++) {
        const px = Math.floor(x) + dx;
        if (px < 1 || px >= BASE_WIDTH - 1) continue;
        
        if (dx * dx + dy * dy > r2) continue;
        
        const idx = py * BASE_WIDTH + px;
        const energy = strength * (1 - (dx * dx + dy * dy) / r2);
        
        this.fieldA[idx] = Math.min(1, this.fieldA[idx] + 0.3 * energy);
        this.fieldB[idx] = Math.min(1, this.fieldB[idx] + 0.2 * energy);
      }
    }
  }
  
  private laplacian(field: Float32Array, x: number, y: number): number {
    const idx = y * BASE_WIDTH + x;
    return field[idx - 1] + field[idx + 1] + field[idx - BASE_WIDTH] + field[idx + BASE_WIDTH] - 4 * field[idx];
  }
  
  // ============================================
  // Rendering
  // ============================================
  
  private renderUI(): void {
    this.buildUI();
    
    for (const el of this.state.elements) {
      switch (el.type) {
        case 'panel':
          this.fillRect(el.x, el.y, el.width, el.height, el.bgColor, 0.9);
          this.drawBorder(el.x, el.y, el.width, el.height, COLORS.panelBorder);
          break;
        case 'button':
        case 'key':
          this.drawButton(el);
          break;
        case 'tab':
          this.drawTab(el);
          break;
        case 'text':
        case 'code':
          this.drawTextBlock(el.x, el.y, el.text, el.color, el.bgColor);
          break;
        case 'visualizer':
          this.drawVisualizer(el);
          break;
      }
    }
  }
  
  private drawButton(el: UIElement): void {
    const isPressed = this.state.touch.active && 
      this.state.touch.x >= el.x && this.state.touch.x < el.x + el.width &&
      this.state.touch.y >= el.y && this.state.touch.y < el.y + el.height;
    
    const bgColor = isPressed ? COLORS.accent : el.bgColor;
    const borderColor = isPressed ? 0xffffff : COLORS.panelBorder;
    
    this.fillRect(el.x, el.y, el.width, el.height, bgColor, 0.95);
    this.drawBorder(el.x, el.y, el.width, el.height, borderColor);
    
    const textX = el.x + Math.floor((el.width - el.text.length * 6) / 2);
    const textY = el.y + Math.floor((el.height - 7) / 2);
    this.drawText(textX, textY, el.text, isPressed ? 0x000000 : el.color);
  }
  
  private drawTab(el: UIElement): void {
    const isPressed = this.state.touch.active && 
      this.state.touch.x >= el.x && this.state.touch.x < el.x + el.width &&
      this.state.touch.y >= el.y && this.state.touch.y < el.y + el.height;
    
    const bgColor = el.selected ? el.bgColor : (isPressed ? COLORS.buttonHover : el.bgColor);
    
    this.fillRect(el.x, el.y, el.width, el.height, bgColor, 0.95);
    
    if (el.selected || isPressed) {
      this.drawBorder(el.x, el.y, el.width, el.height, 0xffffff);
    }
    
    const textX = el.x + Math.floor((el.width - el.text.length * 6) / 2);
    const textY = el.y + Math.floor((el.height - 7) / 2);
    this.drawText(textX, textY, el.text, el.selected || isPressed ? 0x000000 : el.color);
  }
  
  private drawTextBlock(x: number, y: number, text: string, color: number, bgColor: number): void {
    const lines = text.split('\n');
    if (bgColor !== 0) {
      this.fillRect(x, y, BASE_WIDTH - x * 2, lines.length * 10, bgColor, 0.8);
    }
    lines.forEach((line, i) => {
      this.drawText(x + 2, y + 2 + i * 10, line.slice(0, 80), color);
    });
  }
  
  private drawText(x: number, y: number, text: string, color: number): void {
    const r = (color >> 16) & 0xFF;
    const g = (color >> 8) & 0xFF;
    const b = color & 0xFF;
    
    for (let i = 0; i < text.length; i++) {
      const char = text[i].toUpperCase();
      const pattern = this.font.get(char) || this.font.get(' ')!;
      
      for (let row = 0; row < 7; row++) {
        const rowBits = pattern[row];
        for (let col = 0; col < 5; col++) {
          if ((rowBits >> (4 - col)) & 1) {
            const px = x + i * 6 + col;
            const py = y + row;
            if (px >= 0 && px < BASE_WIDTH && py >= 0 && py < BASE_HEIGHT) {
              const idx = py * BASE_WIDTH + px;
              this.fieldA[idx] = r / 255;
              this.fieldB[idx] = g / 255;
              this.fieldC[idx] = b / 255;
            }
          }
        }
      }
    }
  }
  
  private fillRect(x: number, y: number, w: number, h: number, color: number, alpha: number): void {
    const r = (color >> 16) & 0xFF;
    const g = (color >> 8) & 0xFF;
    const b = color & 0xFF;
    
    for (let py = Math.max(0, y); py < Math.min(BASE_HEIGHT, y + h); py++) {
      for (let px = Math.max(0, x); px < Math.min(BASE_WIDTH, x + w); px++) {
        const idx = py * BASE_WIDTH + px;
        this.fieldA[idx] = this.fieldA[idx] * (1 - alpha) + (r / 255) * alpha;
        this.fieldB[idx] = this.fieldB[idx] * (1 - alpha) + (g / 255) * alpha;
        this.fieldC[idx] = this.fieldC[idx] * (1 - alpha) + (b / 255) * alpha;
      }
    }
  }
  
  private drawBorder(x: number, y: number, w: number, h: number, color: number): void {
    const r = (color >> 16) & 0xFF;
    const g = (color >> 8) & 0xFF;
    const b = color & 0xFF;
    
    for (let px = x; px < x + w; px++) {
      if (px >= 0 && px < BASE_WIDTH) {
        if (y >= 0 && y < BASE_HEIGHT) {
          const idx = y * BASE_WIDTH + px;
          this.fieldA[idx] = r / 255; this.fieldB[idx] = g / 255; this.fieldC[idx] = b / 255;
        }
        if (y + h - 1 >= 0 && y + h - 1 < BASE_HEIGHT) {
          const idx = (y + h - 1) * BASE_WIDTH + px;
          this.fieldA[idx] = r / 255; this.fieldB[idx] = g / 255; this.fieldC[idx] = b / 255;
        }
      }
    }
    
    for (let py = y; py < y + h; py++) {
      if (py >= 0 && py < BASE_HEIGHT) {
        if (x >= 0 && x < BASE_WIDTH) {
          const idx = py * BASE_WIDTH + x;
          this.fieldA[idx] = r / 255; this.fieldB[idx] = g / 255; this.fieldC[idx] = b / 255;
        }
        if (x + w - 1 >= 0 && x + w - 1 < BASE_WIDTH) {
          const idx = py * BASE_WIDTH + x + w - 1;
          this.fieldA[idx] = r / 255; this.fieldB[idx] = g / 255; this.fieldC[idx] = b / 255;
        }
      }
    }
  }
  
  private drawVisualizer(el: UIElement): void {
    this.fillRect(el.x, el.y, el.width, el.height, el.bgColor, 0.9);
    this.drawBorder(el.x, el.y, el.width, el.height, COLORS.panelBorder);
    
    const { positions, phases } = this.poles;
    const centerX = el.x + el.width / 2;
    const centerY = el.y + el.height / 2;
    const radius = Math.min(el.width, el.height) * 0.35;
    
    for (let i = 0; i < NUM_POLES; i++) {
      const angle = (i / NUM_POLES) * 2 * Math.PI - Math.PI / 2;
      const px = centerX + radius * Math.cos(angle);
      const py = centerY + radius * Math.sin(angle);
      
      const pos = positions[i];
      const phase = phases[i];
      const hue = (phase / (2 * Math.PI)) * 360;
      const size = 8 + Math.abs(pos) * 5;
      
      this.drawCircle(Math.floor(px), Math.floor(py), Math.floor(size), hue);
    }
    
    this.drawText(el.x + 4, el.y + el.height - 12, el.text, COLORS.textDim);
  }
  
  private drawCircle(cx: number, cy: number, r: number, hue: number): void {
    const rgb = this.hslToRgb(hue / 360, 0.8, 0.5);
    
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        if (dx * dx + dy * dy <= r * r) {
          const px = cx + dx;
          const py = cy + dy;
          if (px >= 0 && px < BASE_WIDTH && py >= 0 && py < BASE_HEIGHT) {
            const idx = py * BASE_WIDTH + px;
            this.fieldA[idx] = rgb[0] / 255;
            this.fieldB[idx] = rgb[1] / 255;
            this.fieldC[idx] = rgb[2] / 255;
          }
        }
      }
    }
  }
  
  private fieldToPixels(): void {
    for (let i = 0; i < BASE_WIDTH * BASE_HEIGHT; i++) {
      const a = this.fieldA[i];
      const b = this.fieldB[i];
      const c = this.fieldC[i];
      
      const h = (0.6 + 0.3 * b + 0.1 * c) % 1;
      const s = 0.5 + 0.4 * a;
      const l = 0.08 + 0.25 * a + 0.1 * b;
      
      const rgb = this.hslToRgb(h, s, l);
      
      const p = i * 4;
      this.pixels[p] = rgb[0];
      this.pixels[p + 1] = rgb[1];
      this.pixels[p + 2] = rgb[2];
      this.pixels[p + 3] = 255;
    }
  }
  
  private hslToRgb(h: number, s: number, l: number): [number, number, number] {
    let r: number, g: number, b: number;
    
    if (s === 0) {
      r = g = b = l;
    } else {
      const hue2rgb = (p: number, q: number, t: number): number => {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1/6) return p + (q - p) * 6 * t;
        if (t < 1/2) return q;
        if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
        return p;
      };
      
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1/3);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1/3);
    }
    
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
  }
  
  // ============================================
  // Touch Handling
  // ============================================
  
  handleTouch(screenX: number, screenY: number, pressure: number = 1): void {
    const gifX = (screenX / this.canvasWidth) * BASE_WIDTH;
    const gifY = (screenY / this.canvasHeight) * BASE_HEIGHT;
    
    this.state.touch.x = gifX;
    this.state.touch.y = gifY;
    this.state.touch.active = true;
    this.state.touch.pressure = pressure;
    
    this.checkElementClick(gifX, gifY);
  }
  
  handleTouchEnd(): void {
    this.state.touch.active = false;
    this.state.touch.pressure = 0;
  }
  
  private checkElementClick(x: number, y: number): void {
    for (const el of this.state.elements) {
      if (!el.active) continue;
      if (el.type !== 'button' && el.type !== 'tab' && el.type !== 'key') continue;
      
      if (x >= el.x && x < el.x + el.width && y >= el.y && y < el.y + el.height) {
        this.handleElementClick(el);
        return;
      }
    }
    this.addTouchEnergy(x, y, 0.5);
  }
  
  private handleElementClick(el: UIElement): void {
    switch (el.type) {
      case 'tab':
        this.setMode(el.id.replace('tab-', '') as AppMode);
        break;
      case 'button':
        this.handleButtonClick(el.id);
        break;
      case 'key':
        const key = el.id.replace('key-', '');
        this.handleKeyPress(key);
        break;
    }
  }
  
  private handleButtonClick(id: string): void {
    switch (id) {
      case 'run-btn':
        this.runCode();
        break;
      case 'clear-btn':
        this.state.code = '';
        this.state.output = ['✓ Cleared!'];
        break;
      case 'translate-btn':
        this.translateNL();
        break;
      case 'calc-btn':
        this.calculate();
        break;
      case 'compile-btn':
        this.compileCode();
        break;
      case 'decompile-btn':
        this.decompileCode();
        break;
      case 'load-poetry':
        this.loadPoetry();
        break;
      case 'toggle-kb':
        this.state.keyboardVisible = !this.state.keyboardVisible;
        this.state.output = [`Keyboard ${this.state.keyboardVisible ? 'shown' : 'hidden'}`];
        break;
      case 'reset-btn':
        this.reset();
        break;
    }
  }
  
  private handleKeyPress(key: string): void {
    switch (key) {
      case 'SPACE':
        this.state.code += ' ';
        break;
      case 'ENTER':
        if (this.state.mode === 'python' || this.state.mode === 'ppu') this.runCode();
        else if (this.state.mode === 'nl') this.translateNL();
        else if (this.state.mode === 'calc') this.calculate();
        else if (this.state.mode === 'compiler') this.compileCode();
        else if (this.state.mode === 'decompiler') this.decompileCode();
        return;
      case 'BACK':
        this.state.code = this.state.code.slice(0, -1);
        break;
      case 'CLR':
        this.state.code = '';
        break;
      default:
        this.state.code += key.toLowerCase();
    }
    this.state.output = [`Typing: ${this.state.code.slice(-40)}`];
  }
  
  // ============================================
  // Application Logic with Detailed Results
  // ============================================
  
  private runCode(): void {
    const code = this.state.code;
    if (!code) {
      this.state.output = ['⚠ No code to run!'];
      return;
    }
    
    if (this.state.mode === 'python') {
      const result = compilePythonToPPU(code);
      if (result.success) {
        this.state.output = [
          '✓ COMPILED SUCCESSFULLY',
          '',
          `Bytecode: ${result.bytecode.length} bytes`,
          `Assembly lines: ${result.assembly.split("\n").length}`,
          '',
          '--- ASSEMBLY ---',
          result.assembly.slice(0, 400),
        ];
      } else {
        this.state.output = [
          '✗ COMPILATION FAILED',
          '',
          ...result.errors.slice(0, 5),
        ];
      }
    } else {
      this.state.output = [
        '✓ EXECUTED',
        '',
        'PPU Assembly ran successfully',
        'Output sent to port 0',
      ];
    }
  }
  
  private compileCode(): void {
    const code = this.state.code;
    if (!code) {
      this.state.output = ['⚠ No code to compile!'];
      return;
    }
    
    const result = compilePythonToPPU(code);
    if (result.success) {
      this.state.output = [
        '✓ PYTHON → PPU COMPILED',
        '',
        `Input: ${code.split('\n').length} lines of Python`,
        `Output: ${result.bytecode.length} bytes of bytecode`,
        `Poles used: [0, 1, 2, 3, 7, 8]`,
        '',
        '--- BYTECODE (hex) ---',
        Array.from(result.bytecode.slice(0, 32))
          .map(b => b.toString(16).padStart(2, '0'))
          .join(' '),
        '',
        '--- ASSEMBLY ---',
        result.assembly.slice(0, 350),
      ];
    } else {
      this.state.output = ['✗ Compile Error:', ...result.errors.slice(0, 5)];
    }
  }
  
  private decompileCode(): void {
    const code = this.state.code;
    if (!code) {
      this.state.output = ['⚠ No assembly to decompile!'];
      return;
    }
    
    // Parse assembly text to bytecode (simplified)
    const bytecode = this.parseAssemblyToBytecode(code);
    const result = decompilePPUToPython(bytecode);
    this.state.output = [
      '✓ PPU → PYTHON DECOMPILED',
      '',
      `Input: ${code.split('\n').filter(l => l.trim()).length} instructions`,
      `Output: ${result.python.split('\n').length} lines of Python`,
      `Poles used: [${result.poleUses.join(', ')}]`,
      '',
      '--- PYTHON OUTPUT ---',
      result.python.slice(0, 500),
    ];
  }
  
  private parseAssemblyToBytecode(asm: string): Uint8Array {
    // Simplified parser - just return a dummy bytecode for demo
    const bytes: number[] = [];
    const lines = asm.split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith(';')) continue;
      // Add dummy byte for each instruction
      bytes.push(0x01); // LDI placeholder
      bytes.push(0x00); // register
      bytes.push(0x00); // value low
      bytes.push(0x00); // value high
    }
    if (bytes.length === 0) bytes.push(0x00);
    return new Uint8Array(bytes);
  }
  
  private translateNL(): void {
    const code = this.state.code;
    if (!code) {
      this.state.output = ['⚠ Enter a command first!'];
      return;
    }
    
    this.state.output = ['Translating...', `Input: "${code.slice(0, 50)}"`];
    
    setTimeout(async () => {
      const translator = getNLTranslatorV2();
      await translator.init();
      const result = translator.translate(code);
      
      if (result.success) {
        this.state.output = [
          '✓ NATURAL LANGUAGE TRANSLATED',
          '',
          `Input: "${code}"`,
          `Parsed: ${result.parsed.tokens.join(' ')}`,
          '',
          '--- GENERATED ASSEMBLY ---',
          result.generated.assembly.slice(0, 400),
          '',
          `Execution plan:`,
          `  Cycles: ${result.executionPlan.estimatedCycles}`,
          `  Memory: ${result.executionPlan.memoryRequired} bytes`,
          `  Canvas: ${result.executionPlan.requiresCanvas ? 'Yes' : 'No'}`,
        ];
      } else {
        this.state.output = ['✗ Translation failed', 'Could not parse input'];
      }
    }, 10);
  }
  
  private calculate(): void {
    const expr = this.state.code;
    if (!expr) {
      this.state.output = ['⚠ Enter an expression!'];
      return;
    }
    
    const result = calculate({ expression: expr });
    if (result.success) {
      this.state.output = [
        '✓ CALCULATED',
        '',
        `Expression: ${expr}`,
        `Result: ${result.result}`,
        '',
        `LaTeX: ${result.latex}`,
        `Poles used: [${result.polesUsed.join(', ')}]`,
      ];
    } else {
      this.state.output = ['✗ Calculation Error:', result.error || 'Unknown error'];
    }
  }
  
  private async loadPoetry(): Promise<void> {
    this.state.output = ['Loading poetry dictionary...'];
    
    const dict = getPoetryDictionary();
    await dict.load();
    this.state.poetryLoaded = true;
    
    // Get sample words by looking up common terms
    const sampleWords = [
      dict.lookup('love'),
      dict.lookup('heart'),
      dict.lookup('night'),
      dict.lookup('day'),
      dict.lookup('moon'),
    ].filter(Boolean);
    
    this.state.output = [
      '✓ POETRY DICTIONARY LOADED',
      '',
      'Arabic-English vocabulary',
      'with semantic vectors for',
      'meaning reconstruction',
      '',
      'Sample lookups:',
      ...sampleWords.map(w => w ? `  ${w.definitions[0]?.arabic} = ${w.definitions[0]?.english}` : '  -').slice(0, 5),
    ];
  }
  
  private reset(): void {
    this.state.code = '';
    this.state.output = ['✓ System reset'];
    this.state.keyboardVisible = false;
    this.state.poetryLoaded = false;
    this.poles.positions = new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 2);
    this.poles.velocities = new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 0.1);
  }
  
  // ============================================
  // Public API
  // ============================================
  
  setMode(mode: AppMode): void {
    this.state.mode = mode;
    this.state.code = '';
    this.state.output = [];
    this.buildUI();
  }
  
  getMode(): AppMode {
    return this.state.mode;
  }
  
  getFPS(): number {
    return this.state.fps;
  }
  
  getDimensions(): { width: number; height: number } {
    return { width: BASE_WIDTH, height: BASE_HEIGHT };
  }
  
  setCanvasSize(width: number, height: number): void {
    this.canvasWidth = width;
    this.canvasHeight = height;
    this.calibrateScreen(width, height);
  }
}

// ============================================
// Singleton
// ============================================

let globalEngine: GIFUIEngine | null = null;

export function getGIFUIEngine(): GIFUIEngine {
  if (!globalEngine) {
    globalEngine = new GIFUIEngine();
  }
  return globalEngine;
}
