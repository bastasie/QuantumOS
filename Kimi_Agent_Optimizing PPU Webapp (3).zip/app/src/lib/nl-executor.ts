/**
 * Natural Language Executor
 * Executes parsed natural language commands and shows live results
 */

import { parseNaturalLanguage, parseMultipleCommands, type ParsedCommand } from './matrix-grammar';
import { GIFLifeField } from './giflife-field';
import { createPPUState, pulsePPU } from './ppu-core';

// ============================================
// Execution Context
// ============================================

export interface ExecutionContext {
  variables: Map<string, number | string>;
  canvas?: HTMLCanvasElement;
  ctx?: CanvasRenderingContext2D;
  giflife?: GIFLifeField;
  ppu: ReturnType<typeof createPPUState>;
  output: string[];
  graphics: GraphicObject[];
}

export interface GraphicObject {
  id: string;
  type: 'circle' | 'square' | 'triangle' | 'line' | 'point' | 'text';
  x: number;
  y: number;
  color: string;
  size: number;
  properties: Record<string, unknown>;
}

export interface ExecutionResult {
  success: boolean;
  command: ParsedCommand;
  output: string[];
  graphics: GraphicObject[];
  variables: Record<string, number | string>;
  error?: string;
}

// ============================================
// Command Handlers
// ============================================

type CommandHandler = (cmd: ParsedCommand, ctx: ExecutionContext) => ExecutionResult;

const COMMAND_HANDLERS: Record<string, CommandHandler> = {
  // Drawing commands
  'draw': handleDraw,
  'paint': handleDraw,
  'render': handleDraw,
  'sketch': handleDraw,
  
  // Creation commands
  'create': handleCreate,
  'make': handleCreate,
  'build': handleCreate,
  
  // Movement commands
  'move': handleMove,
  'shift': handleMove,
  'translate': handleMove,
  
  // Animation commands
  'animate': handleAnimate,
  'rotate': handleRotate,
  'spin': handleRotate,
  
  // Math commands
  'calculate': handleCalculate,
  'compute': handleCalculate,
  'solve': handleCalculate,
  'add': handleCalculate,
  'subtract': handleCalculate,
  'multiply': handleCalculate,
  'divide': handleCalculate,
  
  // Output commands
  'print': handlePrint,
  'show': handlePrint,
  'display': handlePrint,
  'output': handlePrint,
  
  // Control commands
  'set': handleSet,
  'change': handleSet,
  
  // Query commands
  'get': handleGet,
  'find': handleGet,
  
  // Clear/reset commands
  'clear': handleClear,
  'reset': handleClear,
  'delete': handleClear,
  'remove': handleClear,
};

// ============================================
// Handler Implementations
// ============================================

function handleDraw(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const { output } = cmd;
  const shape = (output.parameters.shape as string) || 'circle';
  const color = (output.parameters.color as string) || 'blue';
  const size = (output.parameters.value as number) || 50;
  const x = (output.parameters.value2 as number) || 256;
  const y = (output.parameters.value3 as number) || 256;
  
  const graphic: GraphicObject = {
    id: `gfx_${Date.now()}`,
    type: shape as GraphicObject['type'],
    x,
    y,
    color: colorToHex(color),
    size,
    properties: { created: Date.now() },
  };
  
  ctx.graphics.push(graphic);
  
  // Draw on canvas if available
  if (ctx.ctx) {
    drawShape(ctx.ctx, graphic);
  }
  
  // Also splash on GIFLife field
  if (ctx.giflife) {
    ctx.giflife.splash(x, y, size, 1);
  }
  
  return {
    success: true,
    command: cmd,
    output: [`Drew ${shape} at (${x}, ${y}) with color ${color} and size ${size}`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleCreate(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const object = cmd.output.object || 'object';
  const name = cmd.output.subject || `obj_${Date.now()}`;
  
  ctx.variables.set(name, object);
  
  return {
    success: true,
    command: cmd,
    output: [`Created ${object} named "${name}"`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleMove(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const object = cmd.output.object;
  const dx = (cmd.output.parameters.value as number) || 10;
  const dy = (cmd.output.parameters.value2 as number) || 0;
  
  // Find and move graphic object
  const graphic = ctx.graphics.find(g => g.id === object);
  if (graphic) {
    graphic.x += dx;
    graphic.y += dy;
    
    return {
      success: true,
      command: cmd,
      output: [`Moved ${object} by (${dx}, ${dy}) to (${graphic.x}, ${graphic.y})`],
      graphics: [...ctx.graphics],
      variables: Object.fromEntries(ctx.variables),
    };
  }
  
  return {
    success: false,
    command: cmd,
    output: [],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
    error: `Object "${object}" not found`,
  };
}

function handleAnimate(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const object = cmd.output.object;
  const duration = (cmd.output.parameters.value as number) || 1000;
  
  return {
    success: true,
    command: cmd,
    output: [`Started animation of ${object} for ${duration}ms`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleRotate(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const angle = (cmd.output.parameters.value as number) || 45;
  
  // Pulse PPU for rotation effect
  pulsePPU(ctx.ppu, angle / 360);
  
  return {
    success: true,
    command: cmd,
    output: [`Rotated by ${angle} degrees`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleCalculate(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const action = cmd.output.action;
  const a = (cmd.output.parameters.value as number) || 0;
  const b = (cmd.output.parameters.value2 as number) || 0;
  
  let result = 0;
  let operation = '';
  
  switch (action) {
    case 'add':
    case 'sum':
      result = a + b;
      operation = '+';
      break;
    case 'subtract':
    case 'sub':
      result = a - b;
      operation = '-';
      break;
    case 'multiply':
    case 'mul':
    case 'times':
      result = a * b;
      operation = '×';
      break;
    case 'divide':
    case 'div':
      result = b !== 0 ? a / b : 0;
      operation = '÷';
      break;
    default:
      result = a;
      operation = '=';
  }
  
  // Store result
  const varName = `result_${Date.now()}`;
  ctx.variables.set(varName, result);
  
  return {
    success: true,
    command: cmd,
    output: [`${a} ${operation} ${b} = ${result}`, `Stored in variable "${varName}"`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handlePrint(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const message = cmd.output.object || cmd.input;
  const output = [`${message}`];
  
  return {
    success: true,
    command: cmd,
    output,
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleSet(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const property = cmd.output.object || 'value';
  const value = cmd.output.parameters.value || cmd.output.parameters.color;
  
  ctx.variables.set(property, value as string | number);
  
  // Handle PPU coherence setting
  if (property === 'coherence' && typeof value === 'number') {
    ctx.ppu.coherence = Math.max(0, Math.min(1, value / 100));
  }
  
  return {
    success: true,
    command: cmd,
    output: [`Set ${property} = ${value}`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleGet(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const property = cmd.output.object || 'unknown';
  const value = ctx.variables.get(property);
  
  return {
    success: true,
    command: cmd,
    output: [`${property} = ${value !== undefined ? value : 'undefined'}`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

function handleClear(cmd: ParsedCommand, ctx: ExecutionContext): ExecutionResult {
  const target = cmd.output.object;
  
  if (target === 'all' || target === 'everything') {
    ctx.graphics = [];
    ctx.variables.clear();
    ctx.output = [];
    
    // Clear canvas
    if (ctx.ctx && ctx.canvas) {
      ctx.ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    }
    
    return {
      success: true,
      command: cmd,
      output: ['Cleared all graphics and variables'],
      graphics: [],
      variables: {},
    };
  }
  
  // Remove specific graphic
  ctx.graphics = ctx.graphics.filter(g => g.id !== target);
  
  return {
    success: true,
    command: cmd,
    output: [`Removed ${target}`],
    graphics: [...ctx.graphics],
    variables: Object.fromEntries(ctx.variables),
  };
}

// ============================================
// Helper Functions
// ============================================

function colorToHex(color: string): string {
  const colors: Record<string, string> = {
    'red': '#FF0000', 'blue': '#0000FF', 'green': '#00FF00',
    'yellow': '#FFFF00', 'orange': '#FFA500', 'purple': '#800080',
    'pink': '#FFC0CB', 'brown': '#8B4513', 'black': '#000000',
    'white': '#FFFFFF', 'gray': '#808080', 'cyan': '#00FFFF',
    'magenta': '#FF00FF', 'lime': '#00FF00', 'navy': '#000080',
    'teal': '#008080',
  };
  return colors[color.toLowerCase()] || color;
}

function drawShape(ctx: CanvasRenderingContext2D, graphic: GraphicObject): void {
  ctx.fillStyle = graphic.color;
  ctx.strokeStyle = graphic.color;
  
  switch (graphic.type) {
    case 'circle':
      ctx.beginPath();
      ctx.arc(graphic.x, graphic.y, graphic.size, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'square':
      ctx.fillRect(
        graphic.x - graphic.size / 2,
        graphic.y - graphic.size / 2,
        graphic.size,
        graphic.size
      );
      break;
    case 'triangle':
      ctx.beginPath();
      ctx.moveTo(graphic.x, graphic.y - graphic.size);
      ctx.lineTo(graphic.x - graphic.size, graphic.y + graphic.size);
      ctx.lineTo(graphic.x + graphic.size, graphic.y + graphic.size);
      ctx.closePath();
      ctx.fill();
      break;
    case 'line':
      ctx.beginPath();
      ctx.moveTo(graphic.x, graphic.y);
      ctx.lineTo(
        graphic.x + (graphic.properties.dx as number || 100),
        graphic.y + (graphic.properties.dy as number || 0)
      );
      ctx.stroke();
      break;
    case 'point':
      ctx.fillRect(graphic.x - 1, graphic.y - 1, 3, 3);
      break;
    case 'text':
      ctx.font = `${graphic.size}px monospace`;
      ctx.fillText((graphic.properties.text as string) || '', graphic.x, graphic.y);
      break;
  }
}

// ============================================
// Main Executor
// ============================================

export function createExecutionContext(canvas?: HTMLCanvasElement): ExecutionContext {
  const ctx = canvas?.getContext('2d') || undefined;
  
  return {
    variables: new Map(),
    canvas,
    ctx,
    ppu: createPPUState(),
    output: [],
    graphics: [],
  };
}

export function executeCommand(
  input: string,
  context: ExecutionContext
): ExecutionResult {
  // Parse the command
  const parsed = parseNaturalLanguage(input);
  
  // Find handler
  const handler = COMMAND_HANDLERS[parsed.output.action];
  
  if (handler) {
    return handler(parsed, context);
  }
  
  // Unknown command - try generic handler
  return {
    success: true,
    command: parsed,
    output: [`Parsed: "${parsed.input}" as ${parsed.structure} structure`],
    graphics: [...context.graphics],
    variables: Object.fromEntries(context.variables),
  };
}

export function executeMultiple(
  input: string,
  context: ExecutionContext
): ExecutionResult[] {
  const commands = parseMultipleCommands(input);
  const results: ExecutionResult[] = [];
  
  for (const cmd of commands) {
    const handler = COMMAND_HANDLERS[cmd.output.action];
    if (handler) {
      results.push(handler(cmd, context));
    } else {
      results.push({
        success: true,
        command: cmd,
        output: [`Parsed: "${cmd.input}"`],
        graphics: [...context.graphics],
        variables: Object.fromEntries(context.variables),
      });
    }
  }
  
  return results;
}

// ============================================
// Batch Execution with Visualization
// ============================================

export interface BatchExecutionResult {
  inputs: string[];
  results: ExecutionResult[];
  finalContext: ExecutionContext;
  summary: {
    totalCommands: number;
    successful: number;
    failed: number;
    graphicsCreated: number;
    variablesSet: number;
  };
}

export function executeBatch(
  inputs: string[],
  canvas?: HTMLCanvasElement
): BatchExecutionResult {
  const context = createExecutionContext(canvas);
  const results: ExecutionResult[] = [];
  
  for (const input of inputs) {
    const result = executeCommand(input, context);
    results.push(result);
    
    // Update context output
    context.output.push(...result.output);
  }
  
  const successful = results.filter(r => r.success).length;
  
  return {
    inputs,
    results,
    finalContext: context,
    summary: {
      totalCommands: inputs.length,
      successful,
      failed: inputs.length - successful,
      graphicsCreated: context.graphics.length,
      variablesSet: context.variables.size,
    },
  };
}
