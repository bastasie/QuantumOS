/**
 * PPU (Prime Processing Unit) Core Engine
 * Implements the 12-pole harmonic oscillator system and prime-domain computation
 * Based on "The Prime Domain Machine: Analog Computation and Memory via Primorial Logarithmic Circuits"
 */

import type { PPUState, PrimeDomainValue } from '@/types';

// ============================================
// Constants
// ============================================

export const NUM_POLES = 12;
export const DEFAULT_COHERENCE = 0.78;
export const DEFAULT_SMOOTH = 0.22;
export const DEFAULT_ENTROPY = 0.12;
export const DEFAULT_TEMPERATURE = 0.90;

// First 16 primes for prime-domain computation
export const PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53];

// Unit voltage/current scaling
export const VUNIT = 0.5; // Volts per prime unit
export const IUNIT = 0.001; // 1 mA reference

// ============================================
// PPU State Management
// ============================================

export function createPPUState(): PPUState {
  return {
    coherence: DEFAULT_COHERENCE,
    smooth: DEFAULT_SMOOTH,
    entropy: DEFAULT_ENTROPY,
    temperature: DEFAULT_TEMPERATURE,
    load: 0.0,
    poles: new Float32Array(NUM_POLES),
    vels: new Float32Array(NUM_POLES),
  };
}

export function stepPPU(state: PPUState, dt: number): void {
  const { poles, vels, coherence } = state;
  
  // Update each pole as damped harmonic oscillator
  for (let i = 0; i < NUM_POLES; i++) {
    const w = 1.4 + 0.13 * i;  // frequency
    const damp = 0.08 + 0.004 * i;  // damping
    const drive = 0.10 * Math.sin(Date.now() * 0.001 * (1 + i * 0.07));
    
    // Acceleration: -ω²x - γv + drive - coherence coupling
    const acc = -w * w * poles[i] - damp * vels[i] + drive - 0.20 * (1 - coherence) * poles[i];
    
    vels[i] += acc * dt;
    poles[i] += vels[i] * dt;
  }
  
  // Calculate entropy from pole energies
  let E = 0;
  for (let i = 0; i < NUM_POLES; i++) {
    E += poles[i] * poles[i] + 0.18 * vels[i] * vels[i];
  }
  state.entropy = Math.min(Math.max(E / NUM_POLES, 0), 1);
  
  // Update smooth based on coherence
  const targetSmooth = 0.10 + 0.60 * (1 - coherence);
  state.smooth = state.smooth + (targetSmooth - state.smooth) * 0.05;
  state.smooth = Math.min(Math.max(state.smooth, 0.05), 0.85);
  
  // Update temperature
  const targetTemp = 0.55 + 0.75 * coherence;
  state.temperature = state.temperature + (targetTemp - state.temperature) * 0.03;
  state.temperature = Math.min(Math.max(state.temperature, 0.2), 1.6);
  
  // Decay load
  state.load = Math.min(Math.max(state.load * 0.94, 0), 1);
}

export function pulsePPU(state: PPUState, strength: number = 0.9): void {
  for (let i = 0; i < NUM_POLES; i++) {
    state.vels[i] += (Math.random() - 0.5) * 2 * strength;
  }
  state.load = Math.min(state.load + 0.3, 1);
}

export function setCoherence(state: PPUState, value: number): void {
  state.coherence = Math.min(Math.max(value, 0), 1);
}

// ============================================
// Prime Domain Computation
// ============================================

/**
 * Factorize a number into primes
 * Returns Map of prime -> exponent
 */
export function factorize(n: number): Map<number, number> {
  const factors = new Map<number, number>();
  let remaining = Math.abs(Math.floor(n));
  
  if (remaining <= 1) return factors;
  
  for (const prime of PRIMES) {
    if (prime * prime > remaining) break;
    let exp = 0;
    while (remaining % prime === 0) {
      exp++;
      remaining /= prime;
    }
    if (exp > 0) {
      factors.set(prime, exp);
    }
  }
  
  if (remaining > 1) {
    factors.set(remaining, 1);
  }
  
  return factors;
}

/**
 * Convert number to prime-exponent vector
 */
export function toPrimeVector(n: number, numPrimes: number = 16): number[] {
  const factors = factorize(n);
  const vector: number[] = new Array(numPrimes).fill(0);
  
  for (let i = 0; i < Math.min(numPrimes, PRIMES.length); i++) {
    vector[i] = factors.get(PRIMES[i]) || 0;
  }
  
  return vector;
}

/**
 * Convert prime-exponent vector back to number
 */
export function fromPrimeVector(vector: number[]): number {
  let result = 1;
  for (let i = 0; i < Math.min(vector.length, PRIMES.length); i++) {
    if (vector[i] > 0) {
      result *= Math.pow(PRIMES[i], vector[i]);
    }
  }
  return result;
}

/**
 * Log-domain multiplication: log(a*b) = log(a) + log(b)
 * Simulates analog log-domain multiplier from the PPU paper
 */
export function logDomainMultiply(a: number, b: number): number {
  if (a <= 0 || b <= 0) return 0;
  
  const logA = Math.log(a);
  const logB = Math.log(b);
  const logSum = logA + logB;
  
  return Math.exp(logSum);
}

/**
 * Analog prime multiplication using log-domain
 * Simulates: Vout = (p1 * p2) * Vunit
 */
export function analogPrimeMultiply(p1: number, p2: number): PrimeDomainValue {
  const product = p1 * p2;
  return {
    prime: product,
    exponent: 1,
    analogValue: product * VUNIT,
  };
}

/**
 * Generate analog voltage for a prime
 * Vp = p * Vunit
 */
export function primeToVoltage(prime: number): number {
  return prime * VUNIT;
}

/**
 * Convert voltage back to prime (with tolerance)
 */
export function voltageToPrime(voltage: number, tolerance: number = 0.015): number | null {
  const p = voltage / VUNIT;
  const nearestPrime = PRIMES.find(prime => Math.abs(prime - p) / p < tolerance);
  return nearestPrime || null;
}

// ============================================
// Prime Memory Compression (from PPU paper)
// ============================================

export interface CompressedPrimeVector {
  isSparse: boolean;
  fullVector?: number[];
  sparsePairs?: Array<[number, number]>; // [index, exponent]
  relationshipFlag: boolean;
}

/**
 * Compress a prime-exponent vector using sparse encoding
 * Based on the two-stage memory architecture from the PPU paper
 */
export function compressPrimeVector(
  vector: number[],
  threshold: number = 4
): CompressedPrimeVector {
  const nonzeroIndices: Array<[number, number]> = [];
  
  for (let i = 0; i < vector.length; i++) {
    if (vector[i] !== 0) {
      nonzeroIndices.push([i, vector[i]]);
    }
  }
  
  const isSparse = nonzeroIndices.length <= threshold;
  
  if (isSparse) {
    return {
      isSparse: true,
      sparsePairs: nonzeroIndices,
      relationshipFlag: false,
    };
  } else {
    return {
      isSparse: false,
      fullVector: [...vector],
      relationshipFlag: false,
    };
  }
}

/**
 * Decompress a prime-exponent vector
 */
export function decompressPrimeVector(compressed: CompressedPrimeVector, numPrimes: number = 16): number[] {
  if (!compressed.isSparse || !compressed.sparsePairs) {
    return compressed.fullVector || new Array(numPrimes).fill(0);
  }
  
  const vector = new Array(numPrimes).fill(0);
  for (const [index, exponent] of compressed.sparsePairs) {
    if (index < numPrimes) {
      vector[index] = exponent;
    }
  }
  return vector;
}

// ============================================
// PPU Pole Visualization
// ============================================

export interface PoleVisualization {
  amplitudes: number[];
  phases: number[];
  energies: number[];
  dominantMode: number;
}

export function getPoleVisualization(state: PPUState): PoleVisualization {
  const amplitudes: number[] = [];
  const phases: number[] = [];
  const energies: number[] = [];
  
  let maxEnergy = 0;
  let dominantMode = 0;
  
  for (let i = 0; i < NUM_POLES; i++) {
    const amp = state.poles[i];
    const vel = state.vels[i];
    const energy = amp * amp + 0.18 * vel * vel;
    
    amplitudes.push(amp);
    phases.push(Math.atan2(vel, amp));
    energies.push(energy);
    
    if (energy > maxEnergy) {
      maxEnergy = energy;
      dominantMode = i;
    }
  }
  
  return { amplitudes, phases, energies, dominantMode };
}

// ============================================
// Utility Functions
// ============================================

export function clamp(x: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, x));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/**
 * Calculate PPU-modulated reaction-diffusion parameters
 */
export function getRDParameters(ppu: PPUState): {
  feed: number;
  kill: number;
  diffusionA: number;
  diffusionB: number;
  diffusionC: number;
} {
  return {
    feed: 0.032 + 0.018 * (1 - ppu.coherence) + 0.010 * ppu.load,
    kill: 0.053 + 0.020 * ppu.entropy + 0.010 * (1 - ppu.coherence),
    diffusionA: 1.0,
    diffusionB: 0.55,
    diffusionC: 0.35,
  };
}
