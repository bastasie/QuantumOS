/**
 * Trigonometric Set Theory - Spectral Operator Calculus
 * Based on "Trigonometric Set Theory and the Quantum Zero-Shot Intelligence"
 * Implements Boolean gates, Walsh characters, and spectral operators
 */

import type { BooleanGate, Complex, WalshCharacter } from '@/types';

// ============================================
// Complex Number Utilities
// ============================================

export function complex(re: number, im: number = 0): Complex {
  return { re, im };
}

export function addComplex(a: Complex, b: Complex): Complex {
  return { re: a.re + b.re, im: a.im + b.im };
}

export function mulComplex(a: Complex, b: Complex): Complex {
  return {
    re: a.re * b.re - a.im * b.im,
    im: a.re * b.im + a.im * b.re,
  };
}

export function expComplex(theta: number): Complex {
  return { re: Math.cos(theta), im: Math.sin(theta) };
}

export function magnitudeComplex(c: Complex): number {
  return Math.sqrt(c.re * c.re + c.im * c.im);
}

// ============================================
// Boolean Trigonometric Encoding
// ============================================

/**
 * Sign-lift: s(x) = cos(πx)
 * Maps {0, 1} → {+1, -1}
 */
export function signLift(x: 0 | 1): number {
  return Math.cos(Math.PI * x);
}

/**
 * Inverse: x(s) = (1 - s) / 2
 * Maps {+1, -1} → {0, 1}
 */
export function signLiftInverse(s: number): 0 | 1 {
  return Math.round((1 - s) / 2) as 0 | 1;
}

// ============================================
// Boolean Gates (Trigonometric Forms)
// ============================================

export const TRIG_GATES: Record<string, BooleanGate> = {
  NOT: {
    name: 'NOT',
    trigExpression: '(1 + cos(πx)) / 2',
    evaluate: ([x]) => !x,
    spectralForm: (x) => (1 + Math.cos(Math.PI * x)) / 2,
  },
  
  AND: {
    name: 'AND',
    trigExpression: '(1 - cos(πx) - cos(πy) + cos(π(x+y))) / 4',
    evaluate: ([x, y]) => x && y,
    spectralForm: (x, y = 0) => (1 - Math.cos(Math.PI * x) - Math.cos(Math.PI * y) + Math.cos(Math.PI * (x + y))) / 4,
  },
  
  OR: {
    name: 'OR',
    trigExpression: '(3 - cos(πx) - cos(πy) - cos(π(x+y))) / 4',
    evaluate: ([x, y]) => x || y,
    spectralForm: (x, y = 0) => (3 - Math.cos(Math.PI * x) - Math.cos(Math.PI * y) - Math.cos(Math.PI * (x + y))) / 4,
  },
  
  XOR: {
    name: 'XOR',
    trigExpression: '(1 - cos(π(x+y))) / 2',
    evaluate: ([x, y]) => x !== y,
    spectralForm: (x, y = 0) => (1 - Math.cos(Math.PI * (x + y))) / 2,
  },
  
  NAND: {
    name: 'NAND',
    trigExpression: '1 - AND(x,y)',
    evaluate: ([x, y]) => !(x && y),
    spectralForm: (x, y = 0) => 1 - (1 - Math.cos(Math.PI * x) - Math.cos(Math.PI * y) + Math.cos(Math.PI * (x + y))) / 4,
  },
  
  NOR: {
    name: 'NOR',
    trigExpression: '1 - OR(x,y)',
    evaluate: ([x, y]) => !(x || y),
    spectralForm: (x, y = 0) => 1 - (3 - Math.cos(Math.PI * x) - Math.cos(Math.PI * y) - Math.cos(Math.PI * (x + y))) / 4,
  },
  
  XNOR: {
    name: 'XNOR',
    trigExpression: '(1 + cos(π(x+y))) / 2',
    evaluate: ([x, y]) => x === y,
    spectralForm: (x, y = 0) => (1 + Math.cos(Math.PI * (x + y))) / 2,
  },
};

/**
 * Evaluate a Boolean gate using trigonometric encoding
 */
export function evaluateTrigGate(
  gateName: string,
  inputs: [number, number?]
): number {
  const gate = TRIG_GATES[gateName];
  if (!gate) throw new Error(`Unknown gate: ${gateName}`);
  return gate.spectralForm(inputs[0], inputs[1]);
}

// ============================================
// Walsh Characters (Fourier on Boolean domain)
// ============================================

/**
 * Generate Walsh characters for n-bit Boolean space
 * χ_S(x) = ∏_{i∈S} (-1)^{x_i} = ∏_{i∈S} cos(πx_i)
 */
export function generateWalshCharacters(n: number): WalshCharacter[] {
  const characters: WalshCharacter[] = [];
  const numSubsets = 1 << n; // 2^n subsets
  
  for (let s = 0; s < numSubsets; s++) {
    const subset: number[] = [];
    for (let i = 0; i < n; i++) {
      if (s & (1 << i)) {
        subset.push(i);
      }
    }
    
    characters.push({
      subset,
      value: (x: boolean[]) => {
        let prod = 1;
        for (const i of subset) {
          prod *= x[i] ? -1 : 1;
        }
        return prod;
      },
    });
  }
  
  return characters;
}

/**
 * Compute Fourier coefficient for a Boolean function
 * f̂(S) = 2^{-n} Σ_x f(x) χ_S(x)
 */
export function computeFourierCoefficient(
  f: (x: boolean[]) => number,
  subset: number[],
  n: number
): number {
  let sum = 0;
  const numInputs = 1 << n;
  
  for (let x = 0; x < numInputs; x++) {
    const inputs: boolean[] = [];
    for (let i = 0; i < n; i++) {
      inputs.push(!!(x & (1 << i)));
    }
    
    let chi = 1;
    for (const i of subset) {
      chi *= inputs[i] ? -1 : 1;
    }
    
    sum += f(inputs) * chi;
  }
  
  return sum / numInputs;
}

/**
 * Compute full Fourier expansion of a Boolean function
 */
export function fourierExpansion(
  f: (x: boolean[]) => number,
  n: number
): Map<string, number> {
  const coefficients = new Map<string, number>();
  const characters = generateWalshCharacters(n);
  
  for (const char of characters) {
    const coeff = computeFourierCoefficient(f, char.subset, n);
    const key = char.subset.length === 0 ? '∅' : `{${char.subset.join(',')}}`;
    coefficients.set(key, coeff);
  }
  
  return coefficients;
}

// ============================================
// Spectral Operators
// ============================================

/**
 * Spectral derivative operator: D̂f(k) = i2πk f̂(k)
 */
export function spectralDerivative(coefficients: Complex[], k: number): Complex {
  const factor = 2 * Math.PI * k;
  return { re: -factor * coefficients[k]?.im || 0, im: factor * coefficients[k]?.re || 0 };
}

/**
 * Spectral n-th derivative: D̂^n f(k) = (i2πk)^n f̂(k)
 */
export function spectralDerivativeN(
  coefficients: Complex[],
  k: number,
  n: number
): Complex {
  const factor = Math.pow(2 * Math.PI * k, n);
  const phase = n * Math.PI / 2;
  return {
    re: factor * (Math.cos(phase) * coefficients[k]?.re - Math.sin(phase) * coefficients[k]?.im),
    im: factor * (Math.sin(phase) * coefficients[k]?.re + Math.cos(phase) * coefficients[k]?.im),
  };
}

/**
 * Spectral integration (inverse of derivative)
 * Îf(k) = f̂(k) / (i2πk) for k ≠ 0
 */
export function spectralIntegrate(coefficients: Complex[], k: number): Complex {
  if (k === 0) return { re: 0, im: 0 };
  const factor = 1 / (2 * Math.PI * k);
  return { re: factor * coefficients[k]?.im, im: -factor * coefficients[k]?.re };
}

/**
 * Convolution in spectral domain: (f * g)̂(k) = f̂(k) ĝ(k)
 */
export function spectralConvolution(
  fCoeffs: Complex[],
  gCoeffs: Complex[],
  k: number
): Complex {
  return mulComplex(fCoeffs[k] || { re: 0, im: 0 }, gCoeffs[k] || { re: 0, im: 0 });
}

// ============================================
// Local Trigonometric Surrogates
// ============================================

/**
 * Local derivative surrogate: D̃f(x) = -π tan(πx) f(x)
 * Exact for f(x) = cos(πx)
 */
export function localDerivativeSurrogate(f: number, x: number): number {
  const cosPx = Math.cos(Math.PI * x);
  if (Math.abs(cosPx) < 1e-10) return 0; // Avoid pole
  return -Math.PI * Math.tan(Math.PI * x) * f;
}

/**
 * Second derivative surrogate: D̃^(2)f(x) = -π² sec²(πx) f(x)
 */
export function localSecondDerivativeSurrogate(f: number, x: number): number {
  const cosPx = Math.cos(Math.PI * x);
  if (Math.abs(cosPx) < 1e-10) return 0;
  return -Math.PI * Math.PI / (cosPx * cosPx) * f;
}

// ============================================
// BAZ/Bas Layer (Invertibility)
// ============================================

/**
 * BAZ normalization function
 * Ensures S(k; T) = BAZ(k; T) · B(k; T) ≠ 0
 */
export function bazNormalize(
  symbol: Complex,
  temperature: number
): Complex {
  const mag = magnitudeComplex(symbol);
  if (mag < 1e-10) {
    // Add small regularization
    return { re: temperature * 1e-6, im: 0 };
  }
  return symbol;
}

/**
 * Check if symbol is invertible
 */
export function isInvertible(symbol: Complex, threshold: number = 1e-10): boolean {
  return magnitudeComplex(symbol) > threshold;
}

// ============================================
// Zero-Shot Learning (Spectral Identification)
// ============================================

/**
 * Learn operator coefficients via projection
 * θ̂_k ≈ (1/N) Σ_i y_i φ_k(x_i)
 */
export function zeroShotLearn(
  xData: number[][],
  yData: number[],
  basisFunctions: ((x: number[]) => number)[]
): number[] {
  const N = xData.length;
  const coefficients: number[] = new Array(basisFunctions.length).fill(0);
  
  for (let k = 0; k < basisFunctions.length; k++) {
    let sum = 0;
    for (let i = 0; i < N; i++) {
      sum += yData[i] * basisFunctions[k](xData[i]);
    }
    coefficients[k] = sum / N;
  }
  
  return coefficients;
}

/**
 * Fourier basis functions for periodic domains
 */
export function fourierBasis(k: number): (x: number[]) => number {
  return (x: number[]) => {
    const dot = x.reduce((sum, xi, i) => sum + xi * (i + 1), 0);
    return Math.cos(2 * Math.PI * k * dot);
  };
}

/**
 * Walsh basis functions for Boolean domains
 */
export function walshBasis(subset: number[]): (x: boolean[]) => number {
  return (x: boolean[]) => {
    let prod = 1;
    for (const i of subset) {
      prod *= x[i] ? -1 : 1;
    }
    return prod;
  };
}

// ============================================
// Visualization Helpers
// ============================================

export interface GateVisualization {
  name: string;
  truthTable: Array<[boolean[], boolean]>;
  spectralValues: number[][];
  fourierCoefficients: Map<string, number>;
}

/**
 * Generate visualization data for a Boolean gate
 */
export function generateGateVisualization(gateName: string): GateVisualization {
  const gate = TRIG_GATES[gateName];
  if (!gate) throw new Error(`Unknown gate: ${gateName}`);
  
  const truthTable: Array<[boolean[], boolean]> = [];
  const spectralValues: number[][] = [];
  
  // Generate 2D truth table and spectral values
  for (let x = 0; x <= 1; x += 0.1) {
    const row: number[] = [];
    for (let y = 0; y <= 1; y += 0.1) {
      const val = gate.spectralForm(x, y);
      row.push(val);
      
      // Add to truth table at Boolean corners
      if (Math.abs(x - Math.round(x)) < 0.05 && Math.abs(y - Math.round(y)) < 0.05) {
        const xBool = Math.round(x) === 1;
        const yBool = Math.round(y) === 1;
        truthTable.push([[xBool, yBool], gate.evaluate([xBool, yBool])]);
      }
    }
    spectralValues.push(row);
  }
  
  // Compute Fourier coefficients
  const f = (inputs: boolean[]) => gate.evaluate(inputs) ? 1 : 0;
  const fourierCoefficients = fourierExpansion(f, 2);
  
  return {
    name: gateName,
    truthTable,
    spectralValues,
    fourierCoefficients,
  };
}

// ============================================
// Parseval's Identity Verification
// ============================================

/**
 * Verify Parseval's identity: Σ_S f̂(S)² = 2^{-n} Σ_x f(x)²
 */
export function verifyParseval(
  f: (x: boolean[]) => number,
  n: number
): { lhs: number; rhs: number; error: number } {
  const fourierCoeffs = fourierExpansion(f, n);
  
  let lhs = 0;
  for (const coeff of fourierCoeffs.values()) {
    lhs += coeff * coeff;
  }
  
  let rhs = 0;
  const numInputs = 1 << n;
  for (let x = 0; x < numInputs; x++) {
    const inputs: boolean[] = [];
    for (let i = 0; i < n; i++) {
      inputs.push(!!(x & (1 << i)));
    }
    const fx = f(inputs);
    rhs += fx * fx;
  }
  rhs /= numInputs;
  
  return { lhs, rhs, error: Math.abs(lhs - rhs) };
}
