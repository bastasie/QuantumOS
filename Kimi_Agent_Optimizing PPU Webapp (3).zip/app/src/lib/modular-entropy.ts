/**
 * Modular Entropy Framework
 * Based on "Modular Entropy Analysis and Applications in Theoretical Physics"
 * Implements entropy with modular operators and feedback-controlled systems
 */

import type { EntropyState, FeedbackParameters, CoolingProfile } from '@/types';

// ============================================
// Physical Constants
// ============================================

export const K_BOLTZMANN = 1.380649e-23; // J/K
export const H_BAR = 1.054571817e-34; // J·s

// ============================================
// Modular Entropy Calculations
// ============================================

/**
 * Calculate modified energy term with modular operator
 * δE_i = -k_B T ln[cos(π ln E_i / (2E_i))]
 */
export function modifiedEnergy(
  energy: number,
  temperature: number
): number {
  if (energy <= 0 || temperature <= 0) return 0;
  
  const arg = (Math.log(energy) * Math.PI) / (2 * energy);
  const cosVal = Math.cos(arg);
  
  // Ensure positive argument for log
  if (cosVal <= 0) return 0;
  
  return -K_BOLTZMANN * temperature * Math.log(cosVal);
}

/**
 * Series expansion approximation for small ln(E)/(πE)
 * cos(z) ≈ 1 - z²/2 for small z
 */
export function modifiedEnergyApproximate(
  energy: number,
  temperature: number
): number {
  if (energy <= 0 || temperature <= 0) return 0;
  
  const z = Math.log(energy) / (Math.PI * energy);
  const cosApprox = 1 - (z * z) / 2;
  
  if (cosApprox <= 0) return 0;
  
  return -K_BOLTZMANN * temperature * Math.log(cosApprox);
}

/**
 * Full entropy expression with modular term
 * S = (k_B/T)⟨E⟩ + (k_B/2π²) Σ_i p_i (ln² E_i / E_i²) + k_B ln Z
 */
export function calculateModularEntropy(
  energies: number[],
  probabilities: number[],
  temperature: number
): EntropyState {
  if (energies.length !== probabilities.length) {
    throw new Error('Energies and probabilities must have same length');
  }
  
  // Expected energy
  let expectedEnergy = 0;
  for (let i = 0; i < energies.length; i++) {
    expectedEnergy += probabilities[i] * energies[i];
  }
  
  // Modified energy term (approximate form)
  let modifiedEnergySum = 0;
  for (let i = 0; i < energies.length; i++) {
    if (energies[i] > 0) {
      const lnE = Math.log(energies[i]);
      modifiedEnergySum += probabilities[i] * (lnE * lnE) / (energies[i] * energies[i]);
    }
  }
  const modifiedEnergy = (K_BOLTZMANN / (2 * Math.PI * Math.PI)) * modifiedEnergySum;
  
  // Partition function (simplified)
  let partitionFunction = 0;
  for (let i = 0; i < energies.length; i++) {
    if (temperature > 0) {
      partitionFunction += Math.exp(-energies[i] / (K_BOLTZMANN * temperature));
    }
  }
  
  // Total entropy
  const entropy = (K_BOLTZMANN / temperature) * expectedEnergy + 
                  modifiedEnergy + 
                  K_BOLTZMANN * Math.log(partitionFunction);
  
  return {
    temperature,
    expectedEnergy,
    modifiedEnergy,
    partitionFunction,
    entropy,
  };
}

// ============================================
// Feedback-Controlled Systems
// ============================================

/**
 * Feedback modulation function
 * f(α, t) = 1 + α sin(ωt + φ)
 */
export function feedbackModulation(
  params: FeedbackParameters,
  t: number
): number {
  return 1 + params.alpha * Math.sin(params.omega * t + params.phi);
}

/**
 * Modulated energy with feedback
 * E_i(t) = E_{i,0} · f(α_i, t)
 */
export function modulatedEnergy(
  baselineEnergy: number,
  params: FeedbackParameters,
  t: number
): number {
  return baselineEnergy * feedbackModulation(params, t);
}

/**
 * Calculate entropy with feedback-modulated energies
 */
export function calculateFeedbackEntropy(
  baselineEnergies: number[],
  probabilities: number[],
  feedbackParams: FeedbackParameters[],
  temperature: number,
  t: number
): EntropyState {
  const modulatedEnergies = baselineEnergies.map((E0, i) => 
    modulatedEnergy(E0, feedbackParams[i] || feedbackParams[0], t)
  );
  
  return calculateModularEntropy(modulatedEnergies, probabilities, temperature);
}

// ============================================
// Optimization for Targeted Cooling
// ============================================

/**
 * Calculate entropy derivative with respect to feedback amplitude
 * ∂S/∂α_i = 0 for optimal cooling
 */
export function entropyDerivativeAlpha(
  baselineEnergy: number,
  params: FeedbackParameters,
  probability: number,
  temperature: number,
  t: number
): number {
  const E = modulatedEnergy(baselineEnergy, params, t);
  const sinTerm = Math.sin(params.omega * t + params.phi);
  
  // Simplified derivative
  const dE_dalpha = baselineEnergy * sinTerm;
  const lnE = Math.log(E);
  
  const term1 = (K_BOLTZMANN / temperature) * probability * dE_dalpha;
  const term2 = (K_BOLTZMANN / (Math.PI * Math.PI)) * probability * 
                (lnE / (E * E * E)) * (1 - lnE) * dE_dalpha;
  
  return term1 + term2;
}

/**
 * Find optimal feedback parameters for cooling
 * Uses gradient descent on entropy
 */
export function optimizeCooling(
  baselineEnergies: number[],
  initialParams: FeedbackParameters[],
  temperature: number,
  iterations: number = 100,
  learningRate: number = 0.01
): FeedbackParameters[] {
  const params = initialParams.map(p => ({ ...p }));
  
  for (let iter = 0; iter < iterations; iter++) {
    const t = iter * 0.1;
    
    for (let i = 0; i < params.length; i++) {
      // Gradient on alpha
      const gradAlpha = entropyDerivativeAlpha(
        baselineEnergies[i],
        params[i],
        1.0 / baselineEnergies.length,
        temperature,
        t
      );
      
      // Update parameters (gradient descent to minimize entropy)
      params[i].alpha -= learningRate * gradAlpha;
      params[i].alpha = Math.max(0, Math.min(1, params[i].alpha));
    }
  }
  
  return params;
}

// ============================================
// 3D Standing Wave Patterns
// ============================================

/**
 * Generate 3D standing wave pattern for cooling
 * I(x,y,z,t) = I_0 (1 + α sin(ωt + φ(x,y,z)))
 */
export function generateStandingWave(
  x: number,
  y: number,
  z: number,
  t: number,
  profile: CoolingProfile
): number {
  const { position, intensity, frequency, phase } = profile;
  
  // Distance from target position
  const dx = x - position[0];
  const dy = y - position[1];
  const dz = z - position[2];
  const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
  
  // Spatial phase modulation
  const spatialPhase = distance * 2 * Math.PI;
  
  return intensity * (1 + 0.5 * Math.sin(frequency * t + phase + spatialPhase));
}

/**
 * Generate cooling matrix with multiple zones
 */
export function generateCoolingMatrix(
  size: [number, number, number],
  profiles: CoolingProfile[],
  t: number
): Float32Array {
  const [nx, ny, nz] = size;
  const matrix = new Float32Array(nx * ny * nz);
  
  for (let iz = 0; iz < nz; iz++) {
    for (let iy = 0; iy < ny; iy++) {
      for (let ix = 0; ix < nx; ix++) {
        const idx = iz * ny * nx + iy * nx + ix;
        const x = ix / nx;
        const y = iy / ny;
        const z = iz / nz;
        
        // Sum contributions from all profiles
        let total = 0;
        for (const profile of profiles) {
          total += generateStandingWave(x, y, z, t, profile);
        }
        
        matrix[idx] = total;
      }
    }
  }
  
  return matrix;
}

// ============================================
// UV Purification Application
// ============================================

/**
 * UV intensity with modular modulation
 * I_i(x,y,z,t) = I_{i,0} (1 + α_i sin(ω_i t + φ_i(x,y,z)))
 */
export function modulatedUVIntensity(
  x: number,
  y: number,
  z: number,
  t: number,
  baselineIntensity: number,
  params: FeedbackParameters,
  waveVector: [number, number, number]
): number {
  const [kx, ky, kz] = waveVector;
  const spatialPhase = kx * x + ky * y + kz * z;
  
  return baselineIntensity * (1 + params.alpha * Math.sin(params.omega * t + params.phi + spatialPhase));
}

/**
 * Microbial inactivation rate under UV
 * dN/dt = -K · Σ_i ε_i I_i(x,y,z,t) · N
 */
export function microbialInactivationRate(
  uvIntensities: number[],
  effectivenessFactors: number[],
  inactivationConstant: number
): number {
  let totalDose = 0;
  for (let i = 0; i < uvIntensities.length; i++) {
    totalDose += effectivenessFactors[i] * uvIntensities[i];
  }
  return -inactivationConstant * totalDose;
}

// ============================================
// Copper-Silver Ionization Application
// ============================================

/**
 * Ion concentration with modulated release
 * C_i(x,y,z,t) = C_{i,0}(x,y,z) · f(α_i, ω_i, t, φ_i)
 */
export function modulatedIonConcentration(
  baselineConcentration: number,
  params: FeedbackParameters,
  t: number
): number {
  return baselineConcentration * feedbackModulation(params, t);
}

/**
 * Microbial viability under ion exposure
 * p_j(t) = p_{j,0} · exp(-∫ Σ_i k_i C_i(x_j,y_j,z_j,τ) dτ)
 */
export function microbialViability(
  initialViability: number,
  ionConcentrations: number[],
  inactivationRates: number[],
  time: number
): number {
  let totalExposure = 0;
  for (let i = 0; i < ionConcentrations.length; i++) {
    totalExposure += inactivationRates[i] * ionConcentrations[i] * time;
  }
  return initialViability * Math.exp(-totalExposure);
}

// ============================================
// Visualization Helpers
// ============================================

export interface EntropyVisualization {
  energies: number[];
  probabilities: number[];
  modifiedEnergies: number[];
  entropy: number;
  temperature: number;
}

/**
 * Generate visualization data for entropy
 */
export function generateEntropyVisualization(
  numStates: number = 10,
  temperature: number = 300
): EntropyVisualization {
  const energies: number[] = [];
  const probabilities: number[] = [];
  const modifiedEnergies: number[] = [];
  
  // Generate energy levels (e.g., harmonic oscillator)
  for (let i = 0; i < numStates; i++) {
    const E = (i + 0.5) * K_BOLTZMANN * temperature * 2;
    energies.push(E);
    
    // Boltzmann probability
    const prob = Math.exp(-E / (K_BOLTZMANN * temperature));
    probabilities.push(prob);
    
    // Modified energy
    modifiedEnergies.push(modifiedEnergy(E, temperature));
  }
  
  // Normalize probabilities
  const sumProb = probabilities.reduce((a, b) => a + b, 0);
  for (let i = 0; i < probabilities.length; i++) {
    probabilities[i] /= sumProb;
  }
  
  const state = calculateModularEntropy(energies, probabilities, temperature);
  
  return {
    energies,
    probabilities,
    modifiedEnergies,
    entropy: state.entropy,
    temperature,
  };
}

/**
 * Generate cooling profile visualization
 */
export function generateCoolingVisualization(
  profiles: CoolingProfile[],
  timeSteps: number = 100
): Float32Array[] {
  const frames: Float32Array[] = [];
  
  for (let t = 0; t < timeSteps; t++) {
    const time = t * 0.1;
    const matrix = generateCoolingMatrix([32, 32, 1], profiles, time);
    frames.push(matrix);
  }
  
  return frames;
}
