/**
 * PPU Engine - Core Architecture
 * PPU Clock → Poles → GIF Display
 * Touch input feeds the GIF producer
 * All runs continuously at optimized frame rate
 */

// ============================================
// PPU Clock - Master timing source
// ============================================

export interface PPUClock {
  tick: number;           // Current clock tick
  frequency: number;      // Clock frequency in Hz
  phase: number;          // Current phase (0-2π)
  time: number;           // Accumulated time
}

// ============================================
// 12-Pole Harmonic Oscillator System
// ============================================

export interface Poles {
  positions: Float32Array;  // 12 pole positions
  velocities: Float32Array; // 12 pole velocities
  energies: Float32Array;   // Energy per pole
  phases: Float32Array;     // Phase per pole
  coherence: number;        // Global coherence (0-1)
  entropy: number;          // Global entropy (0-1)
}

// ============================================
// GIF Field - Visual computational substrate
// ============================================

export interface GIFField {
  width: number;
  height: number;
  pixels: Uint8ClampedArray;  // RGBA pixel data
  fieldA: Float32Array;       // Reaction component A
  fieldB: Float32Array;       // Reaction component B
  fieldC: Float32Array;       // Reaction component C
  touchEnergy: Float32Array;  // Energy from touch input
}

// ============================================
// Touch Input
// ============================================

export interface TouchInput {
  x: number;
  y: number;
  pressure: number;
  active: boolean;
  timestamp: number;
}

// ============================================
// PPU Engine State
// ============================================

export interface PPUEngineState {
  clock: PPUClock;
  poles: Poles;
  gif: GIFField;
  touch: TouchInput;
  running: boolean;
  frameCount: number;
  lastFrameTime: number;
  fps: number;
}

// ============================================
// Constants
// ============================================

const NUM_POLES = 12;
const DEFAULT_WIDTH = 256;
const DEFAULT_HEIGHT = 256;

// Pole frequencies (harmonic series with golden ratio modulation)
const POLE_FREQUENCIES = new Float32Array(NUM_POLES).map((_, i) => {
  const phi = 1.618033988749895;
  return 1.0 + 0.13 * i + 0.07 * Math.sin(i * phi);
});

// Pole damping factors
const POLE_DAMPING = new Float32Array(NUM_POLES).map((_, i) => {
  return 0.08 + 0.004 * i;
});

// ============================================
// PPU Engine Class
// ============================================

export class PPUEngine {
  private state: PPUEngineState;
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private imageData: ImageData | null = null;
  private animationId: number | null = null;
  private onFrame: ((state: PPUEngineState) => void) | null = null;
  
  // Performance tracking
  private frameTimes: number[] = [];
  
  constructor() {
    this.state = this.createInitialState();
  }
  
  private createInitialState(): PPUEngineState {
    const size = DEFAULT_WIDTH * DEFAULT_HEIGHT;
    
    return {
      clock: {
        tick: 0,
        frequency: 60,
        phase: 0,
        time: 0,
      },
      poles: {
        positions: new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 2),
        velocities: new Float32Array(NUM_POLES).map(() => (Math.random() - 0.5) * 0.1),
        energies: new Float32Array(NUM_POLES),
        phases: new Float32Array(NUM_POLES),
        coherence: 0.78,
        entropy: 0.12,
      },
      gif: {
        width: DEFAULT_WIDTH,
        height: DEFAULT_HEIGHT,
        pixels: new Uint8ClampedArray(size * 4),
        fieldA: new Float32Array(size).map(() => 0.1 + Math.random() * 0.1),
        fieldB: new Float32Array(size).map(() => 0.08 + Math.random() * 0.08),
        fieldC: new Float32Array(size).map(() => 0.05 + Math.random() * 0.05),
        touchEnergy: new Float32Array(size),
      },
      touch: {
        x: 0,
        y: 0,
        pressure: 0,
        active: false,
        timestamp: 0,
      },
      running: false,
      frameCount: 0,
      lastFrameTime: performance.now(),
      fps: 60,
    };
  }
  
  // ============================================
  // Canvas Setup
  // ============================================
  
  setCanvas(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    
    // Set canvas size to match GIF field
    canvas.width = DEFAULT_WIDTH;
    canvas.height = DEFAULT_HEIGHT;
    
    if (this.ctx) {
      this.imageData = this.ctx.createImageData(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    }
  }
  
  setOnFrame(callback: (state: PPUEngineState) => void): void {
    this.onFrame = callback;
  }
  
  // ============================================
  // Touch Input Handling
  // ============================================
  
  handleTouch(x: number, y: number, pressure: number = 1.0): void {
    // Scale touch coordinates to GIF field
    const fieldX = Math.floor((x / (this.canvas?.width || 1)) * DEFAULT_WIDTH);
    const fieldY = Math.floor((y / (this.canvas?.height || 1)) * DEFAULT_HEIGHT);
    
    this.state.touch.x = fieldX;
    this.state.touch.y = fieldY;
    this.state.touch.pressure = pressure;
    this.state.touch.active = true;
    this.state.touch.timestamp = performance.now();
    
    // Add energy to GIF field at touch location
    this.addTouchEnergy(fieldX, fieldY, pressure);
    
    // Excite poles based on touch
    this.excitePoles(pressure);
  }
  
  handleTouchEnd(): void {
    this.state.touch.active = false;
    this.state.touch.pressure = 0;
  }
  
  private addTouchEnergy(x: number, y: number, strength: number): void {
    const { width, height, touchEnergy, fieldA, fieldB, fieldC } = this.state.gif;
    const radius = 15;
    const r2 = radius * radius;
    
    for (let dy = -radius; dy <= radius; dy++) {
      const py = y + dy;
      if (py < 0 || py >= height) continue;
      
      for (let dx = -radius; dx <= radius; dx++) {
        const px = x + dx;
        if (px < 0 || px >= width) continue;
        
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        
        const idx = py * width + px;
        const energy = strength * (1 - d2 / r2);
        
        touchEnergy[idx] += energy;
        fieldA[idx] = Math.min(1, fieldA[idx] + 0.3 * energy);
        fieldB[idx] = Math.min(1, fieldB[idx] + 0.2 * energy);
        fieldC[idx] = Math.min(1, fieldC[idx] + 0.15 * energy);
      }
    }
  }
  
  private excitePoles(strength: number): void {
    const { velocities } = this.state.poles;
    for (let i = 0; i < NUM_POLES; i++) {
      velocities[i] += (Math.random() - 0.5) * 2 * strength * (1 + i * 0.1);
    }
    this.state.poles.coherence = Math.min(1, this.state.poles.coherence + 0.1 * strength);
  }
  
  // ============================================
  // Core Engine Loop
  // ============================================
  
  start(): void {
    if (this.state.running) return;
    this.state.running = true;
    this.state.lastFrameTime = performance.now();
    this.runLoop();
  }
  
  stop(): void {
    this.state.running = false;
    if (this.animationId !== null) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }
  
  private runLoop(): void {
    if (!this.state.running) return;
    
    const now = performance.now();
    const elapsed = now - this.state.lastFrameTime;
    
    // Adaptive frame rate - process multiple steps if needed
    const dt = Math.min(elapsed / 1000, 0.05); // Cap at 50ms
    
    // Step all architecture layers
    this.stepClock(dt);
    this.stepPoles(dt);
    this.stepGIFField(dt);
    this.render();
    
    // Update stats
    this.state.frameCount++;
    this.state.lastFrameTime = now;
    
    // Calculate FPS
    this.frameTimes.push(now);
    while (this.frameTimes.length > 30) this.frameTimes.shift();
    if (this.frameTimes.length > 1) {
      const span = this.frameTimes[this.frameTimes.length - 1] - this.frameTimes[0];
      this.state.fps = (this.frameTimes.length - 1) / (span / 1000);
    }
    
    // Notify callback
    if (this.onFrame) {
      this.onFrame(this.state);
    }
    
    // Schedule next frame
    this.animationId = requestAnimationFrame(() => this.runLoop());
  }
  
  // ============================================
  // PPU Clock Step
  // ============================================
  
  private stepClock(dt: number): void {
    const clock = this.state.clock;
    clock.time += dt;
    clock.tick++;
    clock.phase = (clock.phase + 2 * Math.PI * clock.frequency * dt) % (2 * Math.PI);
  }
  
  // ============================================
  // Poles Step - 12 Harmonic Oscillators
  // ============================================
  
  private stepPoles(dt: number): void {
    const { positions, velocities, energies, phases } = this.state.poles;
    const clockPhase = this.state.clock.phase;
    
    let totalEnergy = 0;
    
    for (let i = 0; i < NUM_POLES; i++) {
      const freq = POLE_FREQUENCIES[i];
      const damping = POLE_DAMPING[i];
      
      // Harmonic oscillator with clock coupling
      const clockDrive = 0.1 * Math.sin(clockPhase * freq + i * 0.5);
      const coupling = this.calculatePoleCoupling(i);
      
      // Acceleration: -ω²x - γv + drive + coupling
      const acceleration = 
        -freq * freq * positions[i] 
        - damping * velocities[i] 
        + clockDrive 
        + coupling;
      
      // Update velocity and position (Verlet integration)
      velocities[i] += acceleration * dt;
      positions[i] += velocities[i] * dt;
      
      // Update phase
      phases[i] = (phases[i] + freq * dt) % (2 * Math.PI);
      
      // Calculate energy
      energies[i] = 0.5 * (positions[i] * positions[i] + velocities[i] * velocities[i]);
      totalEnergy += energies[i];
    }
    
    // Update global coherence and entropy
    const avgEnergy = totalEnergy / NUM_POLES;
    const energyVariance = energies.reduce((sum, e) => sum + (e - avgEnergy) ** 2, 0) / NUM_POLES;
    
    this.state.poles.entropy = Math.min(1, avgEnergy / 2);
    this.state.poles.coherence = Math.max(0, 1 - Math.sqrt(energyVariance) / (avgEnergy + 0.01));
  }
  
  private calculatePoleCoupling(index: number): number {
    const { positions } = this.state.poles;
    let coupling = 0;
    
    // Nearest-neighbor coupling
    const left = (index - 1 + NUM_POLES) % NUM_POLES;
    const right = (index + 1) % NUM_POLES;
    
    coupling += 0.05 * (positions[left] + positions[right] - 2 * positions[index]);
    
    // Long-range coupling (weaker)
    for (let i = 0; i < NUM_POLES; i++) {
      if (i !== index && i !== left && i !== right) {
        const distance = Math.min(Math.abs(i - index), NUM_POLES - Math.abs(i - index));
        coupling += 0.01 * positions[i] / (distance * distance);
      }
    }
    
    return coupling;
  }
  
  // ============================================
  // GIF Field Step - Reaction-Diffusion
  // ============================================
  
  private stepGIFField(dt: number): void {
    const { width, height, fieldA, fieldB, fieldC, touchEnergy } = this.state.gif;
    const { positions, coherence } = this.state.poles;
    
    // Modulate reaction parameters with pole positions
    const feedRate = 0.032 + 0.01 * positions[0] * coherence;
    const killRate = 0.053 + 0.01 * positions[1] * coherence;
    const diffusionA = 1.0 + 0.2 * positions[2];
    const diffusionB = 0.55 + 0.1 * positions[3];
    const diffusionC = 0.35 + 0.1 * positions[4];
    
    // Temporary arrays for update
    const newA = new Float32Array(fieldA);
    const newB = new Float32Array(fieldB);
    const newC = new Float32Array(fieldC);
    
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = y * width + x;
        
        const a = fieldA[idx];
        const b = fieldB[idx];
        const c = fieldC[idx];
        
        // Laplacian (5-point stencil)
        const la = this.laplacian(fieldA, x, y, width);
        const lb = this.laplacian(fieldB, x, y, width);
        const lc = this.laplacian(fieldC, x, y, width);
        
        // Reaction term (Gray-Scott like)
        const ab2 = a * b * b;
        
        // Update with touch energy influence
        const touch = touchEnergy[idx] * 0.1;
        
        let na = a + (diffusionA * la - ab2 + feedRate * (1 - a) + touch) * dt;
        let nb = b + (diffusionB * lb + ab2 - (killRate + feedRate) * b + touch * 0.5) * dt;
        let nc = c + (diffusionC * lc + 0.1 * ab2 - 0.06 * c + touch * 0.3) * dt;
        
        // Clamp
        newA[idx] = Math.max(0, Math.min(1, na));
        newB[idx] = Math.max(0, Math.min(1, nb));
        newC[idx] = Math.max(0, Math.min(1, nc));
      }
    }
    
    // Copy back
    this.state.gif.fieldA.set(newA);
    this.state.gif.fieldB.set(newB);
    this.state.gif.fieldC.set(newC);
    
    // Decay touch energy
    for (let i = 0; i < touchEnergy.length; i++) {
      touchEnergy[i] *= 0.95;
    }
  }
  
  private laplacian(field: Float32Array, x: number, y: number, width: number): number {
    const idx = y * width + x;
    return field[idx - 1] + field[idx + 1] + field[idx - width] + field[idx + width] - 4 * field[idx];
  }
  
  // ============================================
  // Render to Canvas
  // ============================================
  
  private render(): void {
    if (!this.ctx || !this.imageData) return;
    
    const { width, height, fieldA, fieldB, fieldC } = this.state.gif;
    const { positions, phases } = this.state.poles;
    const data = this.imageData.data;
    
    // Color mapping modulated by pole positions
    const hueShift = 0.5 + 0.3 * Math.sin(phases[0]);
    const saturation = 0.7 + 0.2 * positions[1];
    
    for (let i = 0; i < width * height; i++) {
      const a = fieldA[i];
      const b = fieldB[i];
      const c = fieldC[i];
      
      // HSL to RGB conversion with pole modulation
      const h = (hueShift + 0.2 * b + 0.1 * c) % 1;
      const s = saturation * (0.5 + 0.5 * a);
      const l = 0.1 + 0.4 * a + 0.2 * b;
      
      const rgb = this.hslToRgb(h, s, l);
      
      const p = i * 4;
      data[p] = rgb[0];
      data[p + 1] = rgb[1];
      data[p + 2] = rgb[2];
      data[p + 3] = 255;
    }
    
    // Put image data
    this.ctx.putImageData(this.imageData, 0, 0);
  }
  
  private hslToRgb(h: number, s: number, l: number): [number, number, number] {
    let r: number, g: number, b: number;
    
    if (s === 0) {
      r = g = b = l;
    } else {
      const hue2rgb = (p: number, q: number, t: number): number => {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1/6) return p + (q - p) * 6 * t;
        if (t < 1/2) return q;
        if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
        return p;
      };
      
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1/3);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1/3);
    }
    
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
  }
  
  // ============================================
  // Public API
  // ============================================
  
  getState(): PPUEngineState {
    return this.state;
  }
  
  getPoles(): Poles {
    return this.state.poles;
  }
  
  getClock(): PPUClock {
    return this.state.clock;
  }
  
  getFPS(): number {
    return this.state.fps;
  }
  
  reset(): void {
    this.state = this.createInitialState();
  }
}

// ============================================
// Singleton instance
// ============================================

let globalEngine: PPUEngine | null = null;

export function getPPUEngine(): PPUEngine {
  if (!globalEngine) {
    globalEngine = new PPUEngine();
  }
  return globalEngine;
}

export function resetPPUEngine(): void {
  globalEngine = null;
}
