// PPU-AQC Unified Platform Type Definitions

// ============================================
// PPU (Prime Processing Unit) Types
// ============================================

export interface PPUState {
  coherence: number;      // 0-1, controls system order
  smooth: number;         // smoothing factor
  entropy: number;        // system entropy
  temperature: number;    // effective temperature
  load: number;          // computational load
  poles: Float32Array;   // 12 harmonic oscillators
  vels: Float32Array;    // pole velocities
}

export interface PrimeDomainValue {
  prime: number;
  exponent: number;
  analogValue: number;   // Vp = p * Vunit
}

export interface PrimeFactorization {
  value: number;
  factors: Map<number, number>; // prime -> exponent
  vector: number[]; // exponent vector
}

// ============================================
// AQC (Analog Quantum Coherence) Types
// ============================================

export interface AQCState {
  fieldA: Float32Array;  // Reaction-diffusion activator
  fieldB: Float32Array;  // Reaction-diffusion inhibitor
  fieldC: Float32Array;  // Third component (memory)
  gridWidth: number;
  gridHeight: number;
  scale: number;
}

export interface EmergenceMap {
  transform: (x: number, y: number, t: number) => number;
  readout: (field: Float32Array) => number[];
}

// ============================================
// GIFLife Field Types
// ============================================

export interface GIFLifeConfig {
  width: number;
  height: number;
  feedRate: number;
  killRate: number;
  diffusionA: number;
  diffusionB: number;
  diffusionC: number;
  timeStep: number;
}

export interface FieldSnapshot {
  timestamp: number;
  fieldA: Float32Array;
  fieldB: Float32Array;
  fieldC: Float32Array;
  ppuState: PPUState;
}

// ============================================
// Python Kernel Types
// ============================================

export interface PythonKernelState {
  ready: boolean;
  loading: boolean;
  status: 'idle' | 'loading' | 'ready' | 'running' | 'error';
  lastOutput: string;
  lastError: string;
  lastFigure: string | null; // base64 image
}

export interface CodeCell {
  id: string;
  code: string;
  output: string;
  error: string;
  figure: string | null;
  timestamp: number;
}

// ============================================
// Trigonometric Set Theory Types
// ============================================

export interface TrigOperator {
  name: string;
  symbol: (k: number) => Complex;
  domain: [number, number];
}

export interface Complex {
  re: number;
  im: number;
}

// Re-export for convenience
export type { Complex as ComplexNumber };

export interface BooleanGate {
  name: 'NOT' | 'AND' | 'OR' | 'XOR' | 'NAND' | 'NOR' | 'XNOR';
  trigExpression: string;
  evaluate: (inputs: boolean[]) => boolean;
  spectralForm: (x: number, y?: number) => number;
}

export interface WalshCharacter {
  subset: number[];
  value: (x: boolean[]) => number;
}

// ============================================
// Modular Entropy Types
// ============================================

export interface EntropyState {
  temperature: number;
  expectedEnergy: number;
  modifiedEnergy: number;
  partitionFunction: number;
  entropy: number;
}

export interface FeedbackParameters {
  alpha: number;  // amplitude
  omega: number;  // frequency
  phi: number;    // phase
}

export interface CoolingProfile {
  position: [number, number, number];
  intensity: number;
  frequency: number;
  phase: number;
}

// ============================================
// Multisensory Glyph-Convolutional Types
// ============================================

export interface GlyphAtom {
  layer: number;
  modality: string;
  template: number;
  polarity: '+' | '-';
}

export interface Glyph {
  atoms: Map<string, number>; // atom key -> multiplicity
  support: Set<string>;
}

export interface ModalityConfig {
  name: string;
  layers: number;
  templates: number[];
  polarities: ('+' | '-')[];
}

export interface SpectralLadder {
  modality: string;
  eigenvalues: Complex[];
  determinant: number;
}

// ============================================
// PPU-in-JPEG/GIF Types
// ============================================

export interface PPUContainer {
  magic: 'PPUJ' | 'PPUG';
  version: number;
  header: PPUHeader;
  bytecode: Uint8Array;
  truthTable?: TruthTable;
  palette?: number[];
  signature?: Uint8Array;
}

export interface PPUHeader {
  entryPoint: number;
  fbWidth: number;
  fbHeight: number;
  targetFPS: number;
  ioGridX: number;
  ioGridY: number;
  featureFlags: number;
  gradientLevel: GradientLevel;
}

export type GradientLevel = 'G0_LOSSLESS' | 'G1_CORE_LOSSLESS' | 'G2_RECONSTRUCTIBLE' | 'G3_VISUAL_ONLY';

export interface TruthTable {
  records: Map<string, number>; // input key -> command
}

export interface PPUVMState {
  registers: Uint32Array; // 16 registers
  ram: Uint8Array;       // 64KB
  framebuffer: Uint32Array; // RGBA
  pc: number;
  cycles: number;
  ioRegisters: IORegisters;
}

export interface IORegisters {
  cmd: number;
  tick: number;
  touchX: number;
  touchY: number;
  mode: number;
}

// ============================================
// UI Types
// ============================================

export type TabId = 'home' | 'python' | 'compiler' | 'nlp' | 'nlexec' | 'apps' | 'ppu' | 'entropy' | 'trig' | 'glyph' | 'container' | 'settings';

export interface UIState {
  activeTab: TabId;
  sidebarOpen: boolean;
  darkMode: boolean;
  showHUD: boolean;
}

export interface LogEntry {
  timestamp: number;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
}

// ============================================
// Utility Types
// ============================================

export interface Point2D {
  x: number;
  y: number;
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Color {
  r: number;
  g: number;
  b: number;
  a: number;
}

// FFT Types for spectral operations
export interface FFTResult {
  real: Float32Array;
  imag: Float32Array;
  magnitude: Float32Array;
  phase: Float32Array;
}
