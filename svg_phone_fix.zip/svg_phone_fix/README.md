# SVG Phone Fix (buttons + responsive)

## What this does
- Makes your inline SVG scale correctly on phone screens (100vw x 100vh + viewBox).
- Fixes "buttons not responsive" by **auto-adding invisible hitboxes** to elements with:
  - class="btn" OR data-action="..."

## How to use
1) Open `index.html`
2) Replace the demo <svg> with your own SVG (INLINE).
3) Add `class="btn"` and `data-action="something"` to anything clickable.
4) If you have overlays that steal taps, add `class="no-pointer"` to them.

## Run locally on phone
- Easiest: upload the folder to Netlify Drop (static hosting), or
- Run a local server (PC):
  - `python -m http.server 8000`
  - open http://<your-lan-ip>:8000 on your phone

## Build (compiled single file)
- `compiled_single_file.html` is already generated for you.
- It contains everything in one HTML file (SVG + JS).
